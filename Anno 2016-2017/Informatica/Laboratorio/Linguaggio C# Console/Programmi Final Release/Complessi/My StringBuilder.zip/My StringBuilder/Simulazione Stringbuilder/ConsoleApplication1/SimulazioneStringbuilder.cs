﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class SimulazioneStringbuilder
    {
        //attributi
     
        //metodi
        public SimulazioneStringbuilder()
        {           
        }

        public int indexof(string s,int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            int pos = 0;
            bool trovato = false;
            Console.Write("Inserire carattere da ricercare: ");
            string input = Console.ReadLine();
            char val = char.Parse(input);

            for (int i = 0; i < cont; i++)
            {
                if (val == s[i])
                {
                    pos = i;
                    trovato = true;
                    goto jump;
                }

            }
            jump:

            if (trovato == false)
            {
                pos = -1;
            }
            return pos;

        }//index of

        public bool contiene(string s, int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            bool trovato = false;

            Console.Write("Inserire caratteri da ricercare(fino a 4 caratteri): ");
            string input = Console.ReadLine();
            char[] caratteri = new char[l-cont];

            for (int i = 0; i < cont; i++)
            {
                caratteri[i] = s[i];
            }

            for (int i = 0; i < cont; i++)
            {
                if (input.Length == 1)
                {
                    if (caratteri[i] == input[0])
                    {
                        trovato = true;
                        goto jump;
                    }//primo carattere
                }

                if (input.Length == 2)
                {
                    if (caratteri[i] == input[0])
                    {
                        if (caratteri[i + 1] == input[1])
                        {
                            trovato = true;
                            goto jump;
                        }//secondo carattere
                    }
                }

                if (input.Length == 3)
                {
                    if (caratteri[i] == input[0])
                    {
                        if (caratteri[i + 1] == input[1])
                        {
                            if (caratteri[i + 2] == input[2])
                            {
                                trovato = true;
                                goto jump;
                            }
                        }//secondo carattere
                    }
                }

                if (input.Length == 4)
                {
                    if (caratteri[i] == input[0])
                    {
                        if (caratteri[i + 1] == input[1])
                        {
                            if (caratteri[i + 2] == input[2])
                            {
                                if (caratteri[i + 3] == input[3])
                                {
                                    trovato = true;
                                    goto jump;
                                }//quarto carattere                       
                            }//terzo carattere
                        }//secondo carattere
                    }//primo carattere
                }                  
            }
            jump:
            return trovato;
        }


        public char[] rimuovi(string s, int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            Console.Write("Inserire posizione di partenza da rimuovere: ");
            int partenza = Convert.ToInt16(Console.ReadLine());

            Console.Write("Inserire quanti caratteri si vogliono rimuovere: ");
            int quanti = Convert.ToInt16(Console.ReadLine());

            char[] arrayinput = new char[l-cont];

            for (int i = 0; i < s.Length; i++)
            {
                arrayinput[i] = s[i];
            }

            for (int i = 0; i < quanti; i++)
            {
                arrayinput[partenza] = ' ';
                partenza++;
            }

           return arrayinput;

        }

        public char[] rimpiazza(string s, int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            Console.Write("Inserire carattere che si intende rimpiazzare: ");
            string input = Console.ReadLine();
            char val = char.Parse(input);

            Console.Write("Inserire nuovo carattere che andrà a rimpiazzare il precendete: ");
            string nuovo = Console.ReadLine().ToLower();
            char nuovocar = char.Parse(nuovo);

            char[] arrayparola = new char[l-cont];

            for (int i = 0; i < s.Length; i++)
            {
                arrayparola[i] = s[i];
            }

            for (int i = 0; i < s.Length; i++)
            {
                if (arrayparola[i] == val)
                {
                    arrayparola[i] = nuovocar;
                }            
            }

            return arrayparola;
        }

        public char[] inserisci(string s, int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            Console.Write("Inserire carattere da inserire: ");
            string input = Console.ReadLine();
            char val = char.Parse(input);

            Console.Write("Inserire posizione carattere da inserire: ");
            int posizione = Convert.ToInt16(Console.ReadLine());
            int pos = posizione;

            char[] arrayinput = new char[l-cont];

            for (int i = 0; i < s.Length; i++)
            {
                arrayinput[i] = s[i];
            }

           for (int i = s.Length; i > posizione; i--)
           {
               arrayinput[cont] = arrayinput[cont - 1];
               cont--;
           }

           arrayinput[posizione] = val;
    
           return arrayinput;

        }

        public int lastindexof(string s, int l)
        {
            int cont = 0;
            for (int i = 0; i < s.Length; i++)
            {
                cont++;
            }

            int pos = 0;
            bool trovato = false;

            Console.Write("Inserire carattere da ricercare: ");
            string input = Console.ReadLine();
            char val = char.Parse(input);

            char[] arrayreverse = new char[cont];
            for (int i = 0; i < s.Length; i++)
            {
                arrayreverse[i] = s[i];
            }

            Array.Reverse(arrayreverse);

            for (int i = 0; i < cont; i++)
            {
                if (val == arrayreverse[i])
                {
                    pos = i;
                    trovato = true;
                    goto jump;
                }

            }
            jump:

            if (trovato == false)
            {
                pos = -1;
            }
            return pos;

        }//lastindex of

    }
}
