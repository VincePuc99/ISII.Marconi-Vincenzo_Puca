﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mySBNS
{
    class mySB
    {
        private string mySBstr;
        private int mySBCapacity;

        // Costruttori
        public mySB()
        {
            mySBstr = "";
            mySBCapacity = 16;
        }

        public mySB(string prmS)
        {
            mySBstr = prmS;
            mySBCapacity = (mySBstr.Length/16 + 1)*16;
        }

        public mySB(string prmS, int prmC)
        {
            mySBstr = prmS;
            mySBCapacity = prmC;
        }

        // Proprietà
        public string Value
        {
            get { return mySBstr; }
            set { mySBstr = value;
                mySBCapacity = (mySBstr.Length / 16 + 1) * 16;
                }
        }

        public int Capacity
        {
            get { return mySBCapacity; }
            set { mySBCapacity = value; }
        }

        public int Length
        {
            get { return mySBstr.Length; }
        }

        // Metodi
        public int IndexOf(string prmS)
        {
            return mySBstr.IndexOf(prmS);
        }
        public int IndexOf(string prmS, int prmStart)
        {
            return mySBstr.IndexOf(prmS, prmStart);
        }
        public int IndexOf(string prmS, int prmStart, int prmQuanti)
        {
            return mySBstr.IndexOf(prmS, prmStart, prmQuanti);
        }
    }
}
