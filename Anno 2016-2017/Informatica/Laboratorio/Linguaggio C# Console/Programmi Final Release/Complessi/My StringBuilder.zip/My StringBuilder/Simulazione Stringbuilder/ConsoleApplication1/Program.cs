﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            SimulazioneStringbuilder I;            //dichiarazione
            I = new SimulazioneStringbuilder();

           
            int lunghezza = 16;
            int posizione = 0;
           
                Console.Write("Inserire capacità? (SI)-(NO) ");
                Console.Write("Se non viene inserita questa è di 16: ");
                string sn = Console.ReadLine().ToLower();

                if (sn == "si")
                {
                    int nuova = 0;
                    do
                    {
                        Console.Write("Inserie nuova capacity: ");
                        nuova = Convert.ToInt16(Console.ReadLine());

                        if (nuova < 16)
                        {
                            Console.WriteLine("Non può essere minore di 16");
                        }
                    } while (nuova < 16);
                    lunghezza = nuova;
                }

                Console.Write("Inserisci stringa: "); //richiamo indexof
                string stringa = Console.ReadLine().ToLower();

                posizione = I.indexof(stringa, lunghezza);
                Console.WriteLine("Cararettere in posizione: {0}", posizione);
                Console.WriteLine();


                Console.Write("Inserisci stringa: ");  //richiamo lastindex
                string stringa1 = Console.ReadLine().ToLower();

                posizione = I.lastindexof(stringa1, lunghezza);
                Console.WriteLine("Cararettere in posizione: {0}", posizione);
                Console.WriteLine();


                Console.Write("Inserisci stringa: "); //richiamo remove
                string stringa2 = Console.ReadLine().ToLower();

                char[] stringapulita = new char[stringa2.Length];
                stringapulita = I.rimuovi(stringa2, lunghezza);
                Console.Write("Output: ");
                for (int i = 0; i < stringapulita.Length; i++)
                {
                    Console.Write(stringapulita[i]);
                }
                Console.WriteLine();

                Console.Write("Inserisci stringa: "); //richiamo inserisci
                string stringa3 = Console.ReadLine().ToLower();

                char[] stringanuova = new char[stringa3.Length];
                stringanuova = I.inserisci(stringa3, lunghezza);
                for (int i = 0; i < stringanuova.Length; i++)
                {
                    Console.Write(stringanuova[i]);
                }
                Console.WriteLine();

                Console.Write("Inserisci stringa: "); //richiamo replace
                string stringa4 = Console.ReadLine().ToLower();

                char[] stringareplace = new char[stringa4.Length];
                stringareplace = I.rimpiazza(stringa4, lunghezza);
                for (int i = 0; i < stringareplace.Length; i++)
                {
                    Console.Write(stringareplace[i]);
                }
                Console.WriteLine();

                Console.Write("Inserisci stringa: "); //richiamo contiene
                string stringa5 = Console.ReadLine().ToLower();
                bool trovato = I.contiene(stringa5, lunghezza);
                Console.WriteLine(trovato);
                Console.WriteLine();

        }
    }
}
