﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mySBNS
{
    class Program
    {
        static void Main(string[] args)
        {
            mySB mioSB = new mySB("prova");
            Console.WriteLine("Valore " + mioSB.Value);
            Console.WriteLine("Capacità " + mioSB.Capacity);
            Console.WriteLine("Lunghezza " + mioSB.Length);
            Console.WriteLine();
            mioSB.Value = "Nuova stringa moooooolto lunga";
            Console.WriteLine("Valore " + mioSB.Value);
            Console.WriteLine("Capacità " + mioSB.Capacity);
            Console.WriteLine("Lunghezza " + mioSB.Length);
            Console.WriteLine();
            Console.WriteLine("Posizione " + mioSB.IndexOf("o"));
            Console.WriteLine("Posizione " + mioSB.IndexOf("o", 8));
            Console.WriteLine("Posizione " + mioSB.IndexOf("o", 8, 5));
            Console.ReadKey();
        }
    }
}
