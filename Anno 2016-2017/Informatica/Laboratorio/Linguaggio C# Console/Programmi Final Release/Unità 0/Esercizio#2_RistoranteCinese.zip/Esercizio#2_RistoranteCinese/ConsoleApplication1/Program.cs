﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int costotot = 0;
            int quantit = 0;
            int scelta = 0;
            int totalizer = 0;
            menu(costotot, quantit, scelta,totalizer);
        }

        static void menu(int ctot,int quatit,int scel,int izer)
        {
            do
            {
                
                Console.WriteLine("\nxxxxxxxxxxxx Ristornante Cinese xxxxxxxxxxxxx");
                Console.WriteLine("1)Involtino primavera (5$)");
                Console.WriteLine("2)Ravioli al vapore (6$)");
                Console.WriteLine("3)Spaghetti di soia con verdure (4$)");
                Console.WriteLine("4)Pollo con bambù e funghi (8$)");
                Console.WriteLine("5)Vitello con sedano (7$)");
                Console.WriteLine("6)Termina il programma");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

                Console.WriteLine("Inserire l'opzione desiderata: ");
                scel = Convert.ToInt32(Console.ReadLine());

                switch (scel)
                {
                    case 1:
                      int a = invprima(ctot, quatit);
                      izer += a;
                        break;

                    case 2:
                       int b = raviovap(ctot, quatit);
                       izer += b;
                        break;

                    case 3:
                       int c = spagh(ctot, quatit);
                       izer += c;
                        break;

                    case 4:
                      int d = pollo(ctot, quatit);
                      izer += d;
                        break;

                    case 5:
                       int e = vitello(ctot, quatit);
                       izer += e;
                        break;

                    case 6:
                        fine(izer);
                        return;

                }
            } while (true);
        }

        static int invprima(int ctot, int quatit)
        {
            Console.WriteLine("Inserire quante se ne vuole: ");
            quatit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hai ordinato {0} involtini", quatit);
            ctot += quatit * 5;
            return ctot;
        }

        static int raviovap(int ctot, int quatit)
        {

            Console.WriteLine("Inserire quante se ne vuole: ");
            quatit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hai ordinato {0} Ravioli", quatit);
            ctot += quatit * 6;
            return ctot;
        }

        static int spagh(int ctot, int quatit)
        {
            Console.WriteLine("Inserire quante se ne vuole: ");
            quatit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hai ordinato {0} Spaghetti", quatit);
            ctot += quatit * 4;
            return ctot;
        }

        static int pollo(int ctot, int quatit)
        {
            Console.WriteLine("Inserire quante se ne vuole: ");
            quatit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hai ordinato {0} Pollo/i", quatit);
            ctot += quatit * 8;
            return ctot;
        }

        static int vitello(int ctot, int quatit)
        {
            Console.WriteLine("Inserire quante se ne vuole: ");
            quatit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Hai ordinato {0} Vitello/i", quatit);
            ctot += quatit * 7;
            return ctot;
        }

        static void fine(int ctot)
        {
            Console.WriteLine("Programma terminato...");
            Console.WriteLine("\nxxxxxxxxxxxx Ristornante Cinese xxxxxxxxxxxxx");
            Console.WriteLine("xxxxxxxxxxxxxx Scontrino Fiscale xxxxxxxxxxxxxx");
            Console.WriteLine("Subtot {0} $", ctot);
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
        }
    }
}
