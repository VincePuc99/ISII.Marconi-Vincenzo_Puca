﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Affinity
{
    public partial class Form1 : Form
    {
       static int affinita;
        public Form1()
        {
            InitializeComponent();
            affinita = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                   
        }

        private void bttt_verifica_Click(object sender, EventArgs e)
        {
            int etalui = Int32.Parse(txt_età_lui.Text);
            int etalei = Int32.Parse(txt_età_lei.Text);

            int differenza = etalei - etalui;

            if (differenza < 5 && differenza > -5)
            {
                affinita += 30;
            }

            if(cmbx_titoli_lei.Text == cmbx_titoli_lui.Text)
            {
                affinita += 20;
            }

            bool sport = chk_sport_lei.Checked;
            bool sport1 = chk_sport_lui.Checked;
            if ( sport == sport1) 
            {
                affinita += 25;
            }

            bool viaggi = chk_viaggi_lei.Checked;
            bool viaggi1 = chk_viaggi_lui.Checked;
            if (viaggi== viaggi1)
            {
                affinita += 25;
            }
            bool lettura = chbx_lettura_lei.Checked;
                bool lettura1 = chbx_lettura_lui.Checked;
            if (lettura == lettura1)
            {
                affinita += 25;
            }

            txt_percentuale.Text = "" + affinita + "%";
            prgrss_bar.Value = affinita;

        }//fine void

        private void btt_reset_Click(object sender, EventArgs e)
        {
            affinita = 0;
            prgrss_bar.Value = 0;
            txt_percentuale.Text = "";

            cmbx_titoli_lei.Text = "";
            cmbx_titoli_lui.Text = "";

            chbx_lettura_lui.Checked = false;
            chk_sport_lui.Checked = false;
            chk_viaggi_lui.Checked = false;
            txt_età_lui.Text = "";

            chbx_lettura_lei.Checked = false;
            chk_sport_lei.Checked = false;
            chk_viaggi_lei.Checked = false;
            txt_età_lei.Text = "";

        }

        private void Chiudi_Click(object sender, EventArgs e)
        {
            this.Close();
        }       
    }
}
