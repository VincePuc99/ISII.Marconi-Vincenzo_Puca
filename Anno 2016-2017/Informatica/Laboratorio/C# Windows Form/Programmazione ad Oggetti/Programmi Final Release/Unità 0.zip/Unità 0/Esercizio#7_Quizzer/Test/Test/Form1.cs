﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Test
{
    public partial class frmain : Form
    {
        static int cont = 0; //numero righe nel load
        static int numerorighe = 0; //numero righe globale
        static int numero = 0; //indica a quale domanda sei
        static string[][] domrispesaon = new string[cont][]; //contenuto del file
        static int[] risposteconfermateon = new int[numerorighe];
        static int punteggio = 0;
        static int i = 0;
       
        
        public frmain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int cont = 0;
            string coll = @"F:\Documenti\Scuola ISII\Anno 2016-2017\Informatica\Laboratorio\C# Windows Form\Programmi Final Release\Unità 0\Esercizio#7_Quizzer\Questionario.txt";
            StreamReader leggi = new StreamReader(coll);

            while (!leggi.EndOfStream)
            {
                leggi.ReadLine();
                cont++;
            }
            leggi.Close();

            numerorighe = cont; //salva il numero delle righe in globale
            string[][] domrispesa = new string[cont][]; 

            char Carattere;
            string frase = "";

            StreamReader leggi1 = new StreamReader(coll);
            for (int i = 0; i < cont; i++) //questi for servono ad inserire il file nell jagged
            {
                domrispesa[i] = new string[6];

                for (int j = 0; j < 6; j++)
                {
                    do
                    {
                        Carattere = (char)leggi1.Read();
                        if (Carattere != '#')
                        {
                            frase += Carattere;
                        }
                    } while (Carattere != '#');

                    domrispesa[i][j] = frase;
                    frase = "";
                }
                
                leggi1.Read();
                leggi1.Read();               

         }//fine for

         leggi1.Close();
         
         domrispesaon = domrispesa; //il contenuto del file passa da locale a globale

         int[] risposteconfermate = new int[numerorighe]; //fatto solo 1 volta per determinare la grandezza dell array
         risposteconfermateon = risposteconfermate;

        }//fine load

        private void btt_avvia_Click(object sender, EventArgs e)
        {
            if (rad_man.Checked == true)
            {
                txt_displaydomade.Text = domrispesaon[numero][0];
                lst_risposte.Items.Add(domrispesaon[numero][1]);
                lst_risposte.Items.Add(domrispesaon[numero][2]);
                lst_risposte.Items.Add(domrispesaon[numero][3]);
                lst_risposte.Items.Add(domrispesaon[numero][4]);
                btt_successivo.Enabled = true;
                rad_auto.Enabled = false;
                btt_avvia.Enabled = false;
                btt_precedente.Enabled = true;
                btt_confermarsip.Enabled = true;
                btt_valutaprova.Enabled = true;
            }
            if (rad_auto.Checked == true)
            {
                btt_successivo.Enabled = true;
                rad_man.Enabled = false;
                btt_avvia.Enabled = false;
                btt_confermarsip.Enabled = true;
                btt_valutaprova.Enabled = true;
                tmr_automatica.Enabled = true;
                txt_displaydomade.Text = domrispesaon[numero][0];
                lst_risposte.Items.Add(domrispesaon[numero][1]);
                lst_risposte.Items.Add(domrispesaon[numero][2]);
                lst_risposte.Items.Add(domrispesaon[numero][3]);
                lst_risposte.Items.Add(domrispesaon[numero][4]);

            }
            
        }

        private void btt_successivo_Click(object sender, EventArgs e)
        {
            numerorighe -= 1;
            if (numero != numerorighe)
            {
                numero++;
                txt_displaydomade.Text = domrispesaon[numero][0];
                lst_risposte.Items.Clear();
                lst_risposte.Items.Add(domrispesaon[numero][1]);
                lst_risposte.Items.Add(domrispesaon[numero][2]);
                lst_risposte.Items.Add(domrispesaon[numero][3]);
                lst_risposte.Items.Add(domrispesaon[numero][4]);
            }
            else
                numero--;

            numerorighe += 1;
            i = 0;
            prgbar_tempo.Value = 0;
          
        }

        private void btt_precedente_Click(object sender, EventArgs e)
        {
                if (numero == 0)
                {
                    txt_displaydomade.Text = domrispesaon[numero][0];
                    lst_risposte.Items.Clear();
                    lst_risposte.Items.Add(domrispesaon[numero][1]);
                    lst_risposte.Items.Add(domrispesaon[numero][2]);
                    lst_risposte.Items.Add(domrispesaon[numero][3]);
                    lst_risposte.Items.Add(domrispesaon[numero][4]);
                }

                if (numero != 0)
                {
                    numero--;
                    txt_displaydomade.Text = domrispesaon[numero][0];
                    lst_risposte.Items.Clear();
                    lst_risposte.Items.Add(domrispesaon[numero][1]);
                    lst_risposte.Items.Add(domrispesaon[numero][2]);
                    lst_risposte.Items.Add(domrispesaon[numero][3]);
                    lst_risposte.Items.Add(domrispesaon[numero][4]);
                }        
        }

        private void btt_confermarsip_Click(object sender, EventArgs e)
        {
         risposteconfermateon[numero] = lst_risposte.SelectedIndex + 1; //salva la risposat data nell array
        }

        private void btt_valutaprova_Click(object sender, EventArgs e)
        {
            DialogResult messaggio;
            for (int i = 0; i < numerorighe; i++) //controllo delle risposte se sono esatte
            {
                if (risposteconfermateon[i] == Int16.Parse(domrispesaon[i][5]))
                {
                    punteggio++;
                }
            }

            txt_displayvoto.Text = "" + punteggio + "/" + numerorighe;
            btt_valutaprova.Enabled = false;

            messaggio = MessageBox.Show("Prova Completata ", "FINE", MessageBoxButtons.OK);
            if (messaggio == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void prgbar_tempo_Click(object sender, EventArgs e)
        {

        }

        private void tmr_automatica_Tick(object sender, EventArgs e)
        {
            i++;

            numero += 1;
            if (numero == numerorighe)
            {
                for (int j = 1; j < 6; j++)
                {
                    prgbar_tempo.Value = j;
                    Thread.Sleep(1000);
                }
                tmr_automatica.Enabled = false;
                btt_successivo.Enabled = false;
                lst_risposte.Enabled = false;
                btt_confermarsip.Enabled = false;
                prgbar_tempo.Value = 0;
                prgbar_tempo.Enabled = false;
            }
            numero -= 1;
           
            if (i == 6)
            {
                i = 0;
                prgbar_tempo.Value = i;
                btt_successivo.PerformClick();
            }
            else
            {
                prgbar_tempo.Value = i;
            }
         
        }//fine pulsante succ
    }
}
