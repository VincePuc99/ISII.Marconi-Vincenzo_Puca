﻿namespace Concessionaria
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rdbtt_mercedes = new System.Windows.Forms.RadioButton();
            this.rdbtt_audi = new System.Windows.Forms.RadioButton();
            this.rdbtt_ford = new System.Windows.Forms.RadioButton();
            this.grp_marc = new System.Windows.Forms.GroupBox();
            this.grpbx_optionals = new System.Windows.Forms.GroupBox();
            this.chk_vernice = new System.Windows.Forms.CheckBox();
            this.chk_satellitare = new System.Windows.Forms.CheckBox();
            this.chk_cerchi = new System.Windows.Forms.CheckBox();
            this.chk_antifurto = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_prezzo = new System.Windows.Forms.TextBox();
            this.txt_sconto = new System.Windows.Forms.TextBox();
            this.btt_acquista = new System.Windows.Forms.Button();
            this.btt_reset = new System.Windows.Forms.Button();
            this.grp_marc.SuspendLayout();
            this.grpbx_optionals.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdbtt_mercedes
            // 
            this.rdbtt_mercedes.AutoSize = true;
            this.rdbtt_mercedes.Location = new System.Drawing.Point(8, 19);
            this.rdbtt_mercedes.Name = "rdbtt_mercedes";
            this.rdbtt_mercedes.Size = new System.Drawing.Size(66, 17);
            this.rdbtt_mercedes.TabIndex = 0;
            this.rdbtt_mercedes.TabStop = true;
            this.rdbtt_mercedes.Text = "Merceds";
            this.rdbtt_mercedes.UseVisualStyleBackColor = true;
            // 
            // rdbtt_audi
            // 
            this.rdbtt_audi.AutoSize = true;
            this.rdbtt_audi.Location = new System.Drawing.Point(80, 19);
            this.rdbtt_audi.Name = "rdbtt_audi";
            this.rdbtt_audi.Size = new System.Drawing.Size(46, 17);
            this.rdbtt_audi.TabIndex = 1;
            this.rdbtt_audi.TabStop = true;
            this.rdbtt_audi.Text = "Audi";
            this.rdbtt_audi.UseVisualStyleBackColor = true;
            // 
            // rdbtt_ford
            // 
            this.rdbtt_ford.AutoSize = true;
            this.rdbtt_ford.Location = new System.Drawing.Point(132, 19);
            this.rdbtt_ford.Name = "rdbtt_ford";
            this.rdbtt_ford.Size = new System.Drawing.Size(46, 17);
            this.rdbtt_ford.TabIndex = 2;
            this.rdbtt_ford.TabStop = true;
            this.rdbtt_ford.Text = "Ford";
            this.rdbtt_ford.UseVisualStyleBackColor = true;
            // 
            // grp_marc
            // 
            this.grp_marc.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.grp_marc.Controls.Add(this.rdbtt_mercedes);
            this.grp_marc.Controls.Add(this.rdbtt_audi);
            this.grp_marc.Controls.Add(this.rdbtt_ford);
            this.grp_marc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grp_marc.Location = new System.Drawing.Point(12, 12);
            this.grp_marc.Name = "grp_marc";
            this.grp_marc.Size = new System.Drawing.Size(190, 46);
            this.grp_marc.TabIndex = 3;
            this.grp_marc.TabStop = false;
            this.grp_marc.Text = "Marca Auto";
            // 
            // grpbx_optionals
            // 
            this.grpbx_optionals.Controls.Add(this.chk_antifurto);
            this.grpbx_optionals.Controls.Add(this.chk_cerchi);
            this.grpbx_optionals.Controls.Add(this.chk_satellitare);
            this.grpbx_optionals.Controls.Add(this.chk_vernice);
            this.grpbx_optionals.Location = new System.Drawing.Point(12, 73);
            this.grpbx_optionals.Name = "grpbx_optionals";
            this.grpbx_optionals.Size = new System.Drawing.Size(218, 67);
            this.grpbx_optionals.TabIndex = 4;
            this.grpbx_optionals.TabStop = false;
            this.grpbx_optionals.Text = "Optionals";
            // 
            // chk_vernice
            // 
            this.chk_vernice.AutoSize = true;
            this.chk_vernice.Location = new System.Drawing.Point(7, 20);
            this.chk_vernice.Name = "chk_vernice";
            this.chk_vernice.Size = new System.Drawing.Size(114, 17);
            this.chk_vernice.TabIndex = 0;
            this.chk_vernice.Text = "Vernice metallizata";
            this.chk_vernice.UseVisualStyleBackColor = true;
            // 
            // chk_satellitare
            // 
            this.chk_satellitare.AutoSize = true;
            this.chk_satellitare.Location = new System.Drawing.Point(7, 43);
            this.chk_satellitare.Name = "chk_satellitare";
            this.chk_satellitare.Size = new System.Drawing.Size(72, 17);
            this.chk_satellitare.TabIndex = 1;
            this.chk_satellitare.Text = "Satellitare";
            this.chk_satellitare.UseVisualStyleBackColor = true;
            // 
            // chk_cerchi
            // 
            this.chk_cerchi.AutoSize = true;
            this.chk_cerchi.Location = new System.Drawing.Point(122, 43);
            this.chk_cerchi.Name = "chk_cerchi";
            this.chk_cerchi.Size = new System.Drawing.Size(90, 17);
            this.chk_cerchi.TabIndex = 2;
            this.chk_cerchi.Text = "Cerchi in lega";
            this.chk_cerchi.UseVisualStyleBackColor = true;
            // 
            // chk_antifurto
            // 
            this.chk_antifurto.AutoSize = true;
            this.chk_antifurto.Location = new System.Drawing.Point(122, 19);
            this.chk_antifurto.Name = "chk_antifurto";
            this.chk_antifurto.Size = new System.Drawing.Size(65, 17);
            this.chk_antifurto.TabIndex = 3;
            this.chk_antifurto.Text = "Antifurto";
            this.chk_antifurto.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sconto %";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "€";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Prezzo totale";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txt_prezzo
            // 
            this.txt_prezzo.Location = new System.Drawing.Point(97, 177);
            this.txt_prezzo.Name = "txt_prezzo";
            this.txt_prezzo.ReadOnly = true;
            this.txt_prezzo.Size = new System.Drawing.Size(100, 20);
            this.txt_prezzo.TabIndex = 8;
            // 
            // txt_sconto
            // 
            this.txt_sconto.Location = new System.Drawing.Point(97, 151);
            this.txt_sconto.Name = "txt_sconto";
            this.txt_sconto.Size = new System.Drawing.Size(100, 20);
            this.txt_sconto.TabIndex = 9;
            // 
            // btt_acquista
            // 
            this.btt_acquista.Location = new System.Drawing.Point(36, 202);
            this.btt_acquista.Name = "btt_acquista";
            this.btt_acquista.Size = new System.Drawing.Size(75, 24);
            this.btt_acquista.TabIndex = 10;
            this.btt_acquista.Text = "Acquista";
            this.btt_acquista.UseVisualStyleBackColor = true;
            this.btt_acquista.Click += new System.EventHandler(this.btt_acquista_Click);
            // 
            // btt_reset
            // 
            this.btt_reset.Location = new System.Drawing.Point(115, 203);
            this.btt_reset.Name = "btt_reset";
            this.btt_reset.Size = new System.Drawing.Size(75, 23);
            this.btt_reset.TabIndex = 11;
            this.btt_reset.Text = "Reset";
            this.btt_reset.UseVisualStyleBackColor = true;
            this.btt_reset.Click += new System.EventHandler(this.btt_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 241);
            this.Controls.Add(this.btt_reset);
            this.Controls.Add(this.btt_acquista);
            this.Controls.Add(this.txt_sconto);
            this.Controls.Add(this.txt_prezzo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpbx_optionals);
            this.Controls.Add(this.grp_marc);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Concessionaria ";
            this.grp_marc.ResumeLayout(false);
            this.grp_marc.PerformLayout();
            this.grpbx_optionals.ResumeLayout(false);
            this.grpbx_optionals.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdbtt_mercedes;
        private System.Windows.Forms.RadioButton rdbtt_audi;
        private System.Windows.Forms.RadioButton rdbtt_ford;
        private System.Windows.Forms.GroupBox grp_marc;
        private System.Windows.Forms.GroupBox grpbx_optionals;
        private System.Windows.Forms.CheckBox chk_antifurto;
        private System.Windows.Forms.CheckBox chk_cerchi;
        private System.Windows.Forms.CheckBox chk_satellitare;
        private System.Windows.Forms.CheckBox chk_vernice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_prezzo;
        private System.Windows.Forms.TextBox txt_sconto;
        private System.Windows.Forms.Button btt_acquista;
        private System.Windows.Forms.Button btt_reset;
    }
}

