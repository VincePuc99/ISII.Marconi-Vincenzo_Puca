﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Bestpath
{
    public partial class frmtitolo : Form
    {
        static System.Windows.Forms.ErrorProvider errore;
        static double[][] orari = new double[4][];                    
        public frmtitolo()
        {
            InitializeComponent();
        }

        private void bxttabella_Click(object sender, EventArgs e)
        {

        }

        private void bxtmodificavalori_Click(object sender, EventArgs e)
        {
            display_tempi.Text = "";
            best_orari.Text = "";
            if (txtpartenza.Text == "Milano")
            {
                if (txtdestinazione.Text == "Milano")
                {
                    display_tempi.Text += orari[0][0];
                }

                if (txtdestinazione.Text == "Genova")
                {
                    display_tempi.Text += orari[0][1];
                }
                
                    if (txtdestinazione.Text == "Torino")
                {
                    display_tempi.Text += orari[0][2];
                }

                if (txtdestinazione.Text == "Bologna")
                {
                    display_tempi.Text += orari[0][3];
                }

            }

            if (txtpartenza.Text == "Genova")
            {
                if (txtdestinazione.Text == "Milano")
                {
                    display_tempi.Text += orari[1][0];
                }

                if (txtdestinazione.Text == "Genova")
                {
                    display_tempi.Text += orari[1][1];
                }

                if (txtdestinazione.Text == "Torino")
                {
                    display_tempi.Text += orari[1][2];
                }

                if (txtdestinazione.Text == "Bologna")
                {
                    display_tempi.Text += orari[1][3];
                }

            }

            if (txtpartenza.Text == "Torino")
            {
                if (txtdestinazione.Text == "Milano")
                {
                    display_tempi.Text += orari[2][0];
                }

                if (txtdestinazione.Text == "Genova")
                {
                    display_tempi.Text += orari[2][1];
                }

                if (txtdestinazione.Text == "Torino")
                {
                    display_tempi.Text += orari[2][2];
                }

                if (txtdestinazione.Text == "Bologna")
                {
                    double somma = orari[3][0] + orari[2][0];
                    double somma1 = orari[3][1] + orari[2][1];
                    display_tempi.Text += somma;
                    display_tempi.Text += " MIL /";
                    display_tempi.Text += somma1;
                    display_tempi.Text += " GEN";
                    best_orari.Text += somma1;
                }

            }

            if (txtpartenza.Text == "Bologna")
            {
                if (txtdestinazione.Text == "Milano")
                {
                    display_tempi.Text += orari[3][0];
                }

                if (txtdestinazione.Text == "Genova")
                {
                    display_tempi.Text += orari[3][1];
                }

                if (txtdestinazione.Text == "Torino")
                {
                    double somma = orari[3][0] + orari[0][2];
                    double somma1 = orari[3][1] + orari[1][2];
                    display_tempi.Text += somma;
                    display_tempi.Text += " MIL /";
                    display_tempi.Text += somma1;
                    display_tempi.Text += " GEN";
                    best_orari.Text += somma1;
                }

                if (txtdestinazione.Text == "Bologna")
                {
                    display_tempi.Text += orari[3][3];
                }

            }
        }//fine void

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

            displaygiallo.Text += "Tabella collegamenti/tempi autostradali";
            boxmilano.Text += "Milano";
            boxgenova.Text += "Genova";
            boxtorino.Text += "Torino";
            boxbologna.Text += "Bologna";
            txtboxmilano.Text += "Milano";
            txtboxgenova.Text += "Genova";
            txtboxtorino.Text += "Torino";
            txtboxbologna.Text += "Bologna";

            orari[0] = new double[] { 0, 3.50, 2.20, 4.10 };
            orari[1] = new double[] { 3.40, 0, 2.15, 3.30 };
            orari[2] = new double[] { 2, 2.10, 0,0   };
            orari[3] = new double[] { 3.50, 2.20,0,0   };

            txt00.Text += "" + orari[0][0];
            txt01.Text += "" + orari[0][1];
            txt02.Text += "" + orari[0][2];
            txt03.Text += "" + orari[0][3];

            txt10.Text += "" + orari[1][0];
            txt11.Text += "" + orari[1][1];
            txt12.Text += "" + orari[1][2];
            txt13.Text += "" + orari[1][3];

            txt20.Text += "" + orari[2][0];
            txt21.Text += "" + orari[2][1];
            txt22.Text += "" + orari[2][2];
            txt23.Text += "Null";

            txt30.Text += "" + orari[3][0];
            txt31.Text += "" + orari[3][1];
            txt32.Text += "Null";
            txt33.Text += "" + orari[3][3];

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtboxmilano_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpartenza_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void txt00_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bxtreset_Click(object sender, EventArgs e)
        {
            orari[0] = new double[] { 0, 3.50, 2.20, 4.10 };
            orari[1] = new double[] { 3.40, 0, 2.15, 3.30 };
            orari[2] = new double[] { 2, 2.10, 0, 0 };
            orari[3] = new double[] { 3.50, 2.20, 0, 0 };

            txt00.Text = "";
            txt01.Text = "";
            txt02.Text = "";
            txt03.Text = "";
            txt10.Text = "";
            txt11.Text = "";
            txt12.Text = "";
            txt13.Text = "";
            txt20.Text = "";
            txt21.Text = "";
            txt22.Text = "";
            txt23.Text = "";
            txt30.Text = "";
            txt31.Text = "";
            txt32.Text = "";
            txt33.Text = "";

            txt00.Text += "" + orari[0][0];
            txt01.Text += "" + orari[0][1];
            txt02.Text += "" + orari[0][2];
            txt03.Text += "" + orari[0][3];

            txt10.Text += "" + orari[1][0];
            txt11.Text += "" + orari[1][1];
            txt12.Text += "" + orari[1][2];
            txt13.Text += "" + orari[1][3];

            txt20.Text += "" + orari[2][0];
            txt21.Text += "" + orari[2][1];
            txt22.Text += "" + orari[2][2];
            txt23.Text += "Null";

            txt30.Text += "" + orari[3][0];
            txt31.Text += "" + orari[3][1];
            txt32.Text += "Null";
            txt33.Text += "" + orari[3][3];
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_visual.Checked == true)
            {
                grp_visual.Enabled = true;
            }
            else
                grp_visual.Enabled = false;
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void rd_modif_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_modif.Checked == true)
            {
               grpb_modif.Enabled = true;
            }
            else
                grpb_modif.Enabled = false;
        }

        private void Modificaval_Click(object sender, EventArgs e)
        {
            
            if (partezamodif.Text == "Milano")
            {
                if (destinazionemodif.Text == "Milano")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                }

                if (destinazionemodif.Text == "Genova")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[0][1] = Numero;
                }

                if (destinazionemodif.Text == "Torino")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[0][2] = Numero;
                }

                if (destinazionemodif.Text == "Bologna")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[0][3] = Numero;
                }
            }

            if (partezamodif.Text == "Genova")
            {
                if (destinazionemodif.Text == "Milano")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[1][0] = Numero;
                }

                if (destinazionemodif.Text == "Genova")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                }

                if (destinazionemodif.Text == "Torino")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[1][2] = Numero;
                }

                if (destinazionemodif.Text == "Bologna")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[1][3] = Numero;
                }
            }

            if (partezamodif.Text == "Torino")
            {
                if (destinazionemodif.Text == "Milano")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[2][0] = Numero;
                }

                if (destinazionemodif.Text == "Genova")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[2][1] = Numero;
                }

                if (destinazionemodif.Text == "Torino")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                }

                if (destinazionemodif.Text == "Bologna")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                }
            }

            if (partezamodif.Text == "Bologna")
            {
                if (destinazionemodif.Text == "Milano")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[3][0] = Numero;
                }

                if (destinazionemodif.Text == "Genova")
                {
                    double Numero = double.Parse(displaymodif.Text);
                    orari[3][1] = Numero;
                }

                if (destinazionemodif.Text == "Torino")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                }

                if (destinazionemodif.Text == "Bologna")
                {
                    displaymodif.Text = "";
                    displaymodif.Text += "Non disponibile";
                    
                }
            }
        }

        private void bxtcostruiscitabella_Click(object sender, EventArgs e)
        {
            txt00.Text = "";
            txt01.Text = "";
            txt02.Text = "";
            txt03.Text = "";
            txt10.Text = "";
            txt11.Text = "";
            txt12.Text = "";
            txt13.Text = "";
            txt20.Text = "";
            txt21.Text = "";
            txt22.Text = "";
            txt23.Text = "";
            txt30.Text = "";
            txt31.Text = "";
            txt32.Text = "";
            txt33.Text = "";


            txt00.Text += "" + orari[0][0];
            txt01.Text += "" + orari[0][1];
            txt02.Text += "" + orari[0][2];
            txt03.Text += "" + orari[0][3];

            txt10.Text += "" + orari[1][0];
            txt11.Text += "" + orari[1][1];
            txt12.Text += "" + orari[1][2];
            txt13.Text += "" + orari[1][3];

            txt20.Text += "" + orari[2][0];
            txt21.Text += "" + orari[2][1];
            txt22.Text += "" + orari[2][2];
            txt23.Text += "Null";

            txt30.Text += "" + orari[3][0];
            txt31.Text += "" + orari[3][1];
            txt32.Text += "Null";
            txt33.Text += "" + orari[3][3];
            
        }

        private void displaymodif_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt02_TextChanged(object sender, EventArgs e)
        {

        }

        private void best_orari_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt32_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt23_TextChanged(object sender, EventArgs e)
        {

        }//fine void
    }
}
