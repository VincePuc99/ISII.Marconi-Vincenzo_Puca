﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distributore_Bevande
{ 
    public partial class Form1 : Form
    {
        static int[] giacenza = new int[4] {3,5,5,1};
        static double cont = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            check_acqua.Checked = false;
            check_aranciata.Checked = false;
            check_cola.Checked = false;
            check_tèfreddo.Checked = false;

            txttotversa.Text = "0";

            txtdispoacqua.Text = ""+ giacenza[0];
            txtdispocola.Text = "" + giacenza[1];
            txtdispoara.Text = "" + giacenza[2];
            txtdispote.Text = "" + giacenza[3];

        }

        private void check_acqua_CheckedChanged(object sender, EventArgs e)
        {
            if (check_acqua.Checked == true)
            {
                bttprelacqua.Enabled = true;
            }
            else
                bttprelacqua.Enabled = false;
        }

        private void check_cola_CheckedChanged(object sender, EventArgs e)
        {
            if (check_cola.Checked == true)
            {
                bttprelcola.Enabled = true;
            }
            else
                bttprelcola.Enabled = false;
        }

        private void check_aranciata_CheckedChanged(object sender, EventArgs e)
        {
            if (check_aranciata.Checked == true)
            {
                bttprelarancia.Enabled = true; 
            }
            else
                bttprelarancia.Enabled = false;
        }

        private void check_tèfreddo_CheckedChanged(object sender, EventArgs e)
        {
            if (check_tèfreddo.Checked == true)
            {
                bttpreltefreddo.Enabled = true; 
            }
            else
                bttpreltefreddo.Enabled = false;
        }

        private void bttprelacqua_Click(object sender, EventArgs e)
        {
            if (giacenza[0] != 0)
            {
                giacenza[0] -= 1;
                cont += 2;
                txttotversa.Text = "" + cont;
            }
            
            if(giacenza[0] == 0)
            {
                bttprelacqua.Enabled = false;
                check_acqua.Enabled = false;
            }
         
               txtdispoacqua.Text = "" + giacenza[0];

        }

        private void bttprelcola_Click(object sender, EventArgs e)
        {
            if (giacenza[1] != 0)
            {
                giacenza[1] -= 1;
                cont += 2.50;
                txttotversa.Text = "" + cont;
            }

            if (giacenza[1] == 0)
            {
                bttprelcola.Enabled = false;
                check_cola.Enabled = false;
            }

            txtdispocola.Text = "" + giacenza[1];
        }

        private void bttprelarancia_Click(object sender, EventArgs e)
        {
            if (giacenza[2] != 0)
            {
                giacenza[2] -= 1;
                cont += 1.50;
                txttotversa.Text = "" + cont;
            }

            if (giacenza[2] == 0)
            {
                bttprelarancia.Enabled = false;
                check_aranciata.Enabled = false;
            }

            txtdispoara.Text = "" + giacenza[2];
        }

        private void bttpreltefreddo_Click(object sender, EventArgs e)
        {
            if (giacenza[3] != 0)
            {
                giacenza[3] -= 1;
                cont += 1.80;
                txttotversa.Text = "" + cont;
            }

            if (giacenza[3] == 0)
            {
                bttpreltefreddo.Enabled = false;
                check_tèfreddo.Enabled = false;
            }

            txtdispote.Text = "" + giacenza[3];
        }

        private void bttaccettapagam_Click(object sender, EventArgs e)
        {
            check_acqua.Checked = false;
            check_aranciata.Checked = false;
            check_cola.Checked = false;
            check_tèfreddo.Checked = false;

            check_acqua.Enabled = true;
            check_aranciata.Enabled = true;
            check_cola.Enabled = true;
            check_tèfreddo.Enabled = true;

            txttotversa.Text = "0";

            giacenza[0] = 3;
            giacenza[1] = 5;
            giacenza[2] = 5;
            giacenza[3] = 1;

            txtdispoacqua.Text = "" + giacenza[0];
            txtdispocola.Text = "" + giacenza[1];
            txtdispoara.Text = "" + giacenza[2];
            txtdispote.Text = "" + giacenza[3];

            cont = 0;
        }//fine void
    }
}
