﻿namespace Best_path
{
    partial class frmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_titologiallo = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtsupmilano = new System.Windows.Forms.TextBox();
            this.txtsupgenova = new System.Windows.Forms.TextBox();
            this.txtsuptorino = new System.Windows.Forms.TextBox();
            this.txtsupboologna = new System.Windows.Forms.TextBox();
            this.txtinfmilano = new System.Windows.Forms.TextBox();
            this.txtinfgenova = new System.Windows.Forms.TextBox();
            this.txtinftorino = new System.Windows.Forms.TextBox();
            this.txtinfbologna = new System.Windows.Forms.TextBox();
            this.txt00 = new System.Windows.Forms.TextBox();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.txt20 = new System.Windows.Forms.TextBox();
            this.txt30 = new System.Windows.Forms.TextBox();
            this.txt01 = new System.Windows.Forms.TextBox();
            this.txt11 = new System.Windows.Forms.TextBox();
            this.txt21 = new System.Windows.Forms.TextBox();
            this.txt31 = new System.Windows.Forms.TextBox();
            this.txt02 = new System.Windows.Forms.TextBox();
            this.txt12 = new System.Windows.Forms.TextBox();
            this.txt22 = new System.Windows.Forms.TextBox();
            this.txt32 = new System.Windows.Forms.TextBox();
            this.txt13 = new System.Windows.Forms.TextBox();
            this.txt03 = new System.Windows.Forms.TextBox();
            this.txt23 = new System.Windows.Forms.TextBox();
            this.txt33 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rdbtt_modifica = new System.Windows.Forms.RadioButton();
            this.rdbtt_cerca = new System.Windows.Forms.RadioButton();
            this.grpbx_cerca = new System.Windows.Forms.GroupBox();
            this.grpbx_modifica = new System.Windows.Forms.GroupBox();
            this.btt_ricerca = new System.Windows.Forms.Button();
            this.txt_ricercapartenza = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_ricercaarrivo = new System.Windows.Forms.TextBox();
            this.txt_orarioricercadisplay = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_orariobest = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_modifnuovotempo = new System.Windows.Forms.TextBox();
            this.btt_modifica = new System.Windows.Forms.Button();
            this.txt_modifarrivo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtmodif_partenza = new System.Windows.Forms.TextBox();
            this.btt_refresh = new System.Windows.Forms.Button();
            this.btt_reset = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.grpbx_cerca.SuspendLayout();
            this.grpbx_modifica.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_titologiallo
            // 
            this.txt_titologiallo.BackColor = System.Drawing.Color.Gold;
            this.txt_titologiallo.Location = new System.Drawing.Point(9, 19);
            this.txt_titologiallo.Multiline = true;
            this.txt_titologiallo.Name = "txt_titologiallo";
            this.txt_titologiallo.ReadOnly = true;
            this.txt_titologiallo.Size = new System.Drawing.Size(524, 24);
            this.txt_titologiallo.TabIndex = 0;
            this.txt_titologiallo.Text = "Tabella collegamenti/tempi autostradali";
            this.txt_titologiallo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(9, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "/\\/\\/\\/\\/\\/\\/\\/\\/\\";
            // 
            // txtsupmilano
            // 
            this.txtsupmilano.Location = new System.Drawing.Point(115, 49);
            this.txtsupmilano.Name = "txtsupmilano";
            this.txtsupmilano.ReadOnly = true;
            this.txtsupmilano.Size = new System.Drawing.Size(100, 20);
            this.txtsupmilano.TabIndex = 2;
            this.txtsupmilano.Text = "Milano";
            this.txtsupmilano.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtsupgenova
            // 
            this.txtsupgenova.Location = new System.Drawing.Point(221, 49);
            this.txtsupgenova.Name = "txtsupgenova";
            this.txtsupgenova.ReadOnly = true;
            this.txtsupgenova.Size = new System.Drawing.Size(100, 20);
            this.txtsupgenova.TabIndex = 3;
            this.txtsupgenova.Text = "Genova";
            this.txtsupgenova.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtsuptorino
            // 
            this.txtsuptorino.Location = new System.Drawing.Point(327, 49);
            this.txtsuptorino.Name = "txtsuptorino";
            this.txtsuptorino.ReadOnly = true;
            this.txtsuptorino.Size = new System.Drawing.Size(100, 20);
            this.txtsuptorino.TabIndex = 4;
            this.txtsuptorino.Text = "Torino";
            this.txtsuptorino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtsupboologna
            // 
            this.txtsupboologna.Location = new System.Drawing.Point(433, 49);
            this.txtsupboologna.Name = "txtsupboologna";
            this.txtsupboologna.ReadOnly = true;
            this.txtsupboologna.Size = new System.Drawing.Size(100, 20);
            this.txtsupboologna.TabIndex = 5;
            this.txtsupboologna.Text = "Bologna";
            this.txtsupboologna.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtinfmilano
            // 
            this.txtinfmilano.Location = new System.Drawing.Point(9, 75);
            this.txtinfmilano.Name = "txtinfmilano";
            this.txtinfmilano.ReadOnly = true;
            this.txtinfmilano.Size = new System.Drawing.Size(100, 20);
            this.txtinfmilano.TabIndex = 6;
            this.txtinfmilano.Text = "Milano";
            this.txtinfmilano.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtinfgenova
            // 
            this.txtinfgenova.Location = new System.Drawing.Point(9, 101);
            this.txtinfgenova.Name = "txtinfgenova";
            this.txtinfgenova.ReadOnly = true;
            this.txtinfgenova.Size = new System.Drawing.Size(100, 20);
            this.txtinfgenova.TabIndex = 7;
            this.txtinfgenova.Text = "Genova";
            this.txtinfgenova.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtinftorino
            // 
            this.txtinftorino.Location = new System.Drawing.Point(9, 127);
            this.txtinftorino.Name = "txtinftorino";
            this.txtinftorino.ReadOnly = true;
            this.txtinftorino.Size = new System.Drawing.Size(100, 20);
            this.txtinftorino.TabIndex = 8;
            this.txtinftorino.Text = "Torino";
            this.txtinftorino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtinfbologna
            // 
            this.txtinfbologna.Location = new System.Drawing.Point(9, 153);
            this.txtinfbologna.Name = "txtinfbologna";
            this.txtinfbologna.ReadOnly = true;
            this.txtinfbologna.Size = new System.Drawing.Size(100, 20);
            this.txtinfbologna.TabIndex = 9;
            this.txtinfbologna.Text = "Bologna";
            this.txtinfbologna.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt00
            // 
            this.txt00.Location = new System.Drawing.Point(115, 75);
            this.txt00.Name = "txt00";
            this.txt00.ReadOnly = true;
            this.txt00.Size = new System.Drawing.Size(100, 20);
            this.txt00.TabIndex = 10;
            // 
            // txt10
            // 
            this.txt10.Location = new System.Drawing.Point(115, 101);
            this.txt10.Name = "txt10";
            this.txt10.ReadOnly = true;
            this.txt10.Size = new System.Drawing.Size(100, 20);
            this.txt10.TabIndex = 11;
            // 
            // txt20
            // 
            this.txt20.Location = new System.Drawing.Point(115, 127);
            this.txt20.Name = "txt20";
            this.txt20.ReadOnly = true;
            this.txt20.Size = new System.Drawing.Size(100, 20);
            this.txt20.TabIndex = 12;
            // 
            // txt30
            // 
            this.txt30.Location = new System.Drawing.Point(115, 153);
            this.txt30.Name = "txt30";
            this.txt30.ReadOnly = true;
            this.txt30.Size = new System.Drawing.Size(100, 20);
            this.txt30.TabIndex = 13;
            // 
            // txt01
            // 
            this.txt01.Location = new System.Drawing.Point(221, 75);
            this.txt01.Name = "txt01";
            this.txt01.ReadOnly = true;
            this.txt01.Size = new System.Drawing.Size(100, 20);
            this.txt01.TabIndex = 14;
            // 
            // txt11
            // 
            this.txt11.Location = new System.Drawing.Point(221, 101);
            this.txt11.Name = "txt11";
            this.txt11.ReadOnly = true;
            this.txt11.Size = new System.Drawing.Size(100, 20);
            this.txt11.TabIndex = 15;
            // 
            // txt21
            // 
            this.txt21.Location = new System.Drawing.Point(221, 127);
            this.txt21.Name = "txt21";
            this.txt21.ReadOnly = true;
            this.txt21.Size = new System.Drawing.Size(100, 20);
            this.txt21.TabIndex = 16;
            // 
            // txt31
            // 
            this.txt31.Location = new System.Drawing.Point(221, 153);
            this.txt31.Name = "txt31";
            this.txt31.ReadOnly = true;
            this.txt31.Size = new System.Drawing.Size(100, 20);
            this.txt31.TabIndex = 17;
            // 
            // txt02
            // 
            this.txt02.Location = new System.Drawing.Point(327, 75);
            this.txt02.Name = "txt02";
            this.txt02.ReadOnly = true;
            this.txt02.Size = new System.Drawing.Size(100, 20);
            this.txt02.TabIndex = 18;
            // 
            // txt12
            // 
            this.txt12.Location = new System.Drawing.Point(327, 101);
            this.txt12.Name = "txt12";
            this.txt12.ReadOnly = true;
            this.txt12.Size = new System.Drawing.Size(100, 20);
            this.txt12.TabIndex = 19;
            // 
            // txt22
            // 
            this.txt22.Location = new System.Drawing.Point(327, 127);
            this.txt22.Name = "txt22";
            this.txt22.ReadOnly = true;
            this.txt22.Size = new System.Drawing.Size(100, 20);
            this.txt22.TabIndex = 20;
            // 
            // txt32
            // 
            this.txt32.Location = new System.Drawing.Point(327, 153);
            this.txt32.Name = "txt32";
            this.txt32.ReadOnly = true;
            this.txt32.Size = new System.Drawing.Size(100, 20);
            this.txt32.TabIndex = 21;
            // 
            // txt13
            // 
            this.txt13.Location = new System.Drawing.Point(433, 101);
            this.txt13.Name = "txt13";
            this.txt13.ReadOnly = true;
            this.txt13.Size = new System.Drawing.Size(100, 20);
            this.txt13.TabIndex = 22;
            // 
            // txt03
            // 
            this.txt03.Location = new System.Drawing.Point(433, 75);
            this.txt03.Name = "txt03";
            this.txt03.ReadOnly = true;
            this.txt03.Size = new System.Drawing.Size(100, 20);
            this.txt03.TabIndex = 23;
            // 
            // txt23
            // 
            this.txt23.Location = new System.Drawing.Point(433, 127);
            this.txt23.Name = "txt23";
            this.txt23.ReadOnly = true;
            this.txt23.Size = new System.Drawing.Size(100, 20);
            this.txt23.TabIndex = 24;
            // 
            // txt33
            // 
            this.txt33.Location = new System.Drawing.Point(433, 153);
            this.txt33.Name = "txt33";
            this.txt33.ReadOnly = true;
            this.txt33.Size = new System.Drawing.Size(100, 20);
            this.txt33.TabIndex = 25;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt01);
            this.groupBox1.Controls.Add(this.txt33);
            this.groupBox1.Controls.Add(this.txt_titologiallo);
            this.groupBox1.Controls.Add(this.txt23);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.txt03);
            this.groupBox1.Controls.Add(this.txtsupmilano);
            this.groupBox1.Controls.Add(this.txt13);
            this.groupBox1.Controls.Add(this.txtsupgenova);
            this.groupBox1.Controls.Add(this.txt32);
            this.groupBox1.Controls.Add(this.txtsuptorino);
            this.groupBox1.Controls.Add(this.txt22);
            this.groupBox1.Controls.Add(this.txtsupboologna);
            this.groupBox1.Controls.Add(this.txt12);
            this.groupBox1.Controls.Add(this.txtinfmilano);
            this.groupBox1.Controls.Add(this.txt02);
            this.groupBox1.Controls.Add(this.txtinfgenova);
            this.groupBox1.Controls.Add(this.txt31);
            this.groupBox1.Controls.Add(this.txtinftorino);
            this.groupBox1.Controls.Add(this.txt21);
            this.groupBox1.Controls.Add(this.txtinfbologna);
            this.groupBox1.Controls.Add(this.txt11);
            this.groupBox1.Controls.Add(this.txt00);
            this.groupBox1.Controls.Add(this.txt10);
            this.groupBox1.Controls.Add(this.txt30);
            this.groupBox1.Controls.Add(this.txt20);
            this.groupBox1.Location = new System.Drawing.Point(10, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(543, 185);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tabella";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(563, 391);
            this.shapeContainer1.TabIndex = 27;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = -7;
            this.lineShape1.X2 = 578;
            this.lineShape1.Y1 = 205;
            this.lineShape1.Y2 = 205;
            // 
            // rdbtt_modifica
            // 
            this.rdbtt_modifica.AutoSize = true;
            this.rdbtt_modifica.Location = new System.Drawing.Point(212, 208);
            this.rdbtt_modifica.Name = "rdbtt_modifica";
            this.rdbtt_modifica.Size = new System.Drawing.Size(88, 17);
            this.rdbtt_modifica.TabIndex = 28;
            this.rdbtt_modifica.Text = "Modifica orari";
            this.rdbtt_modifica.UseVisualStyleBackColor = true;
            this.rdbtt_modifica.CheckedChanged += new System.EventHandler(this.rd_btt_CheckedChanged);
            // 
            // rdbtt_cerca
            // 
            this.rdbtt_cerca.AutoSize = true;
            this.rdbtt_cerca.Checked = true;
            this.rdbtt_cerca.Location = new System.Drawing.Point(121, 208);
            this.rdbtt_cerca.Name = "rdbtt_cerca";
            this.rdbtt_cerca.Size = new System.Drawing.Size(85, 17);
            this.rdbtt_cerca.TabIndex = 29;
            this.rdbtt_cerca.TabStop = true;
            this.rdbtt_cerca.Text = "Ricerca orari";
            this.rdbtt_cerca.UseVisualStyleBackColor = true;
            this.rdbtt_cerca.CheckedChanged += new System.EventHandler(this.rdbtt_cerca_CheckedChanged);
            // 
            // grpbx_cerca
            // 
            this.grpbx_cerca.Controls.Add(this.label4);
            this.grpbx_cerca.Controls.Add(this.txt_orariobest);
            this.grpbx_cerca.Controls.Add(this.label3);
            this.grpbx_cerca.Controls.Add(this.txt_orarioricercadisplay);
            this.grpbx_cerca.Controls.Add(this.btt_ricerca);
            this.grpbx_cerca.Controls.Add(this.txt_ricercaarrivo);
            this.grpbx_cerca.Controls.Add(this.label2);
            this.grpbx_cerca.Controls.Add(this.label1);
            this.grpbx_cerca.Controls.Add(this.txt_ricercapartenza);
            this.grpbx_cerca.Location = new System.Drawing.Point(12, 231);
            this.grpbx_cerca.Name = "grpbx_cerca";
            this.grpbx_cerca.Size = new System.Drawing.Size(194, 148);
            this.grpbx_cerca.TabIndex = 30;
            this.grpbx_cerca.TabStop = false;
            this.grpbx_cerca.Text = "Ricerca orari";
            // 
            // grpbx_modifica
            // 
            this.grpbx_modifica.Controls.Add(this.label6);
            this.grpbx_modifica.Controls.Add(this.txt_modifnuovotempo);
            this.grpbx_modifica.Controls.Add(this.btt_modifica);
            this.grpbx_modifica.Controls.Add(this.txt_modifarrivo);
            this.grpbx_modifica.Controls.Add(this.label7);
            this.grpbx_modifica.Controls.Add(this.label8);
            this.grpbx_modifica.Controls.Add(this.txtmodif_partenza);
            this.grpbx_modifica.Enabled = false;
            this.grpbx_modifica.Location = new System.Drawing.Point(212, 231);
            this.grpbx_modifica.Name = "grpbx_modifica";
            this.grpbx_modifica.Size = new System.Drawing.Size(194, 111);
            this.grpbx_modifica.TabIndex = 31;
            this.grpbx_modifica.TabStop = false;
            this.grpbx_modifica.Text = "Modifica orari";
            // 
            // btt_ricerca
            // 
            this.btt_ricerca.Location = new System.Drawing.Point(107, 65);
            this.btt_ricerca.Name = "btt_ricerca";
            this.btt_ricerca.Size = new System.Drawing.Size(75, 38);
            this.btt_ricerca.TabIndex = 0;
            this.btt_ricerca.Text = "Visualizza orario";
            this.btt_ricerca.UseVisualStyleBackColor = true;
            this.btt_ricerca.Click += new System.EventHandler(this.btt_ricerca_Click);
            // 
            // txt_ricercapartenza
            // 
            this.txt_ricercapartenza.Location = new System.Drawing.Point(6, 36);
            this.txt_ricercapartenza.Name = "txt_ricercapartenza";
            this.txt_ricercapartenza.Size = new System.Drawing.Size(81, 20);
            this.txt_ricercapartenza.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Partenza";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Arrivo";
            // 
            // txt_ricercaarrivo
            // 
            this.txt_ricercaarrivo.Location = new System.Drawing.Point(101, 36);
            this.txt_ricercaarrivo.Name = "txt_ricercaarrivo";
            this.txt_ricercaarrivo.Size = new System.Drawing.Size(81, 20);
            this.txt_ricercaarrivo.TabIndex = 3;
            // 
            // txt_orarioricercadisplay
            // 
            this.txt_orarioricercadisplay.Location = new System.Drawing.Point(6, 75);
            this.txt_orarioricercadisplay.Name = "txt_orarioricercadisplay";
            this.txt_orarioricercadisplay.ReadOnly = true;
            this.txt_orarioricercadisplay.Size = new System.Drawing.Size(95, 20);
            this.txt_orarioricercadisplay.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tempo";
            // 
            // txt_orariobest
            // 
            this.txt_orariobest.Location = new System.Drawing.Point(6, 114);
            this.txt_orariobest.Name = "txt_orariobest";
            this.txt_orariobest.ReadOnly = true;
            this.txt_orariobest.Size = new System.Drawing.Size(95, 20);
            this.txt_orariobest.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tempo best";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Nuovo tempo";
            // 
            // txt_modifnuovotempo
            // 
            this.txt_modifnuovotempo.Location = new System.Drawing.Point(12, 75);
            this.txt_modifnuovotempo.Name = "txt_modifnuovotempo";
            this.txt_modifnuovotempo.Size = new System.Drawing.Size(81, 20);
            this.txt_modifnuovotempo.TabIndex = 13;
            // 
            // btt_modifica
            // 
            this.btt_modifica.Location = new System.Drawing.Point(99, 62);
            this.btt_modifica.Name = "btt_modifica";
            this.btt_modifica.Size = new System.Drawing.Size(81, 38);
            this.btt_modifica.TabIndex = 8;
            this.btt_modifica.Text = "Modifica orario";
            this.btt_modifica.UseVisualStyleBackColor = true;
            this.btt_modifica.Click += new System.EventHandler(this.btt_modifica_Click);
            // 
            // txt_modifarrivo
            // 
            this.txt_modifarrivo.Location = new System.Drawing.Point(12, 36);
            this.txt_modifarrivo.Name = "txt_modifarrivo";
            this.txt_modifarrivo.Size = new System.Drawing.Size(81, 20);
            this.txt_modifarrivo.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(96, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Arrivo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Partenza";
            // 
            // txtmodif_partenza
            // 
            this.txtmodif_partenza.Location = new System.Drawing.Point(99, 36);
            this.txtmodif_partenza.Name = "txtmodif_partenza";
            this.txtmodif_partenza.Size = new System.Drawing.Size(81, 20);
            this.txtmodif_partenza.TabIndex = 9;
            // 
            // btt_refresh
            // 
            this.btt_refresh.Location = new System.Drawing.Point(212, 348);
            this.btt_refresh.Name = "btt_refresh";
            this.btt_refresh.Size = new System.Drawing.Size(119, 23);
            this.btt_refresh.TabIndex = 32;
            this.btt_refresh.Text = "Refresh Tabella";
            this.btt_refresh.UseVisualStyleBackColor = true;
            this.btt_refresh.Click += new System.EventHandler(this.btt_refresh_Click);
            // 
            // btt_reset
            // 
            this.btt_reset.Location = new System.Drawing.Point(337, 348);
            this.btt_reset.Name = "btt_reset";
            this.btt_reset.Size = new System.Drawing.Size(69, 23);
            this.btt_reset.TabIndex = 33;
            this.btt_reset.Text = "Reset";
            this.btt_reset.UseVisualStyleBackColor = true;
            this.btt_reset.Click += new System.EventHandler(this.btt_reset_Click);
            // 
            // frmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 391);
            this.Controls.Add(this.btt_reset);
            this.Controls.Add(this.btt_refresh);
            this.Controls.Add(this.grpbx_modifica);
            this.Controls.Add(this.grpbx_cerca);
            this.Controls.Add(this.rdbtt_cerca);
            this.Controls.Add(this.rdbtt_modifica);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.shapeContainer1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "frmain";
            this.Text = "Tempi di percorrenza";
            this.Load += new System.EventHandler(this.frmain_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpbx_cerca.ResumeLayout(false);
            this.grpbx_cerca.PerformLayout();
            this.grpbx_modifica.ResumeLayout(false);
            this.grpbx_modifica.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_titologiallo;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtsupmilano;
        private System.Windows.Forms.TextBox txtsupgenova;
        private System.Windows.Forms.TextBox txtsuptorino;
        private System.Windows.Forms.TextBox txtsupboologna;
        private System.Windows.Forms.TextBox txtinfmilano;
        private System.Windows.Forms.TextBox txtinfgenova;
        private System.Windows.Forms.TextBox txtinftorino;
        private System.Windows.Forms.TextBox txtinfbologna;
        private System.Windows.Forms.TextBox txt00;
        private System.Windows.Forms.TextBox txt10;
        private System.Windows.Forms.TextBox txt20;
        private System.Windows.Forms.TextBox txt30;
        private System.Windows.Forms.TextBox txt01;
        private System.Windows.Forms.TextBox txt11;
        private System.Windows.Forms.TextBox txt21;
        private System.Windows.Forms.TextBox txt31;
        private System.Windows.Forms.TextBox txt02;
        private System.Windows.Forms.TextBox txt12;
        private System.Windows.Forms.TextBox txt22;
        private System.Windows.Forms.TextBox txt32;
        private System.Windows.Forms.TextBox txt13;
        private System.Windows.Forms.TextBox txt03;
        private System.Windows.Forms.TextBox txt23;
        private System.Windows.Forms.TextBox txt33;
        private System.Windows.Forms.GroupBox groupBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.RadioButton rdbtt_modifica;
        private System.Windows.Forms.RadioButton rdbtt_cerca;
        private System.Windows.Forms.GroupBox grpbx_cerca;
        private System.Windows.Forms.GroupBox grpbx_modifica;
        private System.Windows.Forms.Button btt_ricerca;
        private System.Windows.Forms.TextBox txt_ricercaarrivo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_ricercapartenza;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_orariobest;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_orarioricercadisplay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_modifnuovotempo;
        private System.Windows.Forms.Button btt_modifica;
        private System.Windows.Forms.TextBox txt_modifarrivo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtmodif_partenza;
        private System.Windows.Forms.Button btt_refresh;
        private System.Windows.Forms.Button btt_reset;
    }
}

