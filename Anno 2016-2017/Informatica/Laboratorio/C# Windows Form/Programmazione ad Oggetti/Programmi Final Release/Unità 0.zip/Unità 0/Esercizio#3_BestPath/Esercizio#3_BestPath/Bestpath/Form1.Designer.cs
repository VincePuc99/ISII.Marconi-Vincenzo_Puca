﻿namespace Bestpath
{
    partial class frmtitolo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmtitolo));
            this.bxtcostruiscitabella = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.displaygiallo = new System.Windows.Forms.TextBox();
            this.txt33 = new System.Windows.Forms.TextBox();
            this.txt23 = new System.Windows.Forms.TextBox();
            this.txt13 = new System.Windows.Forms.TextBox();
            this.boxmilano = new System.Windows.Forms.TextBox();
            this.txtboxbologna = new System.Windows.Forms.TextBox();
            this.boxtorino = new System.Windows.Forms.TextBox();
            this.txt31 = new System.Windows.Forms.TextBox();
            this.txt03 = new System.Windows.Forms.TextBox();
            this.txt21 = new System.Windows.Forms.TextBox();
            this.boxbologna = new System.Windows.Forms.TextBox();
            this.txt32 = new System.Windows.Forms.TextBox();
            this.txt22 = new System.Windows.Forms.TextBox();
            this.txt11 = new System.Windows.Forms.TextBox();
            this.txt12 = new System.Windows.Forms.TextBox();
            this.txt02 = new System.Windows.Forms.TextBox();
            this.txt01 = new System.Windows.Forms.TextBox();
            this.boxgenova = new System.Windows.Forms.TextBox();
            this.txtboxtorino = new System.Windows.Forms.TextBox();
            this.txtboxgenova = new System.Windows.Forms.TextBox();
            this.txtboxmilano = new System.Windows.Forms.TextBox();
            this.txtvuoto = new System.Windows.Forms.TextBox();
            this.txt00 = new System.Windows.Forms.TextBox();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.txt30 = new System.Windows.Forms.TextBox();
            this.txt20 = new System.Windows.Forms.TextBox();
            this.bxtmodificavalori = new System.Windows.Forms.Button();
            this.bxtreset = new System.Windows.Forms.Button();
            this.grbpartenza = new System.Windows.Forms.GroupBox();
            this.txtpartenza = new System.Windows.Forms.TextBox();
            this.grpdestinazione = new System.Windows.Forms.GroupBox();
            this.txtdestinazione = new System.Windows.Forms.TextBox();
            this.display_tempi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.Linea_separatoria = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rd_modif = new System.Windows.Forms.RadioButton();
            this.rd_visual = new System.Windows.Forms.RadioButton();
            this.grp_visual = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.best_orari = new System.Windows.Forms.TextBox();
            this.grpb_modif = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.partezamodif = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.destinazionemodif = new System.Windows.Forms.TextBox();
            this.Modificaval = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.displaymodif = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            this.grbpartenza.SuspendLayout();
            this.grpdestinazione.SuspendLayout();
            this.grp_visual.SuspendLayout();
            this.grpb_modif.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // bxtcostruiscitabella
            // 
            this.bxtcostruiscitabella.Location = new System.Drawing.Point(293, 370);
            this.bxtcostruiscitabella.Name = "bxtcostruiscitabella";
            this.bxtcostruiscitabella.Size = new System.Drawing.Size(149, 27);
            this.bxtcostruiscitabella.TabIndex = 2;
            this.bxtcostruiscitabella.Text = "Re-fresh Tabella";
            this.bxtcostruiscitabella.UseVisualStyleBackColor = true;
            this.bxtcostruiscitabella.Click += new System.EventHandler(this.bxtcostruiscitabella_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.displaygiallo);
            this.groupBox1.Controls.Add(this.txt33);
            this.groupBox1.Controls.Add(this.txt23);
            this.groupBox1.Controls.Add(this.txt13);
            this.groupBox1.Controls.Add(this.boxmilano);
            this.groupBox1.Controls.Add(this.txtboxbologna);
            this.groupBox1.Controls.Add(this.boxtorino);
            this.groupBox1.Controls.Add(this.txt31);
            this.groupBox1.Controls.Add(this.txt03);
            this.groupBox1.Controls.Add(this.txt21);
            this.groupBox1.Controls.Add(this.boxbologna);
            this.groupBox1.Controls.Add(this.txt32);
            this.groupBox1.Controls.Add(this.txt22);
            this.groupBox1.Controls.Add(this.txt11);
            this.groupBox1.Controls.Add(this.txt12);
            this.groupBox1.Controls.Add(this.txt02);
            this.groupBox1.Controls.Add(this.txt01);
            this.groupBox1.Controls.Add(this.boxgenova);
            this.groupBox1.Controls.Add(this.txtboxtorino);
            this.groupBox1.Controls.Add(this.txtboxgenova);
            this.groupBox1.Controls.Add(this.txtboxmilano);
            this.groupBox1.Controls.Add(this.txtvuoto);
            this.groupBox1.Controls.Add(this.txt00);
            this.groupBox1.Controls.Add(this.txt10);
            this.groupBox1.Controls.Add(this.txt30);
            this.groupBox1.Controls.Add(this.txt20);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(554, 189);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Visualizza Tabella";
            // 
            // displaygiallo
            // 
            this.displaygiallo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(216)))), ((int)(((byte)(55)))));
            this.displaygiallo.Location = new System.Drawing.Point(14, 19);
            this.displaygiallo.Multiline = true;
            this.displaygiallo.Name = "displaygiallo";
            this.displaygiallo.ReadOnly = true;
            this.displaygiallo.Size = new System.Drawing.Size(529, 28);
            this.displaygiallo.TabIndex = 12;
            this.displaygiallo.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // txt33
            // 
            this.txt33.Location = new System.Drawing.Point(443, 157);
            this.txt33.Multiline = true;
            this.txt33.Name = "txt33";
            this.txt33.ReadOnly = true;
            this.txt33.Size = new System.Drawing.Size(100, 20);
            this.txt33.TabIndex = 13;
            // 
            // txt23
            // 
            this.txt23.Location = new System.Drawing.Point(443, 131);
            this.txt23.Multiline = true;
            this.txt23.Name = "txt23";
            this.txt23.ReadOnly = true;
            this.txt23.Size = new System.Drawing.Size(100, 20);
            this.txt23.TabIndex = 24;
            this.txt23.TextChanged += new System.EventHandler(this.txt23_TextChanged);
            // 
            // txt13
            // 
            this.txt13.Location = new System.Drawing.Point(443, 105);
            this.txt13.Multiline = true;
            this.txt13.Name = "txt13";
            this.txt13.ReadOnly = true;
            this.txt13.Size = new System.Drawing.Size(100, 20);
            this.txt13.TabIndex = 25;
            // 
            // boxmilano
            // 
            this.boxmilano.Location = new System.Drawing.Point(120, 53);
            this.boxmilano.Multiline = true;
            this.boxmilano.Name = "boxmilano";
            this.boxmilano.ReadOnly = true;
            this.boxmilano.Size = new System.Drawing.Size(100, 20);
            this.boxmilano.TabIndex = 26;
            this.boxmilano.TextChanged += new System.EventHandler(this.textBox21_TextChanged);
            // 
            // txtboxbologna
            // 
            this.txtboxbologna.Location = new System.Drawing.Point(14, 157);
            this.txtboxbologna.Multiline = true;
            this.txtboxbologna.Name = "txtboxbologna";
            this.txtboxbologna.ReadOnly = true;
            this.txtboxbologna.Size = new System.Drawing.Size(100, 20);
            this.txtboxbologna.TabIndex = 27;
            // 
            // boxtorino
            // 
            this.boxtorino.Location = new System.Drawing.Point(337, 53);
            this.boxtorino.Multiline = true;
            this.boxtorino.Name = "boxtorino";
            this.boxtorino.ReadOnly = true;
            this.boxtorino.Size = new System.Drawing.Size(100, 20);
            this.boxtorino.TabIndex = 18;
            this.boxtorino.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // txt31
            // 
            this.txt31.Location = new System.Drawing.Point(231, 157);
            this.txt31.Multiline = true;
            this.txt31.Name = "txt31";
            this.txt31.ReadOnly = true;
            this.txt31.Size = new System.Drawing.Size(100, 20);
            this.txt31.TabIndex = 19;
            // 
            // txt03
            // 
            this.txt03.Location = new System.Drawing.Point(443, 79);
            this.txt03.Multiline = true;
            this.txt03.Name = "txt03";
            this.txt03.ReadOnly = true;
            this.txt03.Size = new System.Drawing.Size(100, 20);
            this.txt03.TabIndex = 11;
            // 
            // txt21
            // 
            this.txt21.Location = new System.Drawing.Point(231, 131);
            this.txt21.Multiline = true;
            this.txt21.Name = "txt21";
            this.txt21.ReadOnly = true;
            this.txt21.Size = new System.Drawing.Size(100, 20);
            this.txt21.TabIndex = 20;
            this.txt21.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // boxbologna
            // 
            this.boxbologna.Location = new System.Drawing.Point(443, 53);
            this.boxbologna.Multiline = true;
            this.boxbologna.Name = "boxbologna";
            this.boxbologna.ReadOnly = true;
            this.boxbologna.Size = new System.Drawing.Size(100, 20);
            this.boxbologna.TabIndex = 6;
            this.boxbologna.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt32
            // 
            this.txt32.Location = new System.Drawing.Point(337, 157);
            this.txt32.Multiline = true;
            this.txt32.Name = "txt32";
            this.txt32.ReadOnly = true;
            this.txt32.Size = new System.Drawing.Size(100, 20);
            this.txt32.TabIndex = 7;
            this.txt32.TextChanged += new System.EventHandler(this.txt32_TextChanged);
            // 
            // txt22
            // 
            this.txt22.Location = new System.Drawing.Point(337, 131);
            this.txt22.Multiline = true;
            this.txt22.Name = "txt22";
            this.txt22.ReadOnly = true;
            this.txt22.Size = new System.Drawing.Size(100, 20);
            this.txt22.TabIndex = 10;
            // 
            // txt11
            // 
            this.txt11.Location = new System.Drawing.Point(231, 105);
            this.txt11.Multiline = true;
            this.txt11.Name = "txt11";
            this.txt11.ReadOnly = true;
            this.txt11.Size = new System.Drawing.Size(100, 20);
            this.txt11.TabIndex = 21;
            // 
            // txt12
            // 
            this.txt12.Location = new System.Drawing.Point(337, 105);
            this.txt12.Multiline = true;
            this.txt12.Name = "txt12";
            this.txt12.ReadOnly = true;
            this.txt12.Size = new System.Drawing.Size(100, 20);
            this.txt12.TabIndex = 8;
            // 
            // txt02
            // 
            this.txt02.Location = new System.Drawing.Point(337, 79);
            this.txt02.Multiline = true;
            this.txt02.Name = "txt02";
            this.txt02.ReadOnly = true;
            this.txt02.Size = new System.Drawing.Size(100, 20);
            this.txt02.TabIndex = 9;
            this.txt02.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            // 
            // txt01
            // 
            this.txt01.Location = new System.Drawing.Point(231, 79);
            this.txt01.Multiline = true;
            this.txt01.Name = "txt01";
            this.txt01.ReadOnly = true;
            this.txt01.Size = new System.Drawing.Size(100, 20);
            this.txt01.TabIndex = 22;
            // 
            // boxgenova
            // 
            this.boxgenova.Location = new System.Drawing.Point(231, 53);
            this.boxgenova.Multiline = true;
            this.boxgenova.Name = "boxgenova";
            this.boxgenova.ReadOnly = true;
            this.boxgenova.Size = new System.Drawing.Size(100, 20);
            this.boxgenova.TabIndex = 23;
            this.boxgenova.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // txtboxtorino
            // 
            this.txtboxtorino.Location = new System.Drawing.Point(14, 131);
            this.txtboxtorino.Multiline = true;
            this.txtboxtorino.Name = "txtboxtorino";
            this.txtboxtorino.ReadOnly = true;
            this.txtboxtorino.Size = new System.Drawing.Size(100, 20);
            this.txtboxtorino.TabIndex = 28;
            // 
            // txtboxgenova
            // 
            this.txtboxgenova.Location = new System.Drawing.Point(14, 105);
            this.txtboxgenova.Multiline = true;
            this.txtboxgenova.Name = "txtboxgenova";
            this.txtboxgenova.ReadOnly = true;
            this.txtboxgenova.Size = new System.Drawing.Size(100, 20);
            this.txtboxgenova.TabIndex = 29;
            // 
            // txtboxmilano
            // 
            this.txtboxmilano.Location = new System.Drawing.Point(14, 79);
            this.txtboxmilano.Multiline = true;
            this.txtboxmilano.Name = "txtboxmilano";
            this.txtboxmilano.ReadOnly = true;
            this.txtboxmilano.Size = new System.Drawing.Size(100, 20);
            this.txtboxmilano.TabIndex = 30;
            this.txtboxmilano.TextChanged += new System.EventHandler(this.txtboxmilano_TextChanged);
            // 
            // txtvuoto
            // 
            this.txtvuoto.Location = new System.Drawing.Point(14, 53);
            this.txtvuoto.Multiline = true;
            this.txtvuoto.Name = "txtvuoto";
            this.txtvuoto.ReadOnly = true;
            this.txtvuoto.Size = new System.Drawing.Size(100, 20);
            this.txtvuoto.TabIndex = 31;
            this.txtvuoto.TextChanged += new System.EventHandler(this.textBox26_TextChanged);
            // 
            // txt00
            // 
            this.txt00.Location = new System.Drawing.Point(120, 79);
            this.txt00.Multiline = true;
            this.txt00.Name = "txt00";
            this.txt00.ReadOnly = true;
            this.txt00.Size = new System.Drawing.Size(100, 20);
            this.txt00.TabIndex = 16;
            this.txt00.TextChanged += new System.EventHandler(this.txt00_TextChanged);
            // 
            // txt10
            // 
            this.txt10.Location = new System.Drawing.Point(120, 105);
            this.txt10.Multiline = true;
            this.txt10.Name = "txt10";
            this.txt10.ReadOnly = true;
            this.txt10.Size = new System.Drawing.Size(100, 20);
            this.txt10.TabIndex = 15;
            // 
            // txt30
            // 
            this.txt30.Location = new System.Drawing.Point(120, 157);
            this.txt30.Multiline = true;
            this.txt30.Name = "txt30";
            this.txt30.ReadOnly = true;
            this.txt30.Size = new System.Drawing.Size(100, 20);
            this.txt30.TabIndex = 17;
            this.txt30.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // txt20
            // 
            this.txt20.Location = new System.Drawing.Point(120, 131);
            this.txt20.Multiline = true;
            this.txt20.Name = "txt20";
            this.txt20.ReadOnly = true;
            this.txt20.Size = new System.Drawing.Size(100, 20);
            this.txt20.TabIndex = 14;
            this.txt20.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // bxtmodificavalori
            // 
            this.bxtmodificavalori.Location = new System.Drawing.Point(142, 85);
            this.bxtmodificavalori.Name = "bxtmodificavalori";
            this.bxtmodificavalori.Size = new System.Drawing.Size(103, 27);
            this.bxtmodificavalori.TabIndex = 3;
            this.bxtmodificavalori.Text = "Visualizza Valori";
            this.bxtmodificavalori.UseVisualStyleBackColor = true;
            this.bxtmodificavalori.Click += new System.EventHandler(this.bxtmodificavalori_Click);
            // 
            // bxtreset
            // 
            this.bxtreset.Location = new System.Drawing.Point(455, 370);
            this.bxtreset.Name = "bxtreset";
            this.bxtreset.Size = new System.Drawing.Size(68, 27);
            this.bxtreset.TabIndex = 4;
            this.bxtreset.Text = "Reset";
            this.bxtreset.UseVisualStyleBackColor = true;
            this.bxtreset.Click += new System.EventHandler(this.bxtreset_Click);
            // 
            // grbpartenza
            // 
            this.grbpartenza.Controls.Add(this.txtpartenza);
            this.grbpartenza.Location = new System.Drawing.Point(6, 19);
            this.grbpartenza.Name = "grbpartenza";
            this.grbpartenza.Size = new System.Drawing.Size(124, 54);
            this.grbpartenza.TabIndex = 4;
            this.grbpartenza.TabStop = false;
            this.grbpartenza.Text = "Località di partenza";
            // 
            // txtpartenza
            // 
            this.txtpartenza.Location = new System.Drawing.Point(6, 26);
            this.txtpartenza.Multiline = true;
            this.txtpartenza.Name = "txtpartenza";
            this.txtpartenza.Size = new System.Drawing.Size(103, 19);
            this.txtpartenza.TabIndex = 0;
            this.txtpartenza.TextChanged += new System.EventHandler(this.txtpartenza_TextChanged);
            // 
            // grpdestinazione
            // 
            this.grpdestinazione.Controls.Add(this.txtdestinazione);
            this.grpdestinazione.Location = new System.Drawing.Point(136, 19);
            this.grpdestinazione.Name = "grpdestinazione";
            this.grpdestinazione.Size = new System.Drawing.Size(124, 54);
            this.grpdestinazione.TabIndex = 5;
            this.grpdestinazione.TabStop = false;
            this.grpdestinazione.Text = "Località di destinazione";
            // 
            // txtdestinazione
            // 
            this.txtdestinazione.Location = new System.Drawing.Point(6, 26);
            this.txtdestinazione.Multiline = true;
            this.txtdestinazione.Name = "txtdestinazione";
            this.txtdestinazione.Size = new System.Drawing.Size(103, 19);
            this.txtdestinazione.TabIndex = 1;
            // 
            // display_tempi
            // 
            this.display_tempi.Location = new System.Drawing.Point(17, 92);
            this.display_tempi.Name = "display_tempi";
            this.display_tempi.ReadOnly = true;
            this.display_tempi.Size = new System.Drawing.Size(100, 20);
            this.display_tempi.TabIndex = 6;
            this.display_tempi.TabStop = false;
            this.display_tempi.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tempi di percorrenza";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.Linea_separatoria});
            this.shapeContainer1.Size = new System.Drawing.Size(578, 419);
            this.shapeContainer1.TabIndex = 8;
            this.shapeContainer1.TabStop = false;
            // 
            // Linea_separatoria
            // 
            this.Linea_separatoria.BorderColor = System.Drawing.Color.Maroon;
            this.Linea_separatoria.Name = "Linea_separatoria";
            this.Linea_separatoria.SelectionColor = System.Drawing.Color.Green;
            this.Linea_separatoria.X1 = -3;
            this.Linea_separatoria.X2 = 591;
            this.Linea_separatoria.Y1 = 210;
            this.Linea_separatoria.Y2 = 210;
            // 
            // rd_modif
            // 
            this.rd_modif.AutoSize = true;
            this.rd_modif.Location = new System.Drawing.Point(299, 219);
            this.rd_modif.Name = "rd_modif";
            this.rd_modif.Size = new System.Drawing.Size(94, 17);
            this.rd_modif.TabIndex = 9;
            this.rd_modif.Text = "Modifica Valori";
            this.rd_modif.UseVisualStyleBackColor = true;
            this.rd_modif.CheckedChanged += new System.EventHandler(this.rd_modif_CheckedChanged);
            // 
            // rd_visual
            // 
            this.rd_visual.AutoSize = true;
            this.rd_visual.Checked = true;
            this.rd_visual.Location = new System.Drawing.Point(187, 219);
            this.rd_visual.Name = "rd_visual";
            this.rd_visual.Size = new System.Drawing.Size(100, 17);
            this.rd_visual.TabIndex = 10;
            this.rd_visual.TabStop = true;
            this.rd_visual.Text = "Visualizza Valori";
            this.rd_visual.UseVisualStyleBackColor = true;
            this.rd_visual.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // grp_visual
            // 
            this.grp_visual.Controls.Add(this.label3);
            this.grp_visual.Controls.Add(this.best_orari);
            this.grp_visual.Controls.Add(this.grbpartenza);
            this.grp_visual.Controls.Add(this.grpdestinazione);
            this.grp_visual.Controls.Add(this.bxtmodificavalori);
            this.grp_visual.Controls.Add(this.label1);
            this.grp_visual.Controls.Add(this.display_tempi);
            this.grp_visual.Location = new System.Drawing.Point(12, 238);
            this.grp_visual.Name = "grp_visual";
            this.grp_visual.Size = new System.Drawing.Size(275, 159);
            this.grp_visual.TabIndex = 11;
            this.grp_visual.TabStop = false;
            this.grp_visual.Text = "Visualizza";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Best";
            // 
            // best_orari
            // 
            this.best_orari.Location = new System.Drawing.Point(17, 132);
            this.best_orari.Name = "best_orari";
            this.best_orari.ReadOnly = true;
            this.best_orari.Size = new System.Drawing.Size(100, 20);
            this.best_orari.TabIndex = 8;
            this.best_orari.TextChanged += new System.EventHandler(this.best_orari_TextChanged);
            // 
            // grpb_modif
            // 
            this.grpb_modif.Controls.Add(this.groupBox3);
            this.grpb_modif.Controls.Add(this.groupBox4);
            this.grpb_modif.Controls.Add(this.Modificaval);
            this.grpb_modif.Controls.Add(this.label2);
            this.grpb_modif.Controls.Add(this.displaymodif);
            this.grpb_modif.Enabled = false;
            this.grpb_modif.Location = new System.Drawing.Point(293, 238);
            this.grpb_modif.Name = "grpb_modif";
            this.grpb_modif.Size = new System.Drawing.Size(275, 126);
            this.grpb_modif.TabIndex = 12;
            this.grpb_modif.TabStop = false;
            this.grpb_modif.Text = "Modifica";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.partezamodif);
            this.groupBox3.Location = new System.Drawing.Point(6, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(124, 54);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Località di partenza";
            // 
            // partezamodif
            // 
            this.partezamodif.Location = new System.Drawing.Point(6, 26);
            this.partezamodif.Multiline = true;
            this.partezamodif.Name = "partezamodif";
            this.partezamodif.Size = new System.Drawing.Size(103, 19);
            this.partezamodif.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.destinazionemodif);
            this.groupBox4.Location = new System.Drawing.Point(136, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(124, 54);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Località di destinazione";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // destinazionemodif
            // 
            this.destinazionemodif.Location = new System.Drawing.Point(6, 26);
            this.destinazionemodif.Multiline = true;
            this.destinazionemodif.Name = "destinazionemodif";
            this.destinazionemodif.Size = new System.Drawing.Size(103, 19);
            this.destinazionemodif.TabIndex = 1;
            this.destinazionemodif.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Modificaval
            // 
            this.Modificaval.Location = new System.Drawing.Point(142, 85);
            this.Modificaval.Name = "Modificaval";
            this.Modificaval.Size = new System.Drawing.Size(103, 27);
            this.Modificaval.TabIndex = 3;
            this.Modificaval.Text = "Modifica Valori";
            this.Modificaval.UseVisualStyleBackColor = true;
            this.Modificaval.Click += new System.EventHandler(this.Modificaval_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nuovo orario";
            // 
            // displaymodif
            // 
            this.displaymodif.Location = new System.Drawing.Point(17, 92);
            this.displaymodif.Name = "displaymodif";
            this.displaymodif.Size = new System.Drawing.Size(100, 20);
            this.displaymodif.TabIndex = 6;
            this.displaymodif.TabStop = false;
            this.displaymodif.TextChanged += new System.EventHandler(this.displaymodif_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this.shapeContainer1;
            this.errorProvider1.Tag = "errore";
            // 
            // frmtitolo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 419);
            this.Controls.Add(this.grpb_modif);
            this.Controls.Add(this.grp_visual);
            this.Controls.Add(this.rd_visual);
            this.Controls.Add(this.rd_modif);
            this.Controls.Add(this.bxtreset);
            this.Controls.Add(this.bxtcostruiscitabella);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.shapeContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmtitolo";
            this.Text = "Collegamenti & Tempi autostradali";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grbpartenza.ResumeLayout(false);
            this.grbpartenza.PerformLayout();
            this.grpdestinazione.ResumeLayout(false);
            this.grpdestinazione.PerformLayout();
            this.grp_visual.ResumeLayout(false);
            this.grp_visual.PerformLayout();
            this.grpb_modif.ResumeLayout(false);
            this.grpb_modif.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bxtcostruiscitabella;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bxtmodificavalori;
        private System.Windows.Forms.TextBox boxmilano;
        private System.Windows.Forms.TextBox txtboxbologna;
        private System.Windows.Forms.TextBox txtboxtorino;
        private System.Windows.Forms.TextBox txtboxgenova;
        private System.Windows.Forms.TextBox txtboxmilano;
        private System.Windows.Forms.TextBox txtvuoto;
        private System.Windows.Forms.Button bxtreset;
        private System.Windows.Forms.GroupBox grbpartenza;
        private System.Windows.Forms.TextBox txt13;
        private System.Windows.Forms.TextBox txt23;
        private System.Windows.Forms.TextBox boxgenova;
        private System.Windows.Forms.TextBox txt01;
        private System.Windows.Forms.TextBox txt11;
        private System.Windows.Forms.TextBox txt21;
        private System.Windows.Forms.TextBox txt31;
        private System.Windows.Forms.TextBox boxtorino;
        private System.Windows.Forms.TextBox txt30;
        private System.Windows.Forms.TextBox txt00;
        private System.Windows.Forms.TextBox txt10;
        private System.Windows.Forms.TextBox txt20;
        private System.Windows.Forms.TextBox txt33;
        private System.Windows.Forms.TextBox displaygiallo;
        private System.Windows.Forms.TextBox txt03;
        private System.Windows.Forms.TextBox txt22;
        private System.Windows.Forms.TextBox txt02;
        private System.Windows.Forms.TextBox txt12;
        private System.Windows.Forms.TextBox txt32;
        private System.Windows.Forms.TextBox boxbologna;
        private System.Windows.Forms.GroupBox grpdestinazione;
        private System.Windows.Forms.TextBox txtpartenza;
        private System.Windows.Forms.TextBox txtdestinazione;
        private System.Windows.Forms.TextBox display_tempi;
        private System.Windows.Forms.Label label1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape Linea_separatoria;
        private System.Windows.Forms.RadioButton rd_modif;
        private System.Windows.Forms.RadioButton rd_visual;
        private System.Windows.Forms.GroupBox grp_visual;
        private System.Windows.Forms.GroupBox grpb_modif;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox partezamodif;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox destinazionemodif;
        private System.Windows.Forms.Button Modificaval;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox displaymodif;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox best_orari;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

