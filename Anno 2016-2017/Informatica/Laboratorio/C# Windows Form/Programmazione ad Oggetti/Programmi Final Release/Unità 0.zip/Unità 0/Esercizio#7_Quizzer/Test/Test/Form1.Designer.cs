﻿namespace Test
{
    partial class frmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmain));
            this.grp_modalita = new System.Windows.Forms.GroupBox();
            this.btt_avvia = new System.Windows.Forms.Button();
            this.rad_man = new System.Windows.Forms.RadioButton();
            this.rad_auto = new System.Windows.Forms.RadioButton();
            this.grp_domande = new System.Windows.Forms.GroupBox();
            this.btt_successivo = new System.Windows.Forms.Button();
            this.btt_precedente = new System.Windows.Forms.Button();
            this.txt_displaydomade = new System.Windows.Forms.TextBox();
            this.grp_risposte = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btt_confermarsip = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.prgbar_tempo = new System.Windows.Forms.ProgressBar();
            this.lst_risposte = new System.Windows.Forms.ListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btt_valutaprova = new System.Windows.Forms.Button();
            this.txt_displayvoto = new System.Windows.Forms.TextBox();
            this.tmr_automatica = new System.Windows.Forms.Timer(this.components);
            this.grp_modalita.SuspendLayout();
            this.grp_domande.SuspendLayout();
            this.grp_risposte.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp_modalita
            // 
            this.grp_modalita.Controls.Add(this.btt_avvia);
            this.grp_modalita.Controls.Add(this.rad_man);
            this.grp_modalita.Controls.Add(this.rad_auto);
            this.grp_modalita.Location = new System.Drawing.Point(12, 12);
            this.grp_modalita.Name = "grp_modalita";
            this.grp_modalita.Size = new System.Drawing.Size(163, 73);
            this.grp_modalita.TabIndex = 0;
            this.grp_modalita.TabStop = false;
            this.grp_modalita.Text = "Modalità Questionario";
            // 
            // btt_avvia
            // 
            this.btt_avvia.Location = new System.Drawing.Point(6, 42);
            this.btt_avvia.Name = "btt_avvia";
            this.btt_avvia.Size = new System.Drawing.Size(150, 23);
            this.btt_avvia.TabIndex = 2;
            this.btt_avvia.Text = "Avvia Questionario";
            this.btt_avvia.UseVisualStyleBackColor = true;
            this.btt_avvia.Click += new System.EventHandler(this.btt_avvia_Click);
            // 
            // rad_man
            // 
            this.rad_man.AutoSize = true;
            this.rad_man.Location = new System.Drawing.Point(90, 19);
            this.rad_man.Name = "rad_man";
            this.rad_man.Size = new System.Drawing.Size(66, 17);
            this.rad_man.TabIndex = 1;
            this.rad_man.TabStop = true;
            this.rad_man.Text = "Manuale";
            this.rad_man.UseVisualStyleBackColor = true;
            // 
            // rad_auto
            // 
            this.rad_auto.AutoSize = true;
            this.rad_auto.Location = new System.Drawing.Point(6, 19);
            this.rad_auto.Name = "rad_auto";
            this.rad_auto.Size = new System.Drawing.Size(78, 17);
            this.rad_auto.TabIndex = 0;
            this.rad_auto.TabStop = true;
            this.rad_auto.Text = "Automatica";
            this.rad_auto.UseVisualStyleBackColor = true;
            // 
            // grp_domande
            // 
            this.grp_domande.Controls.Add(this.btt_successivo);
            this.grp_domande.Controls.Add(this.btt_precedente);
            this.grp_domande.Controls.Add(this.txt_displaydomade);
            this.grp_domande.Location = new System.Drawing.Point(12, 91);
            this.grp_domande.Name = "grp_domande";
            this.grp_domande.Size = new System.Drawing.Size(217, 76);
            this.grp_domande.TabIndex = 1;
            this.grp_domande.TabStop = false;
            this.grp_domande.Text = "Quesito";
            // 
            // btt_successivo
            // 
            this.btt_successivo.Enabled = false;
            this.btt_successivo.Location = new System.Drawing.Point(111, 46);
            this.btt_successivo.Name = "btt_successivo";
            this.btt_successivo.Size = new System.Drawing.Size(98, 23);
            this.btt_successivo.TabIndex = 2;
            this.btt_successivo.Text = "Successivo -->";
            this.btt_successivo.UseVisualStyleBackColor = true;
            this.btt_successivo.Click += new System.EventHandler(this.btt_successivo_Click);
            // 
            // btt_precedente
            // 
            this.btt_precedente.Enabled = false;
            this.btt_precedente.Location = new System.Drawing.Point(7, 46);
            this.btt_precedente.Name = "btt_precedente";
            this.btt_precedente.Size = new System.Drawing.Size(98, 23);
            this.btt_precedente.TabIndex = 1;
            this.btt_precedente.Text = "<-- Precedente";
            this.btt_precedente.UseVisualStyleBackColor = true;
            this.btt_precedente.Click += new System.EventHandler(this.btt_precedente_Click);
            // 
            // txt_displaydomade
            // 
            this.txt_displaydomade.Location = new System.Drawing.Point(7, 20);
            this.txt_displaydomade.Name = "txt_displaydomade";
            this.txt_displaydomade.ReadOnly = true;
            this.txt_displaydomade.Size = new System.Drawing.Size(202, 20);
            this.txt_displaydomade.TabIndex = 0;
            // 
            // grp_risposte
            // 
            this.grp_risposte.Controls.Add(this.label2);
            this.grp_risposte.Controls.Add(this.btt_confermarsip);
            this.grp_risposte.Controls.Add(this.label1);
            this.grp_risposte.Controls.Add(this.prgbar_tempo);
            this.grp_risposte.Controls.Add(this.lst_risposte);
            this.grp_risposte.Location = new System.Drawing.Point(12, 173);
            this.grp_risposte.Name = "grp_risposte";
            this.grp_risposte.Size = new System.Drawing.Size(255, 142);
            this.grp_risposte.TabIndex = 1;
            this.grp_risposte.TabStop = false;
            this.grp_risposte.Text = "Possibili risposte";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Seleziona la risposta e premi \"Conferma\"";
            // 
            // btt_confermarsip
            // 
            this.btt_confermarsip.Enabled = false;
            this.btt_confermarsip.Location = new System.Drawing.Point(149, 111);
            this.btt_confermarsip.Name = "btt_confermarsip";
            this.btt_confermarsip.Size = new System.Drawing.Size(98, 23);
            this.btt_confermarsip.TabIndex = 3;
            this.btt_confermarsip.Text = "Conferma";
            this.btt_confermarsip.UseVisualStyleBackColor = true;
            this.btt_confermarsip.Click += new System.EventHandler(this.btt_confermarsip_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(146, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tempo";
            // 
            // prgbar_tempo
            // 
            this.prgbar_tempo.Location = new System.Drawing.Point(149, 64);
            this.prgbar_tempo.Maximum = 5;
            this.prgbar_tempo.Name = "prgbar_tempo";
            this.prgbar_tempo.Size = new System.Drawing.Size(100, 23);
            this.prgbar_tempo.TabIndex = 4;
            this.prgbar_tempo.Click += new System.EventHandler(this.prgbar_tempo_Click);
            // 
            // lst_risposte
            // 
            this.lst_risposte.FormattingEnabled = true;
            this.lst_risposte.Location = new System.Drawing.Point(7, 39);
            this.lst_risposte.Name = "lst_risposte";
            this.lst_risposte.Size = new System.Drawing.Size(136, 95);
            this.lst_risposte.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.btt_valutaprova);
            this.groupBox4.Controls.Add(this.txt_displayvoto);
            this.groupBox4.Location = new System.Drawing.Point(12, 321);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(173, 74);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Valutazione";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Voto -->";
            // 
            // btt_valutaprova
            // 
            this.btt_valutaprova.Enabled = false;
            this.btt_valutaprova.Location = new System.Drawing.Point(9, 39);
            this.btt_valutaprova.Name = "btt_valutaprova";
            this.btt_valutaprova.Size = new System.Drawing.Size(96, 23);
            this.btt_valutaprova.TabIndex = 1;
            this.btt_valutaprova.Text = "Valuta la prova";
            this.btt_valutaprova.UseVisualStyleBackColor = true;
            this.btt_valutaprova.Click += new System.EventHandler(this.btt_valutaprova_Click);
            // 
            // txt_displayvoto
            // 
            this.txt_displayvoto.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_displayvoto.Location = new System.Drawing.Point(115, 19);
            this.txt_displayvoto.Multiline = true;
            this.txt_displayvoto.Name = "txt_displayvoto";
            this.txt_displayvoto.ReadOnly = true;
            this.txt_displayvoto.Size = new System.Drawing.Size(48, 43);
            this.txt_displayvoto.TabIndex = 0;
            // 
            // tmr_automatica
            // 
            this.tmr_automatica.Interval = 1000;
            this.tmr_automatica.Tick += new System.EventHandler(this.tmr_automatica_Tick);
            // 
            // frmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 399);
            this.Controls.Add(this.grp_domande);
            this.Controls.Add(this.grp_risposte);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.grp_modalita);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmain";
            this.Text = "Quizzer V1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grp_modalita.ResumeLayout(false);
            this.grp_modalita.PerformLayout();
            this.grp_domande.ResumeLayout(false);
            this.grp_domande.PerformLayout();
            this.grp_risposte.ResumeLayout(false);
            this.grp_risposte.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_modalita;
        private System.Windows.Forms.Button btt_avvia;
        private System.Windows.Forms.RadioButton rad_man;
        private System.Windows.Forms.RadioButton rad_auto;
        private System.Windows.Forms.GroupBox grp_domande;
        private System.Windows.Forms.GroupBox grp_risposte;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btt_successivo;
        private System.Windows.Forms.Button btt_precedente;
        private System.Windows.Forms.TextBox txt_displaydomade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar prgbar_tempo;
        private System.Windows.Forms.Button btt_confermarsip;
        private System.Windows.Forms.ListBox lst_risposte;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btt_valutaprova;
        private System.Windows.Forms.TextBox txt_displayvoto;
        private System.Windows.Forms.Timer tmr_automatica;
    }
}

