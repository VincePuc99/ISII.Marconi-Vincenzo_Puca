﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calcolatrice
{
    
    public partial class Form1 : Form
    {
        static string s;
        static string fine;
        static bool operandopiu = true;
        static bool operandomeno = true;
        static bool operandoper = true;
        static bool operandodiviso = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_display.Text += "2";
        }

        private void btt_1_Click(object sender, EventArgs e)
        {
            txt_display.Text += "1";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btt_3_Click(object sender, EventArgs e)
        {
            txt_display.Text += "3";

        }

        private void btt_4_Click(object sender, EventArgs e)
        {
            txt_display.Text += "4";
        }

        private void btt_5_Click(object sender, EventArgs e)
        {
            txt_display.Text += "5";
        }

        private void btt_6_Click(object sender, EventArgs e)
        {
            txt_display.Text += "6";
        }

        private void btt_7_Click(object sender, EventArgs e)
        {
            txt_display.Text += "7";
        }

        private void btt_8_Click(object sender, EventArgs e)
        {
            txt_display.Text += "8";
        }

        private void btt_9_Click(object sender, EventArgs e)
        {
            txt_display.Text += "9";
        }

        private void btt_0_Click(object sender, EventArgs e)
        {
            txt_display.Text += "0";
        }

        private void btt_canc_Click(object sender, EventArgs e)
        {
            txt_display.Clear();
        }

        private void btt_plus_Click(object sender, EventArgs e)
        {
       
            s = txt_display.Text;
            operandopiu = false;
            txt_display.Clear();
        }

        private void btt_meno_Click(object sender, EventArgs e)
        {
           
            s = txt_display.Text;
            operandomeno = false;
            txt_display.Clear();
        }

        private void btt_per_Click(object sender, EventArgs e)
        {
            
            s = txt_display.Text;
            operandoper = false;
            txt_display.Clear();
        }

        private void btt_diviso_Click(object sender, EventArgs e)
        {
           
            s = txt_display.Text;
            operandodiviso = false;
            txt_display.Clear();
        }

        private void btt_equal_Click(object sender, EventArgs e)
        {
            fine = txt_display.Text;
            double numero = double.Parse(s);
            double numero1 = double.Parse(fine);
            double tot = 0;
            if (operandopiu ==false)
            {
                tot = numero + numero1;
            }

            if (operandomeno == false)
            {
                tot = numero - numero1;
            }

            if (operandoper==false)
            {
                tot = numero * numero1;
            }

            if (operandodiviso == false)
            {
                tot = numero / numero1;
            }

            string d = "" + tot;
            txt_display.Text = d;

            tot = 0;
            operandodiviso = true;
            operandomeno = true;
            operandoper = true;
            operandopiu = true;
            numero1 = 0;
            numero = 0;

        }

        private void btt_comma_Click(object sender, EventArgs e)
        {
            txt_display.Text += ",";
        }

        private void button1_Click(object sender, EventArgs e)
        {
          txt_display.Text = txt_display.Text.Remove(txt_display.Text.Length-1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
