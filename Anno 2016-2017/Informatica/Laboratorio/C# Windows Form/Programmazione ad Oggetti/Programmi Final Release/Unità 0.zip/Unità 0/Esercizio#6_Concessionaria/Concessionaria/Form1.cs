﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concessionaria
{
    public partial class Form1 : Form
    {
        static int nuovotot;
       static int totale;
        static int percentuale;
        static int s;
        public Form1()
        {
            InitializeComponent();
            totale = 0;
            percentuale = 0;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btt_acquista_Click(object sender, EventArgs e)
        {
            if (rdbtt_mercedes.Checked == true)
            {
                totale += 40000;
                if (chk_vernice.Checked == true)
                {
                    totale += 300;
                }

                if (chk_antifurto.Checked == true)
                {
                    totale += 400;
                }

                if (chk_satellitare.Checked == true)
                {
                    totale += 800;
                }

                if (chk_cerchi.Checked == true)
                {
                    totale += 200;
                }
            }

            if (rdbtt_audi.Checked == true)
            {
                totale += 30000;
                if (chk_vernice.Checked == true)
                {
                    totale += 300;
                }

                if (chk_antifurto.Checked == true)
                {
                    totale += 400;
                }

                if (chk_satellitare.Checked == true)
                {
                    totale += 800;
                }

                if (chk_cerchi.Checked == true)
                {
                    totale += 200;
                }
            }

            if (rdbtt_ford.Checked == true)
            {
                totale += 20000;
                if (chk_vernice.Checked == true)
                {
                    totale += 300;
                }

                if (chk_antifurto.Checked == true)
                {
                    totale += 400;
                }

                if (chk_satellitare.Checked == true)
                {
                    totale += 800;
                }

                if (chk_cerchi.Checked == true)
                {
                    totale += 200;
                }
            }


            percentuale = Int32.Parse(txt_sconto.Text);

            s = (totale * percentuale) /100;
            nuovotot = totale - s;    

            txt_prezzo.Text = "" + nuovotot;
            totale = 0;
            nuovotot = 0;
            s = 0;
        }//fine void

        private void btt_reset_Click(object sender, EventArgs e)
        {
            txt_prezzo.Text = "";
            txt_sconto.Text = "";
            totale = 0;
            s = 0;
            nuovotot = 0;
            rdbtt_mercedes.Checked = true;
            chk_antifurto.Checked = false;
            chk_satellitare.Checked = false;
            chk_cerchi.Checked = false;
            chk_vernice.Checked = false;
        }
    }
}
