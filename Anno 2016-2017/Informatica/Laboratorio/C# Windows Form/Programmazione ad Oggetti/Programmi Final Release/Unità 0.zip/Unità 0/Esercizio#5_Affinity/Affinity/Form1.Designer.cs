﻿namespace Affinity
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_età_lui = new System.Windows.Forms.TextBox();
            this.chbx_lettura_lui = new System.Windows.Forms.CheckBox();
            this.cmbx_titoli_lui = new System.Windows.Forms.ComboBox();
            this.chk_viaggi_lui = new System.Windows.Forms.CheckBox();
            this.chk_sport_lui = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_età_lei = new System.Windows.Forms.TextBox();
            this.chbx_lettura_lei = new System.Windows.Forms.CheckBox();
            this.cmbx_titoli_lei = new System.Windows.Forms.ComboBox();
            this.chk_viaggi_lei = new System.Windows.Forms.CheckBox();
            this.chk_sport_lei = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bttt_verifica = new System.Windows.Forms.Button();
            this.prgrss_bar = new System.Windows.Forms.ProgressBar();
            this.txt_percentuale = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btt_reset = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btt_Chiudi = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_età_lui);
            this.groupBox1.Controls.Add(this.chbx_lettura_lui);
            this.groupBox1.Controls.Add(this.cmbx_titoli_lui);
            this.groupBox1.Controls.Add(this.chk_viaggi_lui);
            this.groupBox1.Controls.Add(this.chk_sport_lui);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(7, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(199, 102);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lui";
            // 
            // txt_età_lui
            // 
            this.txt_età_lui.Location = new System.Drawing.Point(5, 35);
            this.txt_età_lui.Name = "txt_età_lui";
            this.txt_età_lui.Size = new System.Drawing.Size(87, 20);
            this.txt_età_lui.TabIndex = 9;
            // 
            // chbx_lettura_lui
            // 
            this.chbx_lettura_lui.AutoSize = true;
            this.chbx_lettura_lui.Location = new System.Drawing.Point(125, 75);
            this.chbx_lettura_lui.Name = "chbx_lettura_lui";
            this.chbx_lettura_lui.Size = new System.Drawing.Size(59, 17);
            this.chbx_lettura_lui.TabIndex = 8;
            this.chbx_lettura_lui.Text = "Lettura";
            this.chbx_lettura_lui.UseVisualStyleBackColor = true;
            // 
            // cmbx_titoli_lui
            // 
            this.cmbx_titoli_lui.FormattingEnabled = true;
            this.cmbx_titoli_lui.Items.AddRange(new object[] {
            "Licenza media",
            "Diploma",
            "Laurea"});
            this.cmbx_titoli_lui.Location = new System.Drawing.Point(98, 35);
            this.cmbx_titoli_lui.Name = "cmbx_titoli_lui";
            this.cmbx_titoli_lui.Size = new System.Drawing.Size(92, 21);
            this.cmbx_titoli_lui.TabIndex = 7;
            // 
            // chk_viaggi_lui
            // 
            this.chk_viaggi_lui.AutoSize = true;
            this.chk_viaggi_lui.Location = new System.Drawing.Point(9, 75);
            this.chk_viaggi_lui.Name = "chk_viaggi_lui";
            this.chk_viaggi_lui.Size = new System.Drawing.Size(55, 17);
            this.chk_viaggi_lui.TabIndex = 6;
            this.chk_viaggi_lui.Text = "Viaggi";
            this.chk_viaggi_lui.UseVisualStyleBackColor = true;
            // 
            // chk_sport_lui
            // 
            this.chk_sport_lui.AutoSize = true;
            this.chk_sport_lui.Location = new System.Drawing.Point(70, 75);
            this.chk_sport_lui.Name = "chk_sport_lui";
            this.chk_sport_lui.Size = new System.Drawing.Size(51, 17);
            this.chk_sport_lui.TabIndex = 5;
            this.chk_sport_lui.Text = "Sport";
            this.chk_sport_lui.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Interessi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Titolo di studio";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Età";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_età_lei);
            this.groupBox2.Controls.Add(this.chbx_lettura_lei);
            this.groupBox2.Controls.Add(this.cmbx_titoli_lei);
            this.groupBox2.Controls.Add(this.chk_viaggi_lei);
            this.groupBox2.Controls.Add(this.chk_sport_lei);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(212, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(198, 102);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lei";
            // 
            // txt_età_lei
            // 
            this.txt_età_lei.Location = new System.Drawing.Point(5, 35);
            this.txt_età_lei.Name = "txt_età_lei";
            this.txt_età_lei.Size = new System.Drawing.Size(87, 20);
            this.txt_età_lei.TabIndex = 10;
            // 
            // chbx_lettura_lei
            // 
            this.chbx_lettura_lei.AutoSize = true;
            this.chbx_lettura_lei.Location = new System.Drawing.Point(122, 75);
            this.chbx_lettura_lei.Name = "chbx_lettura_lei";
            this.chbx_lettura_lei.Size = new System.Drawing.Size(59, 17);
            this.chbx_lettura_lei.TabIndex = 9;
            this.chbx_lettura_lei.Text = "Lettura";
            this.chbx_lettura_lei.UseVisualStyleBackColor = true;
            // 
            // cmbx_titoli_lei
            // 
            this.cmbx_titoli_lei.FormattingEnabled = true;
            this.cmbx_titoli_lei.Items.AddRange(new object[] {
            "Licenza media",
            "Diploma",
            "Laurea"});
            this.cmbx_titoli_lei.Location = new System.Drawing.Point(98, 35);
            this.cmbx_titoli_lei.Name = "cmbx_titoli_lei";
            this.cmbx_titoli_lei.Size = new System.Drawing.Size(92, 21);
            this.cmbx_titoli_lei.TabIndex = 7;
            // 
            // chk_viaggi_lei
            // 
            this.chk_viaggi_lei.AutoSize = true;
            this.chk_viaggi_lei.Location = new System.Drawing.Point(9, 75);
            this.chk_viaggi_lei.Name = "chk_viaggi_lei";
            this.chk_viaggi_lei.Size = new System.Drawing.Size(55, 17);
            this.chk_viaggi_lei.TabIndex = 6;
            this.chk_viaggi_lei.Text = "Viaggi";
            this.chk_viaggi_lei.UseVisualStyleBackColor = true;
            // 
            // chk_sport_lei
            // 
            this.chk_sport_lei.AutoSize = true;
            this.chk_sport_lei.Location = new System.Drawing.Point(70, 75);
            this.chk_sport_lei.Name = "chk_sport_lei";
            this.chk_sport_lei.Size = new System.Drawing.Size(51, 17);
            this.chk_sport_lei.TabIndex = 5;
            this.chk_sport_lei.Text = "Sport";
            this.chk_sport_lei.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Interessi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(95, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Titolo di studio";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Età";
            // 
            // bttt_verifica
            // 
            this.bttt_verifica.Location = new System.Drawing.Point(154, 108);
            this.bttt_verifica.Name = "bttt_verifica";
            this.bttt_verifica.Size = new System.Drawing.Size(100, 23);
            this.bttt_verifica.TabIndex = 9;
            this.bttt_verifica.Text = "Verifica Affinità";
            this.bttt_verifica.UseVisualStyleBackColor = true;
            this.bttt_verifica.Click += new System.EventHandler(this.bttt_verifica_Click);
            // 
            // prgrss_bar
            // 
            this.prgrss_bar.Location = new System.Drawing.Point(194, 137);
            this.prgrss_bar.Maximum = 125;
            this.prgrss_bar.Name = "prgrss_bar";
            this.prgrss_bar.Size = new System.Drawing.Size(208, 50);
            this.prgrss_bar.TabIndex = 10;
            // 
            // txt_percentuale
            // 
            this.txt_percentuale.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_percentuale.Location = new System.Drawing.Point(77, 137);
            this.txt_percentuale.Multiline = true;
            this.txt_percentuale.Name = "txt_percentuale";
            this.txt_percentuale.ReadOnly = true;
            this.txt_percentuale.Size = new System.Drawing.Size(111, 50);
            this.txt_percentuale.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Livello di ";
            // 
            // btt_reset
            // 
            this.btt_reset.Location = new System.Drawing.Point(260, 108);
            this.btt_reset.Name = "btt_reset";
            this.btt_reset.Size = new System.Drawing.Size(75, 23);
            this.btt_reset.TabIndex = 13;
            this.btt_reset.Text = "Reset";
            this.btt_reset.UseVisualStyleBackColor = true;
            this.btt_reset.Click += new System.EventHandler(this.btt_reset_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Affinità";
            // 
            // btt_Chiudi
            // 
            this.btt_Chiudi.Location = new System.Drawing.Point(73, 108);
            this.btt_Chiudi.Name = "btt_Chiudi";
            this.btt_Chiudi.Size = new System.Drawing.Size(75, 23);
            this.btt_Chiudi.TabIndex = 15;
            this.btt_Chiudi.Text = "Chiudi";
            this.btt_Chiudi.UseVisualStyleBackColor = true;
            this.btt_Chiudi.Click += new System.EventHandler(this.Chiudi_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(416, 192);
            this.Controls.Add(this.btt_Chiudi);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btt_reset);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_percentuale);
            this.Controls.Add(this.prgrss_bar);
            this.Controls.Add(this.bttt_verifica);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Affinity";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chbx_lettura_lui;
        private System.Windows.Forms.ComboBox cmbx_titoli_lui;
        private System.Windows.Forms.CheckBox chk_viaggi_lui;
        private System.Windows.Forms.CheckBox chk_sport_lui;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chbx_lettura_lei;
        private System.Windows.Forms.ComboBox cmbx_titoli_lei;
        private System.Windows.Forms.CheckBox chk_viaggi_lei;
        private System.Windows.Forms.CheckBox chk_sport_lei;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bttt_verifica;
        private System.Windows.Forms.ProgressBar prgrss_bar;
        private System.Windows.Forms.TextBox txt_percentuale;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_età_lui;
        private System.Windows.Forms.TextBox txt_età_lei;
        private System.Windows.Forms.Button btt_reset;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btt_Chiudi;
    }
}

