﻿namespace Distributore_Bevande
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grpbx_preliev = new System.Windows.Forms.GroupBox();
            this.grbx_Pagame = new System.Windows.Forms.GroupBox();
            this.check_acqua = new System.Windows.Forms.CheckBox();
            this.check_cola = new System.Windows.Forms.CheckBox();
            this.check_aranciata = new System.Windows.Forms.CheckBox();
            this.check_tèfreddo = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtdispoacqua = new System.Windows.Forms.TextBox();
            this.txtdispocola = new System.Windows.Forms.TextBox();
            this.txtdispoara = new System.Windows.Forms.TextBox();
            this.txtdispote = new System.Windows.Forms.TextBox();
            this.bttprelacqua = new System.Windows.Forms.Button();
            this.bttprelcola = new System.Windows.Forms.Button();
            this.bttprelarancia = new System.Windows.Forms.Button();
            this.bttpreltefreddo = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.bttaccettapagam = new System.Windows.Forms.Button();
            this.txttotversa = new System.Windows.Forms.TextBox();
            this.grpbx_preliev.SuspendLayout();
            this.grbx_Pagame.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbx_preliev
            // 
            this.grpbx_preliev.Controls.Add(this.bttpreltefreddo);
            this.grpbx_preliev.Controls.Add(this.bttprelarancia);
            this.grpbx_preliev.Controls.Add(this.bttprelcola);
            this.grpbx_preliev.Controls.Add(this.bttprelacqua);
            this.grpbx_preliev.Controls.Add(this.txtdispote);
            this.grpbx_preliev.Controls.Add(this.txtdispoara);
            this.grpbx_preliev.Controls.Add(this.txtdispocola);
            this.grpbx_preliev.Controls.Add(this.txtdispoacqua);
            this.grpbx_preliev.Controls.Add(this.label8);
            this.grpbx_preliev.Controls.Add(this.label7);
            this.grpbx_preliev.Controls.Add(this.label6);
            this.grpbx_preliev.Controls.Add(this.label5);
            this.grpbx_preliev.Controls.Add(this.label4);
            this.grpbx_preliev.Controls.Add(this.label3);
            this.grpbx_preliev.Controls.Add(this.label2);
            this.grpbx_preliev.Controls.Add(this.label1);
            this.grpbx_preliev.Controls.Add(this.check_tèfreddo);
            this.grpbx_preliev.Controls.Add(this.check_aranciata);
            this.grpbx_preliev.Controls.Add(this.check_cola);
            this.grpbx_preliev.Controls.Add(this.check_acqua);
            this.grpbx_preliev.Location = new System.Drawing.Point(12, 12);
            this.grpbx_preliev.Name = "grpbx_preliev";
            this.grpbx_preliev.Size = new System.Drawing.Size(329, 160);
            this.grpbx_preliev.TabIndex = 0;
            this.grpbx_preliev.TabStop = false;
            this.grpbx_preliev.Text = "Prelievo Bevande";
            // 
            // grbx_Pagame
            // 
            this.grbx_Pagame.Controls.Add(this.txttotversa);
            this.grbx_Pagame.Controls.Add(this.bttaccettapagam);
            this.grbx_Pagame.Controls.Add(this.label9);
            this.grbx_Pagame.Location = new System.Drawing.Point(12, 178);
            this.grbx_Pagame.Name = "grbx_Pagame";
            this.grbx_Pagame.Size = new System.Drawing.Size(329, 94);
            this.grbx_Pagame.TabIndex = 1;
            this.grbx_Pagame.TabStop = false;
            this.grbx_Pagame.Text = "Pagamento";
            // 
            // check_acqua
            // 
            this.check_acqua.AutoSize = true;
            this.check_acqua.Location = new System.Drawing.Point(6, 53);
            this.check_acqua.Name = "check_acqua";
            this.check_acqua.Size = new System.Drawing.Size(57, 17);
            this.check_acqua.TabIndex = 0;
            this.check_acqua.Text = "Acqua";
            this.check_acqua.UseVisualStyleBackColor = true;
            this.check_acqua.CheckedChanged += new System.EventHandler(this.check_acqua_CheckedChanged);
            // 
            // check_cola
            // 
            this.check_cola.AutoSize = true;
            this.check_cola.Location = new System.Drawing.Point(6, 76);
            this.check_cola.Name = "check_cola";
            this.check_cola.Size = new System.Drawing.Size(47, 17);
            this.check_cola.TabIndex = 1;
            this.check_cola.Text = "Cola";
            this.check_cola.UseVisualStyleBackColor = true;
            this.check_cola.CheckedChanged += new System.EventHandler(this.check_cola_CheckedChanged);
            // 
            // check_aranciata
            // 
            this.check_aranciata.AutoSize = true;
            this.check_aranciata.Location = new System.Drawing.Point(6, 99);
            this.check_aranciata.Name = "check_aranciata";
            this.check_aranciata.Size = new System.Drawing.Size(71, 17);
            this.check_aranciata.TabIndex = 2;
            this.check_aranciata.Text = "Aranciata";
            this.check_aranciata.UseVisualStyleBackColor = true;
            this.check_aranciata.CheckedChanged += new System.EventHandler(this.check_aranciata_CheckedChanged);
            // 
            // check_tèfreddo
            // 
            this.check_tèfreddo.AutoSize = true;
            this.check_tèfreddo.Location = new System.Drawing.Point(6, 122);
            this.check_tèfreddo.Name = "check_tèfreddo";
            this.check_tèfreddo.Size = new System.Drawing.Size(75, 17);
            this.check_tèfreddo.TabIndex = 3;
            this.check_tèfreddo.Text = "Tè Freddo";
            this.check_tèfreddo.UseVisualStyleBackColor = true;
            this.check_tèfreddo.CheckedChanged += new System.EventHandler(this.check_tèfreddo_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Bevanda";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Prezzo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(184, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Disponibilità";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(259, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Preleva";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(118, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "$2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(118, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "$2,50";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(118, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "$1,50";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(118, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "$1,80";
            // 
            // txtdispoacqua
            // 
            this.txtdispoacqua.Location = new System.Drawing.Point(189, 47);
            this.txtdispoacqua.Name = "txtdispoacqua";
            this.txtdispoacqua.ReadOnly = true;
            this.txtdispoacqua.Size = new System.Drawing.Size(32, 20);
            this.txtdispoacqua.TabIndex = 12;
            // 
            // txtdispocola
            // 
            this.txtdispocola.Location = new System.Drawing.Point(189, 70);
            this.txtdispocola.Name = "txtdispocola";
            this.txtdispocola.ReadOnly = true;
            this.txtdispocola.Size = new System.Drawing.Size(32, 20);
            this.txtdispocola.TabIndex = 13;
            // 
            // txtdispoara
            // 
            this.txtdispoara.Location = new System.Drawing.Point(189, 93);
            this.txtdispoara.Name = "txtdispoara";
            this.txtdispoara.ReadOnly = true;
            this.txtdispoara.Size = new System.Drawing.Size(32, 20);
            this.txtdispoara.TabIndex = 14;
            // 
            // txtdispote
            // 
            this.txtdispote.Location = new System.Drawing.Point(189, 116);
            this.txtdispote.Name = "txtdispote";
            this.txtdispote.ReadOnly = true;
            this.txtdispote.Size = new System.Drawing.Size(32, 20);
            this.txtdispote.TabIndex = 15;
            // 
            // bttprelacqua
            // 
            this.bttprelacqua.Enabled = false;
            this.bttprelacqua.Location = new System.Drawing.Point(242, 44);
            this.bttprelacqua.Name = "bttprelacqua";
            this.bttprelacqua.Size = new System.Drawing.Size(75, 23);
            this.bttprelacqua.TabIndex = 16;
            this.bttprelacqua.Text = "Preleva";
            this.bttprelacqua.UseVisualStyleBackColor = true;
            this.bttprelacqua.Click += new System.EventHandler(this.bttprelacqua_Click);
            // 
            // bttprelcola
            // 
            this.bttprelcola.Enabled = false;
            this.bttprelcola.Location = new System.Drawing.Point(242, 67);
            this.bttprelcola.Name = "bttprelcola";
            this.bttprelcola.Size = new System.Drawing.Size(75, 23);
            this.bttprelcola.TabIndex = 17;
            this.bttprelcola.Text = "Preleva";
            this.bttprelcola.UseVisualStyleBackColor = true;
            this.bttprelcola.Click += new System.EventHandler(this.bttprelcola_Click);
            // 
            // bttprelarancia
            // 
            this.bttprelarancia.Enabled = false;
            this.bttprelarancia.Location = new System.Drawing.Point(242, 90);
            this.bttprelarancia.Name = "bttprelarancia";
            this.bttprelarancia.Size = new System.Drawing.Size(75, 23);
            this.bttprelarancia.TabIndex = 18;
            this.bttprelarancia.Text = "Preleva";
            this.bttprelarancia.UseVisualStyleBackColor = true;
            this.bttprelarancia.Click += new System.EventHandler(this.bttprelarancia_Click);
            // 
            // bttpreltefreddo
            // 
            this.bttpreltefreddo.Enabled = false;
            this.bttpreltefreddo.Location = new System.Drawing.Point(242, 113);
            this.bttpreltefreddo.Name = "bttpreltefreddo";
            this.bttpreltefreddo.Size = new System.Drawing.Size(75, 23);
            this.bttpreltefreddo.TabIndex = 19;
            this.bttpreltefreddo.Text = "Preleva";
            this.bttpreltefreddo.UseVisualStyleBackColor = true;
            this.bttpreltefreddo.Click += new System.EventHandler(this.bttpreltefreddo_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Totale Versato $";
            // 
            // bttaccettapagam
            // 
            this.bttaccettapagam.Location = new System.Drawing.Point(121, 60);
            this.bttaccettapagam.Name = "bttaccettapagam";
            this.bttaccettapagam.Size = new System.Drawing.Size(75, 23);
            this.bttaccettapagam.TabIndex = 20;
            this.bttaccettapagam.Text = "Accetta";
            this.bttaccettapagam.UseVisualStyleBackColor = true;
            this.bttaccettapagam.Click += new System.EventHandler(this.bttaccettapagam_Click);
            // 
            // txttotversa
            // 
            this.txttotversa.Location = new System.Drawing.Point(105, 34);
            this.txttotversa.Name = "txttotversa";
            this.txttotversa.ReadOnly = true;
            this.txttotversa.Size = new System.Drawing.Size(116, 20);
            this.txttotversa.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 278);
            this.Controls.Add(this.grbx_Pagame);
            this.Controls.Add(this.grpbx_preliev);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Distributore Automatico";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbx_preliev.ResumeLayout(false);
            this.grpbx_preliev.PerformLayout();
            this.grbx_Pagame.ResumeLayout(false);
            this.grbx_Pagame.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbx_preliev;
        private System.Windows.Forms.Button bttpreltefreddo;
        private System.Windows.Forms.Button bttprelarancia;
        private System.Windows.Forms.Button bttprelcola;
        private System.Windows.Forms.Button bttprelacqua;
        private System.Windows.Forms.TextBox txtdispote;
        private System.Windows.Forms.TextBox txtdispoara;
        private System.Windows.Forms.TextBox txtdispocola;
        private System.Windows.Forms.TextBox txtdispoacqua;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox check_tèfreddo;
        private System.Windows.Forms.CheckBox check_aranciata;
        private System.Windows.Forms.CheckBox check_cola;
        private System.Windows.Forms.CheckBox check_acqua;
        private System.Windows.Forms.GroupBox grbx_Pagame;
        private System.Windows.Forms.TextBox txttotversa;
        private System.Windows.Forms.Button bttaccettapagam;
        private System.Windows.Forms.Label label9;
    }
}

