﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Codice_utente
{
    public partial class frmmain : Form
    {
        static string codice;
        public frmmain()
        {
            InitializeComponent();
            txtcognome.Text = "";
            txtdatadinascita.Text = "";
            txtdisplay.Text = "";
            txtnome.Text = "";
            bttgenerator.Enabled = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void bttread_Click(object sender, EventArgs e)
        {
            bool ok = false;
            ok = verificadata(txtdatadinascita.Text);

            if (ok == true)
            {
                bttgenerator.Enabled = true;
            }
            else
            {
                bttgenerator.Enabled = false;
                txtdatadinascita.Text = "Data non valida";
            }

        }

        public void cod()
        {
            string nome;
            string cogn;
            string data;

            nome = "" + txtnome.Text[0] + txtnome.Text[1];
            cogn = "" + txtcognome.Text[0] + txtcognome.Text[txtcognome.Text.Length - 1];
            data = "" + txtdatadinascita.Text[txtdatadinascita.Text.Length - 2] + txtdatadinascita.Text[txtdatadinascita.Text.Length - 1] + txtdatadinascita.Text[0] + txtdatadinascita.Text[1];
            codice = nome + cogn + data;
        }

        public bool verificadata(string data)
        {           
            bool check = false;
            int contslash = 0;
            for (int i = 0; i < data.Length; i++)
            {
                if (data[i] == '/')
                {
                    contslash++;
                }

                if (data[i] == '-')
                {
                    check = true;
                }                         
            }

            if (data.Length != 10|| check == true || contslash != 2)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private void bttgenerator_Click(object sender, EventArgs e)
        {
            cod();
            txtdisplay.Text = codice;
        }

    }
}
