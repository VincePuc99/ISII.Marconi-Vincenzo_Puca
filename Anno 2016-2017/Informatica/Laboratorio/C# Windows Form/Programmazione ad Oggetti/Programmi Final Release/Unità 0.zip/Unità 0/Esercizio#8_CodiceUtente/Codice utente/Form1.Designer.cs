﻿namespace Codice_utente
{
    partial class frmmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpdati = new System.Windows.Forms.GroupBox();
            this.txtdatadinascita = new System.Windows.Forms.TextBox();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Cognome = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpattività = new System.Windows.Forms.GroupBox();
            this.bttgenerator = new System.Windows.Forms.Button();
            this.bttread = new System.Windows.Forms.Button();
            this.grpcodice = new System.Windows.Forms.GroupBox();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.grpdati.SuspendLayout();
            this.grpattività.SuspendLayout();
            this.grpcodice.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdati
            // 
            this.grpdati.Controls.Add(this.txtdatadinascita);
            this.grpdati.Controls.Add(this.txtcognome);
            this.grpdati.Controls.Add(this.label3);
            this.grpdati.Controls.Add(this.Cognome);
            this.grpdati.Controls.Add(this.txtnome);
            this.grpdati.Controls.Add(this.label1);
            this.grpdati.Location = new System.Drawing.Point(12, 12);
            this.grpdati.Name = "grpdati";
            this.grpdati.Size = new System.Drawing.Size(211, 102);
            this.grpdati.TabIndex = 0;
            this.grpdati.TabStop = false;
            this.grpdati.Text = "Dati utente";
            this.grpdati.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtdatadinascita
            // 
            this.txtdatadinascita.Location = new System.Drawing.Point(94, 71);
            this.txtdatadinascita.Name = "txtdatadinascita";
            this.txtdatadinascita.Size = new System.Drawing.Size(100, 20);
            this.txtdatadinascita.TabIndex = 5;
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(94, 45);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(100, 20);
            this.txtcognome.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Data di nascita";
            // 
            // Cognome
            // 
            this.Cognome.AutoSize = true;
            this.Cognome.Location = new System.Drawing.Point(12, 48);
            this.Cognome.Name = "Cognome";
            this.Cognome.Size = new System.Drawing.Size(52, 13);
            this.Cognome.TabIndex = 2;
            this.Cognome.Text = "Cognome";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(94, 19);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(100, 20);
            this.txtnome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // grpattività
            // 
            this.grpattività.Controls.Add(this.bttgenerator);
            this.grpattività.Controls.Add(this.bttread);
            this.grpattività.Location = new System.Drawing.Point(12, 120);
            this.grpattività.Name = "grpattività";
            this.grpattività.Size = new System.Drawing.Size(211, 51);
            this.grpattività.TabIndex = 1;
            this.grpattività.TabStop = false;
            this.grpattività.Text = "Attività";
            // 
            // bttgenerator
            // 
            this.bttgenerator.Location = new System.Drawing.Point(112, 19);
            this.bttgenerator.Name = "bttgenerator";
            this.bttgenerator.Size = new System.Drawing.Size(93, 23);
            this.bttgenerator.TabIndex = 1;
            this.bttgenerator.Text = "Genera codice";
            this.bttgenerator.UseVisualStyleBackColor = true;
            this.bttgenerator.Click += new System.EventHandler(this.bttgenerator_Click);
            // 
            // bttread
            // 
            this.bttread.Location = new System.Drawing.Point(6, 19);
            this.bttread.Name = "bttread";
            this.bttread.Size = new System.Drawing.Size(93, 23);
            this.bttread.TabIndex = 0;
            this.bttread.Text = "Leggi dati";
            this.bttread.UseVisualStyleBackColor = true;
            this.bttread.Click += new System.EventHandler(this.bttread_Click);
            // 
            // grpcodice
            // 
            this.grpcodice.Controls.Add(this.txtdisplay);
            this.grpcodice.Location = new System.Drawing.Point(13, 177);
            this.grpcodice.Name = "grpcodice";
            this.grpcodice.Size = new System.Drawing.Size(210, 49);
            this.grpcodice.TabIndex = 2;
            this.grpcodice.TabStop = false;
            this.grpcodice.Text = "Codice utente";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(16, 19);
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.ReadOnly = true;
            this.txtdisplay.Size = new System.Drawing.Size(177, 20);
            this.txtdisplay.TabIndex = 0;
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 235);
            this.Controls.Add(this.grpcodice);
            this.Controls.Add(this.grpattività);
            this.Controls.Add(this.grpdati);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Code generator";
            this.grpdati.ResumeLayout(false);
            this.grpdati.PerformLayout();
            this.grpattività.ResumeLayout(false);
            this.grpcodice.ResumeLayout(false);
            this.grpcodice.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpdati;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdatadinascita;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Cognome;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.GroupBox grpattività;
        private System.Windows.Forms.Button bttgenerator;
        private System.Windows.Forms.Button bttread;
        private System.Windows.Forms.GroupBox grpcodice;
        private System.Windows.Forms.TextBox txtdisplay;
    }
}

