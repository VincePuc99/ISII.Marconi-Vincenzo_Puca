﻿namespace Calcolatrice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btt_ce = new System.Windows.Forms.Button();
            this.btt_comma = new System.Windows.Forms.Button();
            this.grp_display = new System.Windows.Forms.GroupBox();
            this.txt_display = new System.Windows.Forms.TextBox();
            this.btt_canc = new System.Windows.Forms.Button();
            this.btt_equal = new System.Windows.Forms.Button();
            this.btt_0 = new System.Windows.Forms.Button();
            this.btt_diviso = new System.Windows.Forms.Button();
            this.btt_plus = new System.Windows.Forms.Button();
            this.btt_meno = new System.Windows.Forms.Button();
            this.btt_per = new System.Windows.Forms.Button();
            this.btt_9 = new System.Windows.Forms.Button();
            this.btt_8 = new System.Windows.Forms.Button();
            this.btt_7 = new System.Windows.Forms.Button();
            this.btt_6 = new System.Windows.Forms.Button();
            this.btt_5 = new System.Windows.Forms.Button();
            this.btt_4 = new System.Windows.Forms.Button();
            this.btt_3 = new System.Windows.Forms.Button();
            this.btt_2 = new System.Windows.Forms.Button();
            this.btt_1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.grp_display.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Black;
            this.groupBox1.Controls.Add(this.btt_ce);
            this.groupBox1.Controls.Add(this.btt_comma);
            this.groupBox1.Controls.Add(this.grp_display);
            this.groupBox1.Controls.Add(this.btt_canc);
            this.groupBox1.Controls.Add(this.btt_equal);
            this.groupBox1.Controls.Add(this.btt_0);
            this.groupBox1.Controls.Add(this.btt_diviso);
            this.groupBox1.Controls.Add(this.btt_plus);
            this.groupBox1.Controls.Add(this.btt_meno);
            this.groupBox1.Controls.Add(this.btt_per);
            this.groupBox1.Controls.Add(this.btt_9);
            this.groupBox1.Controls.Add(this.btt_8);
            this.groupBox1.Controls.Add(this.btt_7);
            this.groupBox1.Controls.Add(this.btt_6);
            this.groupBox1.Controls.Add(this.btt_5);
            this.groupBox1.Controls.Add(this.btt_4);
            this.groupBox1.Controls.Add(this.btt_3);
            this.groupBox1.Controls.Add(this.btt_2);
            this.groupBox1.Controls.Add(this.btt_1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(2, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(280, 329);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "V1.0";
            // 
            // btt_ce
            // 
            this.btt_ce.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btt_ce.Location = new System.Drawing.Point(110, 122);
            this.btt_ce.Name = "btt_ce";
            this.btt_ce.Size = new System.Drawing.Size(44, 34);
            this.btt_ce.TabIndex = 19;
            this.btt_ce.Text = "CE";
            this.btt_ce.UseVisualStyleBackColor = true;
            this.btt_ce.Click += new System.EventHandler(this.button1_Click);
            // 
            // btt_comma
            // 
            this.btt_comma.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_comma.Location = new System.Drawing.Point(160, 282);
            this.btt_comma.Name = "btt_comma";
            this.btt_comma.Size = new System.Drawing.Size(44, 34);
            this.btt_comma.TabIndex = 18;
            this.btt_comma.Text = "Virgo.";
            this.btt_comma.UseVisualStyleBackColor = true;
            this.btt_comma.Click += new System.EventHandler(this.btt_comma_Click);
            // 
            // grp_display
            // 
            this.grp_display.Controls.Add(this.txt_display);
            this.grp_display.ForeColor = System.Drawing.Color.White;
            this.grp_display.Location = new System.Drawing.Point(15, 23);
            this.grp_display.Name = "grp_display";
            this.grp_display.Size = new System.Drawing.Size(248, 79);
            this.grp_display.TabIndex = 17;
            this.grp_display.TabStop = false;
            this.grp_display.Text = "Display";
            // 
            // txt_display
            // 
            this.txt_display.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.txt_display.Font = new System.Drawing.Font("Jokerman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_display.Location = new System.Drawing.Point(8, 15);
            this.txt_display.Multiline = true;
            this.txt_display.Name = "txt_display";
            this.txt_display.ReadOnly = true;
            this.txt_display.Size = new System.Drawing.Size(234, 58);
            this.txt_display.TabIndex = 0;
            this.txt_display.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btt_canc
            // 
            this.btt_canc.ForeColor = System.Drawing.Color.Black;
            this.btt_canc.Location = new System.Drawing.Point(160, 122);
            this.btt_canc.Name = "btt_canc";
            this.btt_canc.Size = new System.Drawing.Size(44, 34);
            this.btt_canc.TabIndex = 16;
            this.btt_canc.Text = "C";
            this.btt_canc.UseVisualStyleBackColor = true;
            this.btt_canc.Click += new System.EventHandler(this.btt_canc_Click);
            // 
            // btt_equal
            // 
            this.btt_equal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_equal.Location = new System.Drawing.Point(210, 282);
            this.btt_equal.Name = "btt_equal";
            this.btt_equal.Size = new System.Drawing.Size(44, 34);
            this.btt_equal.TabIndex = 15;
            this.btt_equal.Text = "=";
            this.btt_equal.UseVisualStyleBackColor = true;
            this.btt_equal.Click += new System.EventHandler(this.btt_equal_Click);
            // 
            // btt_0
            // 
            this.btt_0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_0.Location = new System.Drawing.Point(110, 282);
            this.btt_0.Name = "btt_0";
            this.btt_0.Size = new System.Drawing.Size(44, 34);
            this.btt_0.TabIndex = 14;
            this.btt_0.Text = "0";
            this.btt_0.UseVisualStyleBackColor = true;
            this.btt_0.Click += new System.EventHandler(this.btt_0_Click);
            // 
            // btt_diviso
            // 
            this.btt_diviso.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_diviso.Location = new System.Drawing.Point(210, 242);
            this.btt_diviso.Name = "btt_diviso";
            this.btt_diviso.Size = new System.Drawing.Size(44, 34);
            this.btt_diviso.TabIndex = 13;
            this.btt_diviso.Text = "\\";
            this.btt_diviso.UseVisualStyleBackColor = true;
            this.btt_diviso.Click += new System.EventHandler(this.btt_diviso_Click);
            // 
            // btt_plus
            // 
            this.btt_plus.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_plus.Location = new System.Drawing.Point(210, 122);
            this.btt_plus.Name = "btt_plus";
            this.btt_plus.Size = new System.Drawing.Size(44, 34);
            this.btt_plus.TabIndex = 12;
            this.btt_plus.Text = "+";
            this.btt_plus.UseVisualStyleBackColor = true;
            this.btt_plus.Click += new System.EventHandler(this.btt_plus_Click);
            // 
            // btt_meno
            // 
            this.btt_meno.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_meno.Location = new System.Drawing.Point(210, 162);
            this.btt_meno.Name = "btt_meno";
            this.btt_meno.Size = new System.Drawing.Size(44, 34);
            this.btt_meno.TabIndex = 11;
            this.btt_meno.Text = "-";
            this.btt_meno.UseVisualStyleBackColor = true;
            this.btt_meno.Click += new System.EventHandler(this.btt_meno_Click);
            // 
            // btt_per
            // 
            this.btt_per.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_per.Location = new System.Drawing.Point(210, 202);
            this.btt_per.Name = "btt_per";
            this.btt_per.Size = new System.Drawing.Size(44, 34);
            this.btt_per.TabIndex = 10;
            this.btt_per.Text = "x";
            this.btt_per.UseVisualStyleBackColor = true;
            this.btt_per.Click += new System.EventHandler(this.btt_per_Click);
            // 
            // btt_9
            // 
            this.btt_9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_9.Location = new System.Drawing.Point(160, 242);
            this.btt_9.Name = "btt_9";
            this.btt_9.Size = new System.Drawing.Size(44, 34);
            this.btt_9.TabIndex = 9;
            this.btt_9.Text = "9";
            this.btt_9.UseVisualStyleBackColor = true;
            this.btt_9.Click += new System.EventHandler(this.btt_9_Click);
            // 
            // btt_8
            // 
            this.btt_8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_8.Location = new System.Drawing.Point(110, 242);
            this.btt_8.Name = "btt_8";
            this.btt_8.Size = new System.Drawing.Size(44, 34);
            this.btt_8.TabIndex = 8;
            this.btt_8.Text = "8";
            this.btt_8.UseVisualStyleBackColor = true;
            this.btt_8.Click += new System.EventHandler(this.btt_8_Click);
            // 
            // btt_7
            // 
            this.btt_7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_7.Location = new System.Drawing.Point(60, 242);
            this.btt_7.Name = "btt_7";
            this.btt_7.Size = new System.Drawing.Size(44, 34);
            this.btt_7.TabIndex = 7;
            this.btt_7.Text = "7";
            this.btt_7.UseVisualStyleBackColor = true;
            this.btt_7.Click += new System.EventHandler(this.btt_7_Click);
            // 
            // btt_6
            // 
            this.btt_6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_6.Location = new System.Drawing.Point(160, 202);
            this.btt_6.Name = "btt_6";
            this.btt_6.Size = new System.Drawing.Size(44, 34);
            this.btt_6.TabIndex = 6;
            this.btt_6.Text = "6";
            this.btt_6.UseVisualStyleBackColor = true;
            this.btt_6.Click += new System.EventHandler(this.btt_6_Click);
            // 
            // btt_5
            // 
            this.btt_5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_5.Location = new System.Drawing.Point(110, 202);
            this.btt_5.Name = "btt_5";
            this.btt_5.Size = new System.Drawing.Size(44, 34);
            this.btt_5.TabIndex = 5;
            this.btt_5.Text = "5";
            this.btt_5.UseVisualStyleBackColor = true;
            this.btt_5.Click += new System.EventHandler(this.btt_5_Click);
            // 
            // btt_4
            // 
            this.btt_4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_4.Location = new System.Drawing.Point(60, 202);
            this.btt_4.Name = "btt_4";
            this.btt_4.Size = new System.Drawing.Size(44, 34);
            this.btt_4.TabIndex = 4;
            this.btt_4.Text = "4";
            this.btt_4.UseVisualStyleBackColor = true;
            this.btt_4.Click += new System.EventHandler(this.btt_4_Click);
            // 
            // btt_3
            // 
            this.btt_3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_3.Location = new System.Drawing.Point(160, 162);
            this.btt_3.Name = "btt_3";
            this.btt_3.Size = new System.Drawing.Size(44, 34);
            this.btt_3.TabIndex = 3;
            this.btt_3.Text = "3";
            this.btt_3.UseVisualStyleBackColor = true;
            this.btt_3.Click += new System.EventHandler(this.btt_3_Click);
            // 
            // btt_2
            // 
            this.btt_2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_2.Location = new System.Drawing.Point(110, 162);
            this.btt_2.Name = "btt_2";
            this.btt_2.Size = new System.Drawing.Size(44, 34);
            this.btt_2.TabIndex = 2;
            this.btt_2.Text = "2";
            this.btt_2.UseVisualStyleBackColor = true;
            this.btt_2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btt_1
            // 
            this.btt_1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btt_1.Location = new System.Drawing.Point(60, 162);
            this.btt_1.Name = "btt_1";
            this.btt_1.Size = new System.Drawing.Size(44, 34);
            this.btt_1.TabIndex = 1;
            this.btt_1.Text = "1";
            this.btt_1.UseVisualStyleBackColor = true;
            this.btt_1.Click += new System.EventHandler(this.btt_1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(286, 336);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calcolatrice";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.grp_display.ResumeLayout(false);
            this.grp_display.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox grp_display;
        private System.Windows.Forms.TextBox txt_display;
        private System.Windows.Forms.Button btt_canc;
        private System.Windows.Forms.Button btt_equal;
        private System.Windows.Forms.Button btt_0;
        private System.Windows.Forms.Button btt_diviso;
        private System.Windows.Forms.Button btt_plus;
        private System.Windows.Forms.Button btt_meno;
        private System.Windows.Forms.Button btt_per;
        private System.Windows.Forms.Button btt_9;
        private System.Windows.Forms.Button btt_8;
        private System.Windows.Forms.Button btt_7;
        private System.Windows.Forms.Button btt_6;
        private System.Windows.Forms.Button btt_5;
        private System.Windows.Forms.Button btt_4;
        private System.Windows.Forms.Button btt_3;
        private System.Windows.Forms.Button btt_2;
        private System.Windows.Forms.Button btt_1;
        private System.Windows.Forms.Button btt_comma;
        private System.Windows.Forms.Button btt_ce;
    }
}

