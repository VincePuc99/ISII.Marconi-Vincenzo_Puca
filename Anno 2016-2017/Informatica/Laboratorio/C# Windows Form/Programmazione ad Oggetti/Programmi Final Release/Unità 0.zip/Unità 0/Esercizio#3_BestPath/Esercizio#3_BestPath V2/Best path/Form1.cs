﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Best_path
{
    public partial class frmain : Form
    {
        static double[][] orari = new double[4][];
        public frmain()
        {
            InitializeComponent();
        }

        private void frmain_Load(object sender, EventArgs e)
        {          
           orari[0] = new double[] { 0,3.50,2.20,4.10 };
           orari[1] = new double[] { 3.40,0,2.15,3.30 };
           orari[2] = new double[] { 2,2.10,0,0 };
           orari[3] = new double[] { 3.50,2.20,0,0 };

           txt00.Text += "" + orari[0][0];
           txt01.Text += "" + orari[0][1];
           txt02.Text += "" + orari[0][2];
           txt03.Text += "" + orari[0][3];

           txt10.Text += "" + orari[1][0];
           txt11.Text += "" + orari[1][1];
           txt12.Text += "" + orari[1][2];
           txt13.Text += "" + orari[1][3];

           txt20.Text += "" + orari[2][0];
           txt21.Text += "" + orari[2][1];
           txt22.Text += "" + orari[2][2];
           txt23.Text += "Null";

           txt30.Text += "" + orari[3][0];
           txt31.Text += "" + orari[3][1];
           txt32.Text += "Null";
           txt33.Text += "" + orari[3][3];
      }

        private void rdbtt_cerca_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtt_cerca.Checked == true)
            {
                grpbx_cerca.Enabled = true;
            }
            else
                grpbx_cerca.Enabled = false;
        }

        private void rd_btt_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtt_modifica.Checked == true)
            {
                grpbx_modifica.Enabled = true;
            }
            else
                grpbx_modifica.Enabled = false;
        }

        private void btt_reset_Click(object sender, EventArgs e)
        {
            orari[0] = new double[] { 0, 3.50, 2.20, 4.10 };
            orari[1] = new double[] { 3.40, 0, 2.15, 3.30 };
            orari[2] = new double[] { 2, 2.10, 0, 0 };
            orari[3] = new double[] { 3.50, 2.20, 0, 0 };

            txt00.Text = "";
            txt01.Text = "";
            txt02.Text = "";
            txt03.Text = "";
            txt10.Text = "";
            txt11.Text = "";
            txt12.Text = "";
            txt13.Text = "";
            txt20.Text = "";
            txt21.Text = "";
            txt22.Text = "";
            txt23.Text = "";
            txt30.Text = "";
            txt31.Text = "";
            txt32.Text = "";
            txt33.Text = "";

            txt00.Text += "" + orari[0][0];
            txt01.Text += "" + orari[0][1];
            txt02.Text += "" + orari[0][2];
            txt03.Text += "" + orari[0][3];

            txt10.Text += "" + orari[1][0];
            txt11.Text += "" + orari[1][1];
            txt12.Text += "" + orari[1][2];
            txt13.Text += "" + orari[1][3];

            txt20.Text += "" + orari[2][0];
            txt21.Text += "" + orari[2][1];
            txt22.Text += "" + orari[2][2];
            txt23.Text += "Null";

            txt30.Text += "" + orari[3][0];
            txt31.Text += "" + orari[3][1];
            txt32.Text += "Null";
            txt33.Text += "" + orari[3][3];


            txt_ricercaarrivo.Text = "";
            txt_ricercapartenza.Text = "";
            txt_orarioricercadisplay.Text = "";
            txt_orariobest.Text = "";

            txt_modifarrivo.Text = "";
            txt_modifnuovotempo.Text = "";
            txtmodif_partenza.Text = "";

            rdbtt_cerca.Checked = true;
        }

        private void btt_ricerca_Click(object sender, EventArgs e)
        {
            txt_orarioricercadisplay.Text = "";
            txt_orariobest.Text = "";

            if (txt_ricercapartenza.Text == "Milano")
            {
                if (txt_ricercaarrivo.Text == "Milano")
                {
                    txt_orarioricercadisplay.Text = "" + orari[0][0];
                }

                if (txt_ricercaarrivo.Text == "Genova")
                {
                    txt_orarioricercadisplay.Text = "" + orari[0][1];
                }

                if (txt_ricercaarrivo.Text == "Torino")
                {
                    txt_orarioricercadisplay.Text = "" + orari[0][2];
                }

                if (txt_ricercaarrivo.Text == "Bologna")
                {
                    txt_orarioricercadisplay.Text = "" + orari[0][3];
                }
            }

            if (txt_ricercapartenza.Text == "Genova")
            {
                if (txt_ricercaarrivo.Text == "Milano")
                {
                    txt_orarioricercadisplay.Text = "" + orari[1][0];
                }

                if (txt_ricercaarrivo.Text == "Genova")
                {
                    txt_orarioricercadisplay.Text = "" + orari[1][1];
                }

                if (txt_ricercaarrivo.Text == "Torino")
                {
                    txt_orarioricercadisplay.Text = "" + orari[1][2];
                }

                if (txt_ricercaarrivo.Text == "Bologna")
                {
                    txt_orarioricercadisplay.Text = "" + orari[1][3];
                }
            }

            if (txt_ricercapartenza.Text == "Torino")
            {
                if (txt_ricercaarrivo.Text == "Milano")
                {
                    txt_orarioricercadisplay.Text = "" + orari[2][0];
                }

                if (txt_ricercaarrivo.Text == "Genova")
                {
                    txt_orarioricercadisplay.Text = "" + orari[2][1];
                }

                if (txt_ricercaarrivo.Text == "Torino")
                {
                    txt_orarioricercadisplay.Text = "" + orari[2][2];
                }

                if (txt_ricercaarrivo.Text == "Bologna")
                {
                    double somma = orari[3][0] + orari[2][0];
                    double somma1 = orari[3][1] + orari[2][1];
                    txt_orarioricercadisplay.Text += somma;
                    txt_orarioricercadisplay.Text += " MIL /";
                    txt_orarioricercadisplay.Text += somma1;
                    txt_orarioricercadisplay.Text += " GEN";
                    txt_orariobest.Text += somma1; 
                }
            }

            if (txt_ricercapartenza.Text == "Bologna")
            {
                if (txt_ricercaarrivo.Text == "Milano")
                {
                    txt_orarioricercadisplay.Text = "" + orari[3][0];
                }

                if (txt_ricercaarrivo.Text == "Genova")
                {
                    txt_orarioricercadisplay.Text = "" + orari[3][1];
                }

                if (txt_ricercaarrivo.Text == "Torino")
                {
                    double somma = orari[3][0] + orari[0][2];
                    double somma1 = orari[3][1] + orari[1][2];
                    txt_orarioricercadisplay.Text += somma;
                    txt_orarioricercadisplay.Text += " MIL /";
                    txt_orarioricercadisplay.Text += somma1;
                    txt_orarioricercadisplay.Text += " GEN";
                    txt_orariobest.Text += somma1;
                }

                if (txt_ricercaarrivo.Text == "Bologna")
                {
                    txt_orarioricercadisplay.Text = "" + orari[3][3];
                }
            }

        }

        private void btt_modifica_Click(object sender, EventArgs e)
        {

            if (txt_modifarrivo.Text == "Milano")
            {
                if (txtmodif_partenza.Text == "Milano")
                {
                    txt_modifnuovotempo.Text = "Non disponibile";               
                }

                if (txtmodif_partenza.Text == "Genova")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[0][1] = nuovo;
                }

                if (txtmodif_partenza.Text == "Torino")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[0][2] = nuovo;
                }

                if (txtmodif_partenza.Text == "Bologna")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[0][3] = nuovo;
                }
            
            }

            if (txt_modifarrivo.Text == "Genova")
            {
                if (txtmodif_partenza.Text == "Milano")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[1][0] = nuovo;
                }

                if (txtmodif_partenza.Text == "Genova")
                {                    
                    txt_modifnuovotempo.Text = "Non disponibile";
                }

                if (txtmodif_partenza.Text == "Torino")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[1][2] = nuovo;
                }

                if (txtmodif_partenza.Text == "Bologna")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[1][3] = nuovo;
                }

            }

            if (txt_modifarrivo.Text == "Torino")
            {
                if (txtmodif_partenza.Text == "Milano")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[2][0] = nuovo;
                }

                if (txtmodif_partenza.Text == "Genova")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[2][1] = nuovo;
                }

                if (txtmodif_partenza.Text == "Torino")
                {                    
                    txt_modifnuovotempo.Text = "Non disponibile";
                }

                if (txtmodif_partenza.Text == "Bologna")
                {
                    txt_modifnuovotempo.Text = "Non disponibile";
                }
            }

            if (txt_modifarrivo.Text == "Bologna")
            {
                if (txtmodif_partenza.Text == "Milano")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[3][0] = nuovo;
                }

                if (txtmodif_partenza.Text == "Genova")
                {
                    double nuovo = double.Parse(txt_modifnuovotempo.Text);
                    orari[3][1] = nuovo;
                }

                if (txtmodif_partenza.Text == "Torino")
                {
                    txt_modifnuovotempo.Text = "Non disponibile";
                }

                if (txtmodif_partenza.Text == "Bologna")
                {                 
                    txt_modifnuovotempo.Text = "Non disponibile";
                }
            }
        }

        private void btt_refresh_Click(object sender, EventArgs e)
        {
            txt00.Text = "";
            txt01.Text = "";
            txt02.Text = "";
            txt03.Text = "";
            txt10.Text = "";
            txt11.Text = "";
            txt12.Text = "";
            txt13.Text = "";
            txt20.Text = "";
            txt21.Text = "";
            txt22.Text = "";
            txt23.Text = "";
            txt30.Text = "";
            txt31.Text = "";
            txt32.Text = "";
            txt33.Text = "";

            txt00.Text += "" + orari[0][0];
            txt01.Text += "" + orari[0][1];
            txt02.Text += "" + orari[0][2];
            txt03.Text += "" + orari[0][3];

            txt10.Text += "" + orari[1][0];
            txt11.Text += "" + orari[1][1];
            txt12.Text += "" + orari[1][2];
            txt13.Text += "" + orari[1][3];

            txt20.Text += "" + orari[2][0];
            txt21.Text += "" + orari[2][1];
            txt22.Text += "" + orari[2][2];
            txt23.Text += "Null";

            txt30.Text += "" + orari[3][0];
            txt31.Text += "" + orari[3][1];
            txt32.Text += "Null";
            txt33.Text += "" + orari[3][3];
        }//fine main
    }
}
