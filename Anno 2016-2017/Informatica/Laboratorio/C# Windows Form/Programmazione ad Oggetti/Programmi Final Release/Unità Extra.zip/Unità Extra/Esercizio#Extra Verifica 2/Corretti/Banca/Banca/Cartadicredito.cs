﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiBanca
{
    class Cartadicredito : Strumentobancario
    {
        private int numerocarta;
        private int disponibilita;
        private int totspese;
        private string cognom;

        public Cartadicredito(int numcart,int dispo,int totspes,string cogn) : base(cogn)
        { numerocarta = numcart; disponibilita = dispo; totspese = totspes; cognom = cogn; }

        public int NUMEROCARTA { get { return numerocarta; } set { numerocarta = value; } }
        public int DISPONIBILITA { get { return disponibilita; } set { disponibilita = value; } }
        public int TOTSPESE { get { return totspese; } set { totspese = value; } }
        public string COGNOM { get { return cognom; } set { cognom = value; } }

        public override double saldo()
        {
            int saldo = 0;

            saldo = disponibilita - totspese;

            int s, nuovotot;
            s = (totspese * 80) / 100;
            nuovotot = totspese - s;

            if (saldo >= nuovotot)
            {
                int s1, nuovotot1;
                s1 = (saldo * 2) / 100;
                nuovotot1 = saldo - s;

                saldo = saldo + nuovotot1;
                return saldo;
            }
            else
            {            
                return saldo;
            }
        }
    }
}
