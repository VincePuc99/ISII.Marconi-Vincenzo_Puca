﻿using System;
using System.Windows.Forms;
using Oggettibanca;

namespace Puca
{
    public partial class frmmain : Form
    {
        static int cont;
        static int disponibilitacarta;
        public frmmain()
        {
            //inizializzazione
            InitializeComponent();
            cont = 0;
            disponibilitacarta = 3000;
        }

        private void bttmemorizza_Click(object sender, EventArgs e)
        {
            if (cont < 4) //conteggio tasti premuti
            {
                if (rdbcarta.Checked == true)
                {
                    int numerocarta = Int32.Parse(txtnumero.Text); //conversioni dalle textbox alle string
                    int disponibilita = Int32.Parse(txtversamenti.Text);
                    int totspese = Int32.Parse(txtprelievi.Text);

                    disponibilita = disponibilitacarta; //dato che la disponibilità è fissa non uso quella in input
                    Globals.Rapporticlienti[cont] = new Cartadicredito(numerocarta,disponibilita,totspese); //istanzioni nuovo oggetto

                }
                else
                {
                    int numeroconto = Int32.Parse(txtnumero.Text);//conversioni dalle textbox alle string
                    int totversamenti = Int32.Parse(txtversamenti.Text);
                    int totprelievi = Int32.Parse(txtprelievi.Text);

                    Globals.Rapporticlienti[cont] = new Contocorrente(numeroconto,totversamenti,totprelievi);
                }

                cont++; //incremento variabile
            }
            else
            {
                bttmemorizza.Enabled = false;//disabilita memorizza
            }


        }//fine button

        private void rdbcarta_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbcarta.Checked == true) //cambio contenuto label
            {
                label3.Text = "Disponibilità";
                label4.Text = "Tot. Spese";
            }
            else
            {
                label3.Text = "Tot. Versamenti";
                label4.Text = "Tot. Prelievi";
            }
        }//fine radiobutton

        private void bttcalcola_Click(object sender, EventArgs e)
        {
            double saldomedio = 0;
            if (txtcognome.Text == "") //determino se il campo è vuoto
            {
                for (int i = 0; i < 4; i++)
                {
                    saldomedio += Globals.Rapporticlienti[i].saldo(); //richiamo saldo anche se non gli passo alcuna variabile
                }
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    if (txtcognome.Text == Globals.Rapporticlienti[i].COGNOME)//consento alle classi di usare cognome della base anche se questo non gli viene passato
                    {
                        saldomedio += Globals.Rapporticlienti[i].saldo();
                    }
                }
     
            }

            txtdisplay.Text = "" + saldomedio;  //visualizzazione saldo medio
        }//fine calcola

        private void frmmain_Load(object sender, EventArgs e)
        {

        }
    }
}
