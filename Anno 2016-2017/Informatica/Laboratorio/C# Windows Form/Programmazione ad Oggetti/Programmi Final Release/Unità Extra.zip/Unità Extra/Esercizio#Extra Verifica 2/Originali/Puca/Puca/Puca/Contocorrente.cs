﻿namespace Oggettibanca
{
    class Contocorrente : Strumentobancario
    {
        //area dati
        protected int numeroconto;
        protected int totversamenti;
        protected int totprelievi;
        //costruttori
        public Contocorrente()
        {
            numeroconto = 0;
            totversamenti = 0;
            totprelievi = 0;
        }

        public Contocorrente(int numercon,int totvers,int totprel)
        {
            numeroconto = numercon;
            totversamenti = totvers;
            totprelievi = totprel;
        }
        //proprieta
        public int NUMEROCONTO
        {
            get { return numeroconto; }
            set { numeroconto = value; }
        }

        public int TOTVERSAMENTI
        {
            get { return totversamenti; }
            set { totversamenti = value; }
        }

        public int TOTPRELIEVI
        {
            get { return totprelievi; }
            set { totprelievi = value; }
        }
        //metodi
        public override double saldo()
        {
            int saldo = 0;
            if (saldo >= 0)
            {
                int s, nuovotot;
                s = (saldo * 5) / 100;
                nuovotot = saldo - s;
                return nuovotot;
            }
            else
            {
                saldo = totversamenti - totprelievi;
                return saldo;
            }
                     
        }//fine metodo

    }
}
