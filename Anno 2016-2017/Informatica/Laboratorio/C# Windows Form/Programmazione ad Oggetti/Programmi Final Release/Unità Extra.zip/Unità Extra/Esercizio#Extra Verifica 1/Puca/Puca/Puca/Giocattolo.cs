﻿namespace Toys
{
    class Giocattolo
    {
        //attributi
        private int codicegiocattolo;
        private string descrizione;
        private string etacons;
        private string dataimmag;

        //costruttore di default
        public Giocattolo()
        {
            codicegiocattolo = 0;
            descrizione = "";
            etacons = "";
            dataimmag = "";
        }
        //costruttore overloaded
        public Giocattolo(int code, string desc, string eta, string dataimm)
        {
            bool veri = true;
            veri = codeok(0,100);

            if (veri == true)
            {
                codicegiocattolo = code;
                descrizione = desc;
                etacons = eta;
                dataimmag = dataimm;
            }
        }
        //distruttore
        ~Giocattolo()
        {
            codicegiocattolo = 0;
            descrizione = "";
            etacons = "";
            dataimmag = "";
        }
        //proprietà
        public int CODICE
        {
            get { return codicegiocattolo; }
            set { codicegiocattolo = value; }
        }

        public string DESCRIZIONE
        {
            get { return descrizione; }
            set { descrizione = value; }
        }

        public string ETACONS
        {
            get { return etacons; }
            set { etacons = value; }
        }

        public string DATAIMMAGAZ
        {
            get { return dataimmag; }
            set { dataimmag = value; }
        }


        //metodi
        public bool codeok(int min,int max)
        {
            if (codicegiocattolo >= min && codicegiocattolo <= max)
            {
                return true;
            }
            else
            {
                return false;
            }
        }//fine metodo

    }
}
