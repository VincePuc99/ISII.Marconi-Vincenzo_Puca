﻿namespace Oggettibanca
{
    class Globals
    {
        public static Strumentobancario[] Rapporticlienti = new Strumentobancario[4]; //array
    }
}
