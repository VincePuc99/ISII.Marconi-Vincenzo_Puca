﻿namespace Puca
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpdati = new System.Windows.Forms.GroupBox();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grptipo = new System.Windows.Forms.GroupBox();
            this.rdbcarta = new System.Windows.Forms.RadioButton();
            this.rdbconto = new System.Windows.Forms.RadioButton();
            this.grpdatirapporto = new System.Windows.Forms.GroupBox();
            this.txtversamenti = new System.Windows.Forms.TextBox();
            this.txtprelievi = new System.Windows.Forms.TextBox();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bttmemorizza = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.grpdati.SuspendLayout();
            this.grptipo.SuspendLayout();
            this.grpdatirapporto.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdati
            // 
            this.grpdati.Controls.Add(this.txtcognome);
            this.grpdati.Controls.Add(this.label1);
            this.grpdati.Location = new System.Drawing.Point(13, 13);
            this.grpdati.Name = "grpdati";
            this.grpdati.Size = new System.Drawing.Size(278, 63);
            this.grpdati.TabIndex = 0;
            this.grpdati.TabStop = false;
            this.grpdati.Text = "Dati Cliente";
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(123, 17);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(115, 20);
            this.txtcognome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cognome";
            // 
            // grptipo
            // 
            this.grptipo.Controls.Add(this.rdbcarta);
            this.grptipo.Controls.Add(this.rdbconto);
            this.grptipo.Location = new System.Drawing.Point(13, 82);
            this.grptipo.Name = "grptipo";
            this.grptipo.Size = new System.Drawing.Size(278, 78);
            this.grptipo.TabIndex = 1;
            this.grptipo.TabStop = false;
            this.grptipo.Text = "Tipo Rapporto";
            // 
            // rdbcarta
            // 
            this.rdbcarta.AutoSize = true;
            this.rdbcarta.Location = new System.Drawing.Point(163, 31);
            this.rdbcarta.Name = "rdbcarta";
            this.rdbcarta.Size = new System.Drawing.Size(96, 17);
            this.rdbcarta.TabIndex = 1;
            this.rdbcarta.TabStop = true;
            this.rdbcarta.Text = "Carta di credito";
            this.rdbcarta.UseVisualStyleBackColor = true;
            this.rdbcarta.CheckedChanged += new System.EventHandler(this.rdbcarta_CheckedChanged);
            // 
            // rdbconto
            // 
            this.rdbconto.AutoSize = true;
            this.rdbconto.Location = new System.Drawing.Point(22, 31);
            this.rdbconto.Name = "rdbconto";
            this.rdbconto.Size = new System.Drawing.Size(95, 17);
            this.rdbconto.TabIndex = 0;
            this.rdbconto.TabStop = true;
            this.rdbconto.Text = "Conto corrente";
            this.rdbconto.UseVisualStyleBackColor = true;
            // 
            // grpdatirapporto
            // 
            this.grpdatirapporto.Controls.Add(this.txtversamenti);
            this.grpdatirapporto.Controls.Add(this.txtprelievi);
            this.grpdatirapporto.Controls.Add(this.txtnumero);
            this.grpdatirapporto.Controls.Add(this.label4);
            this.grpdatirapporto.Controls.Add(this.label3);
            this.grpdatirapporto.Controls.Add(this.label2);
            this.grpdatirapporto.Location = new System.Drawing.Point(13, 167);
            this.grpdatirapporto.Name = "grpdatirapporto";
            this.grpdatirapporto.Size = new System.Drawing.Size(278, 113);
            this.grpdatirapporto.TabIndex = 2;
            this.grpdatirapporto.TabStop = false;
            this.grpdatirapporto.Text = "Dati Rapporto";
            // 
            // txtversamenti
            // 
            this.txtversamenti.Location = new System.Drawing.Point(123, 49);
            this.txtversamenti.Name = "txtversamenti";
            this.txtversamenti.Size = new System.Drawing.Size(115, 20);
            this.txtversamenti.TabIndex = 5;
            // 
            // txtprelievi
            // 
            this.txtprelievi.Location = new System.Drawing.Point(123, 73);
            this.txtprelievi.Name = "txtprelievi";
            this.txtprelievi.Size = new System.Drawing.Size(115, 20);
            this.txtprelievi.TabIndex = 4;
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(123, 25);
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(115, 20);
            this.txtnumero.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tot. Prelievi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tot. Versamenti";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Numero";
            // 
            // bttmemorizza
            // 
            this.bttmemorizza.Location = new System.Drawing.Point(13, 287);
            this.bttmemorizza.Name = "bttmemorizza";
            this.bttmemorizza.Size = new System.Drawing.Size(278, 36);
            this.bttmemorizza.TabIndex = 3;
            this.bttmemorizza.Text = "Memorizza dati";
            this.bttmemorizza.UseVisualStyleBackColor = true;
            this.bttmemorizza.Click += new System.EventHandler(this.bttmemorizza_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 377);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "$";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(51, 374);
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.Size = new System.Drawing.Size(100, 20);
            this.txtdisplay.TabIndex = 5;
            // 
            // bttcalcola
            // 
            this.bttcalcola.Location = new System.Drawing.Point(176, 345);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(115, 76);
            this.bttcalcola.TabIndex = 6;
            this.bttcalcola.Text = "Calcola saldo medio";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.bttcalcola_Click);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 443);
            this.Controls.Add(this.bttcalcola);
            this.Controls.Add(this.txtdisplay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bttmemorizza);
            this.Controls.Add(this.grpdatirapporto);
            this.Controls.Add(this.grptipo);
            this.Controls.Add(this.grpdati);
            this.Name = "frmmain";
            this.Text = "Banca V1.0";
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpdati.ResumeLayout(false);
            this.grpdati.PerformLayout();
            this.grptipo.ResumeLayout(false);
            this.grptipo.PerformLayout();
            this.grpdatirapporto.ResumeLayout(false);
            this.grpdatirapporto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpdati;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grptipo;
        private System.Windows.Forms.RadioButton rdbcarta;
        private System.Windows.Forms.RadioButton rdbconto;
        private System.Windows.Forms.GroupBox grpdatirapporto;
        private System.Windows.Forms.TextBox txtversamenti;
        private System.Windows.Forms.TextBox txtprelievi;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bttmemorizza;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.Button bttcalcola;
    }
}

