﻿namespace Oggettibanca
{
    abstract class Strumentobancario
    {   //area dati
        private string cognome;
        //metodi
        public abstract double saldo();

        public string COGNOME //ho dovuto aggoiungere questa proprieta altrimenti non avrei mai usato cognome
        {
            get { return cognome; }
            set { cognome = value; }
        }

    }
}
