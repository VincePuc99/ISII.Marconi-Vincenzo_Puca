﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiBanca
{
    abstract class Strumentobancario
    {
        protected string cognome = "";

        public Strumentobancario(string cogn)
        { cognome = cogn; }

        public string COGNOME { get { return cognome; } set { cognome = value; } }

        public abstract double saldo();
    }
}
