﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Titolo = new System.Windows.Forms.Label();
            this.txtbx_scelta = new System.Windows.Forms.TextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.grpbx_vota = new System.Windows.Forms.GroupBox();
            this.btt_vota = new System.Windows.Forms.Button();
            this.grpbx_barre = new System.Windows.Forms.GroupBox();
            this.Scarso = new System.Windows.Forms.Label();
            this.Discreto = new System.Windows.Forms.Label();
            this.Ottimo = new System.Windows.Forms.Label();
            this.grpbx_vota.SuspendLayout();
            this.grpbx_barre.SuspendLayout();
            this.SuspendLayout();
            // 
            // Titolo
            // 
            this.Titolo.AutoSize = true;
            this.Titolo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titolo.Location = new System.Drawing.Point(23, 9);
            this.Titolo.Name = "Titolo";
            this.Titolo.Size = new System.Drawing.Size(243, 18);
            this.Titolo.TabIndex = 0;
            this.Titolo.Text = "Vota la qualità del servizio BAR";
            // 
            // txtbx_scelta
            // 
            this.txtbx_scelta.Location = new System.Drawing.Point(6, 19);
            this.txtbx_scelta.Name = "txtbx_scelta";
            this.txtbx_scelta.Size = new System.Drawing.Size(188, 20);
            this.txtbx_scelta.TabIndex = 1;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 19);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 2;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(12, 52);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 23);
            this.progressBar2.TabIndex = 3;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(12, 81);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(100, 23);
            this.progressBar3.TabIndex = 4;
            // 
            // grpbx_vota
            // 
            this.grpbx_vota.Controls.Add(this.btt_vota);
            this.grpbx_vota.Controls.Add(this.txtbx_scelta);
            this.grpbx_vota.Location = new System.Drawing.Point(38, 29);
            this.grpbx_vota.Name = "grpbx_vota";
            this.grpbx_vota.Size = new System.Drawing.Size(200, 100);
            this.grpbx_vota.TabIndex = 5;
            this.grpbx_vota.TabStop = false;
            this.grpbx_vota.Text = "Selezione Voto";
            // 
            // btt_vota
            // 
            this.btt_vota.Location = new System.Drawing.Point(59, 58);
            this.btt_vota.Name = "btt_vota";
            this.btt_vota.Size = new System.Drawing.Size(75, 23);
            this.btt_vota.TabIndex = 2;
            this.btt_vota.Text = "Vota";
            this.btt_vota.UseVisualStyleBackColor = true;
            this.btt_vota.Click += new System.EventHandler(this.btt_vota_Click);
            // 
            // grpbx_barre
            // 
            this.grpbx_barre.Controls.Add(this.Scarso);
            this.grpbx_barre.Controls.Add(this.Discreto);
            this.grpbx_barre.Controls.Add(this.Ottimo);
            this.grpbx_barre.Controls.Add(this.progressBar3);
            this.grpbx_barre.Controls.Add(this.progressBar2);
            this.grpbx_barre.Controls.Add(this.progressBar1);
            this.grpbx_barre.Location = new System.Drawing.Point(38, 135);
            this.grpbx_barre.Name = "grpbx_barre";
            this.grpbx_barre.Size = new System.Drawing.Size(200, 114);
            this.grpbx_barre.TabIndex = 6;
            this.grpbx_barre.TabStop = false;
            this.grpbx_barre.Text = "Barre di progresso";
            // 
            // Scarso
            // 
            this.Scarso.AutoSize = true;
            this.Scarso.Location = new System.Drawing.Point(129, 19);
            this.Scarso.Name = "Scarso";
            this.Scarso.Size = new System.Drawing.Size(40, 13);
            this.Scarso.TabIndex = 7;
            this.Scarso.Text = "Scarso";
            // 
            // Discreto
            // 
            this.Discreto.AutoSize = true;
            this.Discreto.Location = new System.Drawing.Point(129, 52);
            this.Discreto.Name = "Discreto";
            this.Discreto.Size = new System.Drawing.Size(46, 13);
            this.Discreto.TabIndex = 8;
            this.Discreto.Text = "Discreto";
            this.Discreto.Click += new System.EventHandler(this.label3_Click);
            // 
            // Ottimo
            // 
            this.Ottimo.AutoSize = true;
            this.Ottimo.Location = new System.Drawing.Point(129, 81);
            this.Ottimo.Name = "Ottimo";
            this.Ottimo.Size = new System.Drawing.Size(37, 13);
            this.Ottimo.TabIndex = 9;
            this.Ottimo.Text = "Ottimo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.grpbx_barre);
            this.Controls.Add(this.grpbx_vota);
            this.Controls.Add(this.Titolo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = " Indagine Statistica";
            this.grpbx_vota.ResumeLayout(false);
            this.grpbx_vota.PerformLayout();
            this.grpbx_barre.ResumeLayout(false);
            this.grpbx_barre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Titolo;
        private System.Windows.Forms.TextBox txtbx_scelta;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.GroupBox grpbx_vota;
        private System.Windows.Forms.Button btt_vota;
        private System.Windows.Forms.GroupBox grpbx_barre;
        private System.Windows.Forms.Label Scarso;
        private System.Windows.Forms.Label Discreto;
        private System.Windows.Forms.Label Ottimo;
    }
}

