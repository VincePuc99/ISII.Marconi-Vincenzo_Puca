﻿namespace Oggettibanca
{
    class Cartadicredito : Strumentobancario
    {   
        //area dati
        protected int numerocarta;
        protected int importomesile;
        protected int totalespese;

        //costruttori
        public Cartadicredito()
        {
            numerocarta = 0;
            importomesile = 0;
            totalespese = 0;
        }

        public Cartadicredito(int ncarta, int importo, int totspese)
        {
            numerocarta = ncarta;
            importomesile = importo;
            totalespese = totspese;
        }
        //proprietà
        public int NUMEROCARTA
        {
            get { return numerocarta; }
            set { numerocarta = value; }
        }

        public int IMPORTOMENSILE
        {
            get { return importomesile; }
            set { importomesile = value; }
        }

        public int TOTSPESE
        {
            get { return totalespese; }
            set { totalespese = value; }
        }
        //metodi
        public override double saldo()
        {
            int saldo = 0;

            int s, nuovotot;
            s = (importomesile * 80) / 100;
            nuovotot = importomesile - s;

            if (saldo >= nuovotot)
            {
                int s1, nuovotot1;
                s1 = (saldo * 2) / 100;
                nuovotot1 = saldo - s;

                saldo = saldo + nuovotot1;
                return saldo;

            }
            else
            {
                saldo = importomesile - totalespese;
                return saldo;
            }
        }

    }
}
