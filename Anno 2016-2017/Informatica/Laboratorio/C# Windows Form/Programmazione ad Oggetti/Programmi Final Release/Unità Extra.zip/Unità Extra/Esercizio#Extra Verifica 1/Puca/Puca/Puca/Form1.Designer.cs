﻿namespace Puca
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpschedagioc = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcodice = new System.Windows.Forms.TextBox();
            this.txtdescrizione = new System.Windows.Forms.TextBox();
            this.txteta = new System.Windows.Forms.TextBox();
            this.txtdata = new System.Windows.Forms.TextBox();
            this.bttinserisci = new System.Windows.Forms.Button();
            this.bttcancella = new System.Windows.Forms.Button();
            this.bttricerca = new System.Windows.Forms.Button();
            this.grpricerca = new System.Windows.Forms.GroupBox();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.grpschedagioc.SuspendLayout();
            this.grpricerca.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpschedagioc
            // 
            this.grpschedagioc.Controls.Add(this.txtdata);
            this.grpschedagioc.Controls.Add(this.txteta);
            this.grpschedagioc.Controls.Add(this.txtdescrizione);
            this.grpschedagioc.Controls.Add(this.txtcodice);
            this.grpschedagioc.Controls.Add(this.label4);
            this.grpschedagioc.Controls.Add(this.label3);
            this.grpschedagioc.Controls.Add(this.label2);
            this.grpschedagioc.Controls.Add(this.label1);
            this.grpschedagioc.Location = new System.Drawing.Point(13, 13);
            this.grpschedagioc.Name = "grpschedagioc";
            this.grpschedagioc.Size = new System.Drawing.Size(241, 120);
            this.grpschedagioc.TabIndex = 0;
            this.grpschedagioc.TabStop = false;
            this.grpschedagioc.Text = "Scheda giocattolo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codice giocattolo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Descrizione";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Età consigliata";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Data immagazzinamento";
            // 
            // txtcodice
            // 
            this.txtcodice.Location = new System.Drawing.Point(134, 13);
            this.txtcodice.Name = "txtcodice";
            this.txtcodice.Size = new System.Drawing.Size(100, 20);
            this.txtcodice.TabIndex = 4;
            // 
            // txtdescrizione
            // 
            this.txtdescrizione.Location = new System.Drawing.Point(134, 39);
            this.txtdescrizione.Name = "txtdescrizione";
            this.txtdescrizione.Size = new System.Drawing.Size(100, 20);
            this.txtdescrizione.TabIndex = 5;
            // 
            // txteta
            // 
            this.txteta.Location = new System.Drawing.Point(134, 65);
            this.txteta.Name = "txteta";
            this.txteta.Size = new System.Drawing.Size(100, 20);
            this.txteta.TabIndex = 6;
            // 
            // txtdata
            // 
            this.txtdata.Location = new System.Drawing.Point(134, 91);
            this.txtdata.Name = "txtdata";
            this.txtdata.Size = new System.Drawing.Size(100, 20);
            this.txtdata.TabIndex = 7;
            // 
            // bttinserisci
            // 
            this.bttinserisci.Location = new System.Drawing.Point(13, 139);
            this.bttinserisci.Name = "bttinserisci";
            this.bttinserisci.Size = new System.Drawing.Size(241, 25);
            this.bttinserisci.TabIndex = 1;
            this.bttinserisci.Text = "Inserisci nel deposito";
            this.bttinserisci.UseVisualStyleBackColor = true;
            this.bttinserisci.Click += new System.EventHandler(this.bttinserisci_Click);
            // 
            // bttcancella
            // 
            this.bttcancella.Enabled = false;
            this.bttcancella.Location = new System.Drawing.Point(13, 170);
            this.bttcancella.Name = "bttcancella";
            this.bttcancella.Size = new System.Drawing.Size(241, 25);
            this.bttcancella.TabIndex = 2;
            this.bttcancella.Text = "Cancellazione";
            this.bttcancella.UseVisualStyleBackColor = true;
            this.bttcancella.Click += new System.EventHandler(this.bttcancella_Click);
            // 
            // bttricerca
            // 
            this.bttricerca.Enabled = false;
            this.bttricerca.Location = new System.Drawing.Point(13, 201);
            this.bttricerca.Name = "bttricerca";
            this.bttricerca.Size = new System.Drawing.Size(241, 25);
            this.bttricerca.TabIndex = 3;
            this.bttricerca.Text = "Ricerca";
            this.bttricerca.UseVisualStyleBackColor = true;
            this.bttricerca.Click += new System.EventHandler(this.bttricerca_Click);
            // 
            // grpricerca
            // 
            this.grpricerca.Controls.Add(this.txtdisplay);
            this.grpricerca.Location = new System.Drawing.Point(13, 233);
            this.grpricerca.Name = "grpricerca";
            this.grpricerca.Size = new System.Drawing.Size(241, 100);
            this.grpricerca.TabIndex = 4;
            this.grpricerca.TabStop = false;
            this.grpricerca.Text = "Ricerca";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(6, 20);
            this.txtdisplay.Multiline = true;
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.ReadOnly = true;
            this.txtdisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtdisplay.Size = new System.Drawing.Size(228, 74);
            this.txtdisplay.TabIndex = 0;
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(266, 343);
            this.Controls.Add(this.grpricerca);
            this.Controls.Add(this.bttricerca);
            this.Controls.Add(this.bttcancella);
            this.Controls.Add(this.bttinserisci);
            this.Controls.Add(this.grpschedagioc);
            this.Name = "frmmain";
            this.Text = "Deposito Giocattoli V1.0";
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpschedagioc.ResumeLayout(false);
            this.grpschedagioc.PerformLayout();
            this.grpricerca.ResumeLayout(false);
            this.grpricerca.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpschedagioc;
        private System.Windows.Forms.TextBox txtdata;
        private System.Windows.Forms.TextBox txteta;
        private System.Windows.Forms.TextBox txtdescrizione;
        private System.Windows.Forms.TextBox txtcodice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttinserisci;
        private System.Windows.Forms.Button bttcancella;
        private System.Windows.Forms.Button bttricerca;
        private System.Windows.Forms.GroupBox grpricerca;
        private System.Windows.Forms.TextBox txtdisplay;
    }
}

