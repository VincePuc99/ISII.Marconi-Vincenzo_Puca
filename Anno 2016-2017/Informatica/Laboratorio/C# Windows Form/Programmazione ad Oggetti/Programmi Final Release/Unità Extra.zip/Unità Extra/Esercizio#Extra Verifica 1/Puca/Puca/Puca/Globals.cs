﻿using Toys;

namespace Puca
{
    class Globals
    {
        //array deposito
        public static Giocattolo[] deposito = new Giocattolo[5]; //valore di 5
    }
}
