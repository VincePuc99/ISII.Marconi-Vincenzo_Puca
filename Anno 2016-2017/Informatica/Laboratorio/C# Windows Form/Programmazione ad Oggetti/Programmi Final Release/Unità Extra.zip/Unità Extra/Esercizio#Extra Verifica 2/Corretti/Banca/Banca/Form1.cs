﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OggettiBanca;

namespace Banca
{
    public partial class frmmain : Form
    {
        static int cont;

        public frmmain()
        {
            InitializeComponent();
            cont = 0;
        }

        private void bttmem_Click(object sender, EventArgs e)
        {
            if (cont < 4)
            {
                if (rdbcarta.Checked == true)
                {
                    int numero = Int32.Parse(txtnumero.Text);
                    int disponibilita = Int32.Parse(txttotversamenti.Text);
                    int spese = Int32.Parse(txttotprelievi.Text);

                    Globals.Rapportibancari[cont] = new Cartadicredito(numero,disponibilita,spese,txtcognome.Text);
                }
                else
                {
                    int numero = Int32.Parse(txtnumero.Text);
                    int versamenti = Int32.Parse(txttotversamenti.Text);
                    int prelievi = Int32.Parse(txttotprelievi.Text);

                    Globals.Rapportibancari[cont] = new Contocorrente(numero,versamenti,prelievi,txtcognome.Text);            
                }

                cont++;
            }
            else 
            {
                bttmem.Enabled = false;
                bttcalcola.Enabled = true;
            }
        }

        private void rdbcarta_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbcarta.Checked == true)
            {
                label3.Text = "Disponibilità";
                label4.Text = "Tot. Spese";
            }
            else
            {
                label3.Text = "Tot. Versamenti";
                label4.Text = "Tot. Prelievi";           
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double saldomedio = 0.0;

            if (txtcognome.Text == "")
            {
                for (int i = 0; i < 4; i++)
                {
                    saldomedio += Globals.Rapportibancari[i].saldo();
                }
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    if (txtcognome.Text == Globals.Rapportibancari[i].COGNOME)
                    {
                       saldomedio += Globals.Rapportibancari[i].saldo();
                    }
                }
            }

            txtdisplay.Text = "" + saldomedio;
        }//fine button
    }
}
