﻿namespace Banca
{
    partial class frmmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpdati = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.grptipo = new System.Windows.Forms.GroupBox();
            this.rdbconto = new System.Windows.Forms.RadioButton();
            this.rdbcarta = new System.Windows.Forms.RadioButton();
            this.grpdatirapporto = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.txttotversamenti = new System.Windows.Forms.TextBox();
            this.txttotprelievi = new System.Windows.Forms.TextBox();
            this.bttmem = new System.Windows.Forms.Button();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.grpdati.SuspendLayout();
            this.grptipo.SuspendLayout();
            this.grpdatirapporto.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdati
            // 
            this.grpdati.Controls.Add(this.txtcognome);
            this.grpdati.Controls.Add(this.label1);
            this.grpdati.Location = new System.Drawing.Point(12, 12);
            this.grpdati.Name = "grpdati";
            this.grpdati.Size = new System.Drawing.Size(201, 46);
            this.grpdati.TabIndex = 0;
            this.grpdati.TabStop = false;
            this.grpdati.Text = "Dati cliente";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cognome";
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(91, 16);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(100, 20);
            this.txtcognome.TabIndex = 1;
            // 
            // grptipo
            // 
            this.grptipo.Controls.Add(this.rdbcarta);
            this.grptipo.Controls.Add(this.rdbconto);
            this.grptipo.Location = new System.Drawing.Point(13, 65);
            this.grptipo.Name = "grptipo";
            this.grptipo.Size = new System.Drawing.Size(106, 66);
            this.grptipo.TabIndex = 1;
            this.grptipo.TabStop = false;
            this.grptipo.Text = "Tipo rapporto";
            // 
            // rdbconto
            // 
            this.rdbconto.AutoSize = true;
            this.rdbconto.Location = new System.Drawing.Point(6, 19);
            this.rdbconto.Name = "rdbconto";
            this.rdbconto.Size = new System.Drawing.Size(96, 17);
            this.rdbconto.TabIndex = 0;
            this.rdbconto.TabStop = true;
            this.rdbconto.Text = "Conto Corrente";
            this.rdbconto.UseVisualStyleBackColor = true;
            // 
            // rdbcarta
            // 
            this.rdbcarta.AutoSize = true;
            this.rdbcarta.Location = new System.Drawing.Point(6, 42);
            this.rdbcarta.Name = "rdbcarta";
            this.rdbcarta.Size = new System.Drawing.Size(96, 17);
            this.rdbcarta.TabIndex = 1;
            this.rdbcarta.TabStop = true;
            this.rdbcarta.Text = "Carta di credito";
            this.rdbcarta.UseVisualStyleBackColor = true;
            this.rdbcarta.CheckedChanged += new System.EventHandler(this.rdbcarta_CheckedChanged);
            // 
            // grpdatirapporto
            // 
            this.grpdatirapporto.Controls.Add(this.txttotprelievi);
            this.grpdatirapporto.Controls.Add(this.txttotversamenti);
            this.grpdatirapporto.Controls.Add(this.txtnumero);
            this.grpdatirapporto.Controls.Add(this.label4);
            this.grpdatirapporto.Controls.Add(this.label3);
            this.grpdatirapporto.Controls.Add(this.label2);
            this.grpdatirapporto.Location = new System.Drawing.Point(12, 138);
            this.grpdatirapporto.Name = "grpdatirapporto";
            this.grpdatirapporto.Size = new System.Drawing.Size(201, 97);
            this.grpdatirapporto.TabIndex = 2;
            this.grpdatirapporto.TabStop = false;
            this.grpdatirapporto.Text = "Dati rapporto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Numero";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tot.Versamenti";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tot.Prelievi";
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(91, 16);
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(100, 20);
            this.txtnumero.TabIndex = 3;
            // 
            // txttotversamenti
            // 
            this.txttotversamenti.Location = new System.Drawing.Point(91, 42);
            this.txttotversamenti.Name = "txttotversamenti";
            this.txttotversamenti.Size = new System.Drawing.Size(100, 20);
            this.txttotversamenti.TabIndex = 4;
            // 
            // txttotprelievi
            // 
            this.txttotprelievi.Location = new System.Drawing.Point(91, 68);
            this.txttotprelievi.Name = "txttotprelievi";
            this.txttotprelievi.Size = new System.Drawing.Size(100, 20);
            this.txttotprelievi.TabIndex = 5;
            // 
            // bttmem
            // 
            this.bttmem.Location = new System.Drawing.Point(125, 66);
            this.bttmem.Name = "bttmem";
            this.bttmem.Size = new System.Drawing.Size(88, 23);
            this.bttmem.TabIndex = 3;
            this.bttmem.Text = "Memorizza dati";
            this.bttmem.UseVisualStyleBackColor = true;
            this.bttmem.Click += new System.EventHandler(this.bttmem_Click);
            // 
            // bttcalcola
            // 
            this.bttcalcola.Enabled = false;
            this.bttcalcola.Location = new System.Drawing.Point(125, 95);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(88, 36);
            this.bttcalcola.TabIndex = 4;
            this.bttcalcola.Text = "Calcola saldo medio";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(94, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "$";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(113, 242);
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.ReadOnly = true;
            this.txtdisplay.Size = new System.Drawing.Size(100, 20);
            this.txtdisplay.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Saldo medio";
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(226, 272);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtdisplay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bttcalcola);
            this.Controls.Add(this.bttmem);
            this.Controls.Add(this.grpdatirapporto);
            this.Controls.Add(this.grptipo);
            this.Controls.Add(this.grpdati);
            this.Name = "frmmain";
            this.Text = "Banca";
            this.grpdati.ResumeLayout(false);
            this.grpdati.PerformLayout();
            this.grptipo.ResumeLayout(false);
            this.grptipo.PerformLayout();
            this.grpdatirapporto.ResumeLayout(false);
            this.grpdatirapporto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpdati;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grptipo;
        private System.Windows.Forms.RadioButton rdbcarta;
        private System.Windows.Forms.RadioButton rdbconto;
        private System.Windows.Forms.GroupBox grpdatirapporto;
        private System.Windows.Forms.TextBox txttotprelievi;
        private System.Windows.Forms.TextBox txttotversamenti;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bttmem;
        private System.Windows.Forms.Button bttcalcola;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.Label label6;
    }
}

