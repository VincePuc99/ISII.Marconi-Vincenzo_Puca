﻿using System;
using System.Windows.Forms;
using Toys;

namespace Puca
{
    public partial class frmmain : Form
    {
        static int cont;
        public frmmain()
        {//inizializza componenti
            InitializeComponent();
            cont = 0;
        }

        private void frmmain_Load(object sender, EventArgs e)
        {

        }

        private void bttinserisci_Click(object sender, EventArgs e)
        {
            
            if (cont < 5)
            {
                int codice = Int32.Parse(txtcodice.Text); 
                Globals.deposito[cont] = new Giocattolo(codice,txtdata.Text,txtdescrizione.Text,txteta.Text); //il codice non può essere mai vuoto
            } //se non è presente un valore nella text allora verrà passato in automatico ""
            else
            {
                bttinserisci.Enabled = false; //abilita/disabilita alcuni pulsanti
                bttcancella.Enabled = true;
                bttricerca.Enabled = true;
            }

            cont++; //incrementa conteggio

            txtcodice.Text = ""; //pulisce le textbox
            txtdata.Text = "";
            txtdescrizione.Text = "";
            txteta.Text = "";

        }//fine button

        private void bttcancella_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                int codice = Int32.Parse(txtcodice.Text); //converte da string a int 
                if (codice == Globals.deposito[i].CODICE && txtdescrizione.Text == Globals.deposito[i].DESCRIZIONE && txteta.Text == Globals.deposito[i].ETACONS && txtdata.Text == Globals.deposito[i].DATAIMMAGAZ)
                { 
                    Globals.deposito[i].CODICE = 0;
                    Globals.deposito[i].DESCRIZIONE = null;
                    Globals.deposito[i].ETACONS = null;
                    Globals.deposito[i].DATAIMMAGAZ = null;
                }            
            }//fine for

        }//fine cancella

        private void bttricerca_Click(object sender, EventArgs e)
        {
            txtdisplay.Text = "Cod.   Data  Art.   Età\r\n";
            txtdisplay.Text += "-------------------------------\r\n";
            for (int i = 0; i < 5; i++)
            {
                int codice = Int32.Parse(txtcodice.Text); //converte da string a int
                if (codice != 0) //controlla se il codice è diverso da 0
                {
                    if (codice == Globals.deposito[i].CODICE) //controlla se è presente in array
                    {
                        txtdisplay.Text += Globals.deposito[i].CODICE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DESCRIZIONE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].ETACONS;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DATAIMMAGAZ;
                        txtdisplay.Text += "\r\n";
                    }
                }
                if (txtdescrizione.Text != "") //controlla se la stringa esiste
                {
                    if (txtdescrizione.Text == Globals.deposito[i].DESCRIZIONE) //controlla se è presente in array
                    {
                        txtdisplay.Text += Globals.deposito[i].CODICE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DESCRIZIONE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].ETACONS;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DATAIMMAGAZ;
                        txtdisplay.Text += "\r\n";
                    }
                }
                if (txteta.Text != "") //controlla se la stringa esiste
                {
                    if (txteta.Text == Globals.deposito[i].ETACONS) //controlla se è presente in array
                    {
                        txtdisplay.Text += Globals.deposito[i].CODICE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DESCRIZIONE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].ETACONS;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DATAIMMAGAZ;
                        txtdisplay.Text += "\r\n";
                    }
                }

                if (txtdata.Text != "") //controlla se la stringa esiste
                {
                    if (txtdata.Text == Globals.deposito[i].DATAIMMAGAZ) //controlla se è presente in array
                    {
                        txtdisplay.Text += Globals.deposito[i].CODICE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DESCRIZIONE;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].ETACONS;
                        txtdisplay.Text += " ";
                        txtdisplay.Text += Globals.deposito[i].DATAIMMAGAZ;
                        txtdisplay.Text += "\r\n";
                    }
                }
            }//fine for
        }
    }
}
