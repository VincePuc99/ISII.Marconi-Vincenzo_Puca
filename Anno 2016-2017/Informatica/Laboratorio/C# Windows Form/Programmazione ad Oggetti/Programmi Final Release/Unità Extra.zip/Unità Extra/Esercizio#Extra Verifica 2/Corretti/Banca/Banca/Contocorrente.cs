﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiBanca
{
    class Contocorrente : Strumentobancario
    {
        private int numero;
        private int totversamenti;
        private int totprelievi;
        private string cognom;

        public Contocorrente(int num, int totvers, int totprel, string cogn) : base(cogn)
        { numero = num; totversamenti = totvers; totprelievi = totprel; cognom = cogn; }

        public int NUMERO { get { return numero; } set { numero = value; } }
        public int TOTVERSAMENTI { get { return totversamenti; } set { totversamenti = value; } }
        public int TOTPRELIEVI { get { return totprelievi; } set { totprelievi = value; } }
        public string COGNOM { get { return cognome; } set { cognome = value; } }

        public override double saldo()
        {
            int saldo = 0;
            saldo = totversamenti - totprelievi;

            if (saldo >= 0)
            {
                int s, nuovotot;
                s = (saldo * 5) / 100;
                nuovotot = saldo + s;

                return nuovotot;
            }
            else
            {
                return saldo;
            }
            
        }
    }
}
