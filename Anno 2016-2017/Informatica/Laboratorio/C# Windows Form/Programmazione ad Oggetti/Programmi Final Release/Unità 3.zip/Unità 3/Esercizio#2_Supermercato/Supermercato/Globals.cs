﻿
namespace Prodotti
{
    class Globals
    {
        public static Prodotto[] Carrello = new Prodotto[4];
    }
}
