﻿
namespace Prodotti
{
    class Pasta : Prodotto
    {
        protected int quantita, costoalkg;

        public Pasta(string denomin,int code,int scont,int quant,int kg) 
            : base(denomin,code,scont)
        {
            quantita = quant;
            costoalkg = kg;
        }

        public int valorizzatore()
        {
            int tot;
            tot = quantita * costoalkg;
            return tot;
        }
    }
}
