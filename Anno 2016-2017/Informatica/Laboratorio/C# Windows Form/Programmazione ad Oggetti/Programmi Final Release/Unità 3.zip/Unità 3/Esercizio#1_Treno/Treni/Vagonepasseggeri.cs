﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiTreno
{
    class Vagonepasseggeri : Vagoneferroviario
    {
        protected string Classe;
        protected int PostiTotali;
        protected int PostiOccupati;
        protected int pesovuotoer;

        public Vagonepasseggeri(string cla, int posttot, int postoc,string cod,int pesovuoto,string azienda,int anno) 
            : base(cod,pesovuoto,azienda,anno)
        {
            Classe = cla;
            PostiTotali = posttot;
            PostiOccupati = postoc;
            pesovuotoer = pesovuoto;
        }

        public override int peso()
        {
            int tolleranza = Utility.Tolleranza(1);
            int peso = pesovuotoer + PostiOccupati * 65 + tolleranza; 
            return peso;
        }
    }
}
