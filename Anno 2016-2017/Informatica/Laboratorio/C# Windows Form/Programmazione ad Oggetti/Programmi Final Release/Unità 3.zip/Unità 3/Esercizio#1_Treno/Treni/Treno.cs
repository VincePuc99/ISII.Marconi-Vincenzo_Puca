﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiTreno
{
    class Treno
    {
        public static Vagoneferroviario[] Convoglio = new Vagoneferroviario[5];
    }
}
