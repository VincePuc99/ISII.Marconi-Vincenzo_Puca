﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiTreno
{
    class Vagonemerci : Vagoneferroviario
    {
        protected int MassimoCarico;
        protected int CaricoEffettivo;
        protected int pesovuotoer;

        public Vagonemerci(int maxcar,int careffet,string codice,int pesvuoto,string azienda,int anno) : base(codice,pesvuoto,azienda,anno)
        {
            MassimoCarico = maxcar;
            CaricoEffettivo = careffet;
            pesovuotoer = pesvuoto;
        }

        public override int peso()
        {
            int tolleranza = Utility.Tolleranza(2);
            int peso = pesovuotoer + CaricoEffettivo + tolleranza;
            return peso;
        }

    }
}
