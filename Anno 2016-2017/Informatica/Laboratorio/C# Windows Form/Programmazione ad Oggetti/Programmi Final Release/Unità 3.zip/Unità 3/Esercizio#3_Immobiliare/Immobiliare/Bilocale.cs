﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiImmobiliare
{
    class Bilocale : Appartamento
    {
        protected bool postoauto;
        protected int metratura;

        public Bilocale(bool posto,string vi,string numciv,int metr,int pian,int ann) 
            : base (vi,numciv,metr,pian,ann)
        {
            postoauto = posto;
            metratura = metr;
        }

        public override double Calcolaaffitto()
        {
            double importoaffitto;
            if(postoauto == true)
            {
                importoaffitto = Convert.ToDouble(metratura) * 1000 * Utility.coefficenteappartamento(2) * 100;
            }
            else
            {
                importoaffitto = Convert.ToDouble(metratura) * 1000 * Utility.coefficenteappartamento(2);
            }
            
            return importoaffitto;
        }
    }   
}
