﻿
namespace OggettiImmobiliare
{
    class Utility
    {
        public static double coefficenteappartamento(double t)
        {
            double importo = 0.0;
            if (t == 1.2)
            {
                importo = 2;
            }
            else
            {
                importo = 3;
            }
            return importo;
        }

        public static bool verificasevuoto()
        {
            bool vuoto = false;

            for (int i = 0; i < 3; i++)
            {
                if (Globals.Palazzo1[i] == null)
                {
                    vuoto = true;
                }

                if (Globals.Palazzo3[i] == null)
                {
                    vuoto = true;
                }
            }

            for (int i = 0; i < 2; i++)
            {
                if (Globals.Palazzo2[i] == null)
                {
                    vuoto = true;
                }
            }
            return vuoto;
        }
    }
}
