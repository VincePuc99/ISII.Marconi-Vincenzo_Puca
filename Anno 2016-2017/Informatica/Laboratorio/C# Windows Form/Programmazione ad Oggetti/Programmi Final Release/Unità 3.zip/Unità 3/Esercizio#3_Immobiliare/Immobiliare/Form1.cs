﻿using System;
using System.Drawing;
using System.Windows.Forms;
using OggettiImmobiliare;

namespace Immobiliare
{
    public partial class frmmain : Form
    {
        static int cont = 0;
        static int contpal1 = 0, contpal2 = 0, contpal3 = 0;

        public frmmain()
        {
            InitializeComponent();
            cmbvie.Items.Add("Via Dante");
            cmbvie.Items.Add("Via Bianchi");
            cmbvie.Items.Add("Via Cella");

            bttapp1.BackColor = Color.White;
            bttapp2.BackColor = Color.White;
            bttapp3.BackColor = Color.White;
            bttapp4.BackColor = Color.White;
            bttapp5.BackColor = Color.White;
            bttapp6.BackColor = Color.White;
            bttapp7.BackColor = Color.White;
            bttapp8.BackColor = Color.White;

            grptrilocale.Enabled = false;

            rdbbilocale.Checked = true;
            rdbtuttiappartamenti.Checked = true;

        }

        private void frmmain_Load(object sender, EventArgs e)
        {

        }

        private void cmbvie_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbvie.SelectedIndex == 0)
            {
                txtannodicostr.Text = "1975";
                txtnumerocivico.Text = "8";
            }

            if (cmbvie.SelectedIndex == 1)
            {
                txtannodicostr.Text = "1980";
                txtnumerocivico.Text = "10";
            }

            if (cmbvie.SelectedIndex == 2)
            {
                txtannodicostr.Text = "1985";
                txtnumerocivico.Text = "15";
            }
        }

        private void bttaggiungiappartamento_Click(object sender, EventArgs e)
        {
            if (cont < 8)
            {
                    if (cmbvie.SelectedItem.ToString() == "Via Dante")
                    {
                        if (contpal1 < 3)
                        {
                            btterr.BackColor = Color.Green;

                            if (rdbbilocale.Checked == true)
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo1[contpal1] = new Bilocale(chkpostoauto.Checked,cmbvie.SelectedItem.ToString(),txtnumerocivico.Text,metr,pian,ann);
                                
                                if (contpal1 == 0)
                                {
                                    bttapp1.BackColor = Color.LimeGreen;
                                }
                                else if (contpal1 == 1)
                                {
                                    bttapp2.BackColor = Color.LimeGreen;
                                }
                                else
                                {
                                    bttapp3.BackColor = Color.LimeGreen;
                                }
                            }
                            else
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo1[contpal1] = new Trilocale(chkbalcone.Checked, chkgarage.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);

                                if (contpal1 == 0)
                                {
                                    bttapp1.BackColor = Color.Blue;
                                }
                                else if (contpal1 == 1)
                                {
                                    bttapp2.BackColor = Color.Blue;
                                }
                                else
                                {
                                    bttapp3.BackColor = Color.Blue;
                                }
                            }
                            contpal1++;
                        }
                        else
                        {
                            btterr.BackColor = Color.Red;
                            cont--;
                        }
                    }//fine via dante
         
                    if (cmbvie.SelectedItem.ToString() == "Via Bianchi")
                    {
                        if (contpal2< 2)
                        {
                            btterr.BackColor = Color.Green;

                            if (rdbbilocale.Checked == true)
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo2[contpal2] = new Bilocale(chkpostoauto.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);

                                if (contpal2 == 0)
                                {
                                    bttapp4.BackColor = Color.LimeGreen;
                                }
                                else
                                {
                                    bttapp5.BackColor = Color.LimeGreen;
                                }
                            }
                            else
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo2[contpal2] = new Trilocale(chkbalcone.Checked, chkgarage.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);

                                if (contpal2 == 0)
                                {
                                    bttapp4.BackColor = Color.Blue;
                                }
                                else
                                {
                                    bttapp5.BackColor = Color.Blue;
                                }
                            }
                            contpal2++;
                        }
                        else
                        {
                            btterr.BackColor = Color.Red;
                            cont--;
                        }
                    }//fine via bianchi 

                    if (cmbvie.SelectedItem.ToString() == "Via Cella")
                    {
                        if (contpal3 < 3)
                        {
                            btterr.BackColor = Color.Green;

                            if (rdbbilocale.Checked == true)
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo3[contpal3] = new Bilocale(chkpostoauto.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);

                                if (contpal3 == 0)
                                {
                                    bttapp6.BackColor = Color.LimeGreen;
                                }
                                else if (contpal3 == 1)
                                {
                                    bttapp7.BackColor = Color.LimeGreen;
                                }
                                else
                                {
                                    bttapp8.BackColor = Color.LimeGreen;
                                }
                            }
                            else
                            {
                                int metr = Int16.Parse(txtmetratura.Text);
                                int pian = Int16.Parse(txtpiano.Text);
                                int ann = Int16.Parse(txtannodicostr.Text);
                                Globals.Palazzo3[contpal3] = new Trilocale(chkbalcone.Checked, chkgarage.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);

                                if (contpal3 == 0)
                                {
                                    bttapp6.BackColor = Color.Blue;
                                }
                                else if (contpal3 == 1)
                                {
                                    bttapp7.BackColor = Color.Blue;
                                }
                                else
                                {
                                    bttapp8.BackColor = Color.Blue;
                                }
                            }
                            contpal3++;
                        }
                        else
                        {
                            btterr.BackColor = Color.Red;
                            cont--;
                        }
                    }//fine via cella                     
            }
            else
            {
                btterr.BackColor = Color.Yellow;
                bttaggiungiappartamento.Enabled = false;
                grpaffitto.Enabled = true;
                btteliminappartamento.Enabled = true;
            }

            cont++;
        }

        private void rdbbilocale_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbbilocale.Checked == true)
            {
                grpbilocale.Enabled = true;
                grptrilocale.Enabled = false;
            }
        }

        private void rdbtrilocale_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtrilocale.Checked == true)
            {
                grpbilocale.Enabled = false;
                grptrilocale.Enabled = true;
            }
        }

        private void bttcalcola_Click(object sender, EventArgs e)
        {
            bool check;
            double totale = 0.0;

            check = Utility.verificasevuoto();

            if (check == false)
            {           
                if (rdbtuttiappartamenti.Checked == true)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        totale += Globals.Palazzo1[i].Calcolaaffitto();
                        totale += Globals.Palazzo3[i].Calcolaaffitto();
                    }

                    for (int j = 0; j < 2; j++)
                    {
                        totale += Globals.Palazzo2[j].Calcolaaffitto();
                    }

                    txtdisplay.Text = "" + totale;
                }//fine if totale

            }
            else
            {
                txtdisplay.Text = "Almeno 1 elimin.";
                rdbtuttiappartamenti.Enabled = false;
            }

            bool[] vuoto1 = new bool[3];
            bool[] vuoto2 = new bool[3];
            bool[] vuoto3 = new bool[3];

            //
            for (int i = 0; i < 3; i++)  //verifica
            {
                if (Globals.Palazzo1[i] == null)
                {
                    vuoto1[i] = true;
                }

                if (Globals.Palazzo3[i] == null)
                {
                    vuoto3[i] = true;
                }
            }

            for (int i = 0; i < 2; i++) //verifica
            {
                if (Globals.Palazzo2[i] == null)
                {
                    vuoto2[i] = true;
                }
            }
            //
                if (rdbsingoloappartamento.Checked == true)
                {
                    if (rdbbilocale.Checked == true)
                    {
                        int metr = Int16.Parse(txtmetratura.Text);
                        int pian = Int16.Parse(txtpiano.Text);
                        int ann = Int16.Parse(txtannodicostr.Text);
                        Globals.singlearray[0] = new Bilocale(chkpostoauto.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);
                    }
                    else
                    {
                        int metr = Int16.Parse(txtmetratura.Text);
                        int pian = Int16.Parse(txtpiano.Text);
                        int ann = Int16.Parse(txtannodicostr.Text);
                        Globals.singlearray[0] = new Trilocale(chkbalcone.Checked, chkgarage.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);
                    }

                    bool trovato = false;

                    if (cmbvie.SelectedItem.ToString() == "Via Dante")
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            if (vuoto1[i] == false)
                            {
                                if (Globals.singlearray[0].ToString() == Globals.Palazzo1[i].ToString())
                                {
                                    totale += Globals.Palazzo1[i].Calcolaaffitto();
                                    trovato = true;
                                }
                            }
                            else
                            {
                                txtdisplay.Text = "Nessun appartamento";
                            }
                        }
                    }//fine via dante

                    if (cmbvie.SelectedItem.ToString() == "Via Cella")
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            if (vuoto3[i] == false)
                            {
                                if (Globals.singlearray[0].ToString() == Globals.Palazzo3[i].ToString())
                                {
                                    totale += Globals.Palazzo3[i].Calcolaaffitto();
                                    trovato = true;
                                }
                            }
                            else
                            {
                                txtdisplay.Text = "Nessun appartamento";
                            }
                        }
                    }//fine via cella

                    if (cmbvie.SelectedItem.ToString() == "Via Bianchi")
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (vuoto2[i] == false)
                            {
                                if (Globals.singlearray[0].ToString() == Globals.Palazzo2[i].ToString())
                                {
                                    totale += Globals.Palazzo2[i].Calcolaaffitto();
                                    trovato = true;
                                }
                            }
                            else
                            {
                                txtdisplay.Text = "Nessun appartamento";
                            }
                        }
                    }//fine via bianchi

                    if (trovato == true)
                    {
                        txtdisplay.Text = "" + totale;
                    }
                    else
                    {
                        txtdisplay.Text = "Nessun appartamento";
                    }
                }//fine if singolo appartamento
        
        }//fine button

        private void rdbtuttiappartamenti_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void btteliminappartamento_Click(object sender, EventArgs e)
        {
            bool trovato = false;
            if (rdbbilocale.Checked == true)
            {
                int metr = Int16.Parse(txtmetratura.Text);
                int pian = Int16.Parse(txtpiano.Text);
                int ann = Int16.Parse(txtannodicostr.Text);
                Globals.singlearray[0] = new Bilocale(chkpostoauto.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);
            }
            else
            {
                int metr = Int16.Parse(txtmetratura.Text);
                int pian = Int16.Parse(txtpiano.Text);
                int ann = Int16.Parse(txtannodicostr.Text);
                Globals.singlearray[0] = new Trilocale(chkbalcone.Checked, chkgarage.Checked, cmbvie.SelectedItem.ToString(), txtnumerocivico.Text, metr, pian, ann);
            }

            bool[] vuoto1 = new bool[3];
            bool[] vuoto2 = new bool[3];
            bool[] vuoto3 = new bool[3];
            //
            for (int i = 0; i < 3; i++)  //verifica
            {
                if (Globals.Palazzo1[i] == null)
                {
                    vuoto1[i] = true;
                }

                if (Globals.Palazzo3[i] == null)
                {
                    vuoto3[i] = true;
                }
            }

            for (int i = 0; i < 2; i++) //verifica
            {
                if (Globals.Palazzo2[i] == null)
                {
                    vuoto2[i] = true;
                }
            }
            //

            if (cmbvie.SelectedItem.ToString() == "Via Dante")
            {
                for (int i = 0; i < 3; i++)
                {
                    if (vuoto1[i] == false)
                    {
                        if (Globals.singlearray[0].ToString() == Globals.Palazzo1[i].ToString())
                        {
                            Globals.Palazzo1[i] = null;
                            trovato = true;
                        }
                    }
                    else
                    {
                        txtdisplay.Text = "Nessun appartamento";
                    }
                }
            }//fine via dante

            if (cmbvie.SelectedItem.ToString() == "Via Cella")
            {
                for (int i = 0; i < 3; i++)
                {
                    if (vuoto3[i] == false)
                    {
                        if (Globals.singlearray[0].ToString() == Globals.Palazzo3[i].ToString())
                        {
                            Globals.Palazzo3[i] = null;
                            trovato = true;
                        }
                    }
                    else
                    {
                        txtdisplay.Text = "Nessun appartamento";
                    }
                }
            }//fine via cella

            if (cmbvie.SelectedItem.ToString() == "Via Bianchi")
            {
                for (int i = 0; i < 2; i++)
                {
                    if (vuoto2[i] == false)
                    {
                        if (Globals.singlearray[0].ToString() == Globals.Palazzo2[i].ToString())
                        {
                            Globals.Palazzo2[i] = null;
                            trovato = true;
                        }
                    }
                    else
                    {
                        txtdisplay.Text = "Nessun appartamento";
                    }
                }
            }//fine via bianchi

            if (trovato == true)
            {
                txtdisplay.Text = "!ELIMINATO!";
            }
            else
            {
                txtdisplay.Text = "Nessun appartamento";
            }
        }//fine button
    }
}
