﻿
namespace Prodotti
{
    class Latte : Prodotto
    {
        protected int quantita, costoallitro;

        public Latte(string denomin, int code, int scont, int quant, int kg)
            : base(denomin, code, scont)
        {
            quantita = quant;
            costoallitro = kg;
        }

        public int valorizzatore()
        {
            int tot;
            tot = quantita * costoallitro;
            return tot;
        }
    }
}
