﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OggettiTreno;

namespace Treni
{
    public partial class frmain : Form
    {
        static int cont = 0;
        public frmain()
        {
            InitializeComponent();
        }

        private void rdbpasseggeri_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbpasseggeri.Checked == true)
            {
                grpvagpass.Enabled = true;
            }
            else
                grpvagpass.Enabled = false;
        }

        private void rdbmerci_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbmerci.Checked == true)
            {
                grpvagonemerci.Enabled = true;
            }
            else
                grpvagonemerci.Enabled = false;
        }

        private void bttaggi_Click(object sender, EventArgs e)
        {

            if (cont < 5)
            {
                
                if (rdbmerci.Checked == true)
                { 
                    btterr.BackColor = Color.Green;

                    int max = Int32.Parse(txtmaxcarico.Text);
                    int eff = Int32.Parse(txtcaricoeff.Text);
                    int ann = Int32.Parse(txtanno.Text);
                    int pes = Int32.Parse(txtpeso.Text);

                    Treno.Convoglio[cont] = new Vagonemerci(max,eff,txtcode.Text,pes,txtcostrutt.Text,ann);
                }
                else
                {
                    btterr.BackColor = Color.Green;
                    int postot = Int32.Parse(txtpostitot.Text);
                    int postocc = Int32.Parse(txtpostioccup.Text);
                    int pesovuoto = Int32.Parse(txtpeso.Text);
                    int ann = Int32.Parse(txtanno.Text);

                    Treno.Convoglio[cont] = new Vagonepasseggeri(cmbclasse.Text, postot, postocc, txtcode.Text, pesovuoto, txtcostrutt.Text, ann);

                }

                cont++; 
            }
            else
            {
                bttaggi.Enabled = false;
                btterr.BackColor = Color.Yellow;
            }
        }//fine void

        private void frmain_Load(object sender, EventArgs e)
        {

        }

        private void bttcalcola_Click(object sender, EventArgs e)
        {
            int tot = 0;
            int totale = 0;

            for (int i = 0; i < 5; i++)
            {
               tot = Treno.Convoglio[i].peso();
               totale += tot;
            }

            txtpesototale.Text = "" + totale;
          
        }
    }
}
