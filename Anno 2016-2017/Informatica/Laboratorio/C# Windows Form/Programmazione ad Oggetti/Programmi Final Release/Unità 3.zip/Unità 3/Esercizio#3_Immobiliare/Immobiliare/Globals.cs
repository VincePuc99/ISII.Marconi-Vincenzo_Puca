﻿
namespace OggettiImmobiliare
{
    class Globals
    {
        public static Appartamento[] Palazzo1 = new Appartamento[3];
        public static Appartamento[] Palazzo2 = new Appartamento[2];
        public static Appartamento[] Palazzo3 = new Appartamento[3];
        public static Appartamento[] singlearray = new Appartamento[1];
    }
}
