﻿namespace Treni
{
    partial class frmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmain));
            this.grpgrafico = new System.Windows.Forms.GroupBox();
            this.bttc5 = new System.Windows.Forms.Button();
            this.bttmotrice = new System.Windows.Forms.Button();
            this.bttc1 = new System.Windows.Forms.Button();
            this.bttc4 = new System.Windows.Forms.Button();
            this.bttc2 = new System.Windows.Forms.Button();
            this.bttc3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbmerci = new System.Windows.Forms.RadioButton();
            this.rdbpasseggeri = new System.Windows.Forms.RadioButton();
            this.grpinfo = new System.Windows.Forms.GroupBox();
            this.txtanno = new System.Windows.Forms.TextBox();
            this.txtpeso = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcostrutt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpvagpass = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtpostioccup = new System.Windows.Forms.TextBox();
            this.txtpostitot = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbclasse = new System.Windows.Forms.ComboBox();
            this.grpvagonemerci = new System.Windows.Forms.GroupBox();
            this.txtcaricoeff = new System.Windows.Forms.TextBox();
            this.txtmaxcarico = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.bttaggi = new System.Windows.Forms.Button();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.txtpesototale = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btterr = new System.Windows.Forms.Button();
            this.grpgrafico.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpinfo.SuspendLayout();
            this.grpvagpass.SuspendLayout();
            this.grpvagonemerci.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpgrafico
            // 
            this.grpgrafico.Controls.Add(this.bttc5);
            this.grpgrafico.Controls.Add(this.bttmotrice);
            this.grpgrafico.Controls.Add(this.bttc1);
            this.grpgrafico.Controls.Add(this.bttc4);
            this.grpgrafico.Controls.Add(this.bttc2);
            this.grpgrafico.Controls.Add(this.bttc3);
            this.grpgrafico.Location = new System.Drawing.Point(13, 13);
            this.grpgrafico.Name = "grpgrafico";
            this.grpgrafico.Size = new System.Drawing.Size(313, 59);
            this.grpgrafico.TabIndex = 0;
            this.grpgrafico.TabStop = false;
            this.grpgrafico.Text = "Grafica treno in costruzione";
            // 
            // bttc5
            // 
            this.bttc5.Location = new System.Drawing.Point(261, 19);
            this.bttc5.Name = "bttc5";
            this.bttc5.Size = new System.Drawing.Size(42, 33);
            this.bttc5.TabIndex = 6;
            this.bttc5.Text = "C5";
            this.bttc5.UseVisualStyleBackColor = true;
            // 
            // bttmotrice
            // 
            this.bttmotrice.Location = new System.Drawing.Point(6, 19);
            this.bttmotrice.Name = "bttmotrice";
            this.bttmotrice.Size = new System.Drawing.Size(57, 33);
            this.bttmotrice.TabIndex = 2;
            this.bttmotrice.Text = "Motrice";
            this.bttmotrice.UseVisualStyleBackColor = true;
            // 
            // bttc1
            // 
            this.bttc1.Location = new System.Drawing.Point(69, 19);
            this.bttc1.Name = "bttc1";
            this.bttc1.Size = new System.Drawing.Size(42, 33);
            this.bttc1.TabIndex = 1;
            this.bttc1.Text = "C1";
            this.bttc1.UseVisualStyleBackColor = true;
            // 
            // bttc4
            // 
            this.bttc4.Location = new System.Drawing.Point(213, 19);
            this.bttc4.Name = "bttc4";
            this.bttc4.Size = new System.Drawing.Size(42, 33);
            this.bttc4.TabIndex = 5;
            this.bttc4.Text = "C4";
            this.bttc4.UseVisualStyleBackColor = true;
            // 
            // bttc2
            // 
            this.bttc2.Location = new System.Drawing.Point(117, 19);
            this.bttc2.Name = "bttc2";
            this.bttc2.Size = new System.Drawing.Size(42, 33);
            this.bttc2.TabIndex = 3;
            this.bttc2.Text = "C2";
            this.bttc2.UseVisualStyleBackColor = true;
            // 
            // bttc3
            // 
            this.bttc3.Location = new System.Drawing.Point(165, 19);
            this.bttc3.Name = "bttc3";
            this.bttc3.Size = new System.Drawing.Size(42, 33);
            this.bttc3.TabIndex = 4;
            this.bttc3.Text = "C3";
            this.bttc3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbmerci);
            this.groupBox1.Controls.Add(this.rdbpasseggeri);
            this.groupBox1.Location = new System.Drawing.Point(13, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 50);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipologia vagone da aggiungere";
            // 
            // rdbmerci
            // 
            this.rdbmerci.AutoSize = true;
            this.rdbmerci.Location = new System.Drawing.Point(128, 19);
            this.rdbmerci.Name = "rdbmerci";
            this.rdbmerci.Size = new System.Drawing.Size(90, 17);
            this.rdbmerci.TabIndex = 1;
            this.rdbmerci.TabStop = true;
            this.rdbmerci.Text = "Vagone merci";
            this.rdbmerci.UseVisualStyleBackColor = true;
            this.rdbmerci.CheckedChanged += new System.EventHandler(this.rdbmerci_CheckedChanged);
            // 
            // rdbpasseggeri
            // 
            this.rdbpasseggeri.AutoSize = true;
            this.rdbpasseggeri.Location = new System.Drawing.Point(6, 19);
            this.rdbpasseggeri.Name = "rdbpasseggeri";
            this.rdbpasseggeri.Size = new System.Drawing.Size(116, 17);
            this.rdbpasseggeri.TabIndex = 0;
            this.rdbpasseggeri.TabStop = true;
            this.rdbpasseggeri.Text = "Vagone passeggeri";
            this.rdbpasseggeri.UseVisualStyleBackColor = true;
            this.rdbpasseggeri.CheckedChanged += new System.EventHandler(this.rdbpasseggeri_CheckedChanged);
            // 
            // grpinfo
            // 
            this.grpinfo.Controls.Add(this.txtanno);
            this.grpinfo.Controls.Add(this.txtpeso);
            this.grpinfo.Controls.Add(this.label4);
            this.grpinfo.Controls.Add(this.label3);
            this.grpinfo.Controls.Add(this.txtcostrutt);
            this.grpinfo.Controls.Add(this.label2);
            this.grpinfo.Controls.Add(this.txtcode);
            this.grpinfo.Controls.Add(this.label1);
            this.grpinfo.Location = new System.Drawing.Point(13, 135);
            this.grpinfo.Name = "grpinfo";
            this.grpinfo.Size = new System.Drawing.Size(313, 85);
            this.grpinfo.TabIndex = 2;
            this.grpinfo.TabStop = false;
            this.grpinfo.Text = "Informazioni vagone";
            // 
            // txtanno
            // 
            this.txtanno.Location = new System.Drawing.Point(246, 51);
            this.txtanno.Name = "txtanno";
            this.txtanno.Size = new System.Drawing.Size(56, 20);
            this.txtanno.TabIndex = 7;
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(246, 18);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.Size = new System.Drawing.Size(56, 20);
            this.txtpeso.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(143, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Anno costruzione";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(143, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Peso a vuoto (KG.)";
            // 
            // txtcostrutt
            // 
            this.txtcostrutt.Location = new System.Drawing.Point(59, 51);
            this.txtcostrutt.Name = "txtcostrutt";
            this.txtcostrutt.Size = new System.Drawing.Size(78, 20);
            this.txtcostrutt.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Costruttore";
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(59, 18);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(78, 20);
            this.txtcode.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codice";
            // 
            // grpvagpass
            // 
            this.grpvagpass.Controls.Add(this.label7);
            this.grpvagpass.Controls.Add(this.txtpostioccup);
            this.grpvagpass.Controls.Add(this.txtpostitot);
            this.grpvagpass.Controls.Add(this.label6);
            this.grpvagpass.Controls.Add(this.label5);
            this.grpvagpass.Controls.Add(this.cmbclasse);
            this.grpvagpass.Enabled = false;
            this.grpvagpass.Location = new System.Drawing.Point(13, 227);
            this.grpvagpass.Name = "grpvagpass";
            this.grpvagpass.Size = new System.Drawing.Size(159, 100);
            this.grpvagpass.TabIndex = 3;
            this.grpvagpass.TabStop = false;
            this.grpvagpass.Text = "Vagone passeggeri";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Posti occup.";
            // 
            // txtpostioccup
            // 
            this.txtpostioccup.Location = new System.Drawing.Point(75, 71);
            this.txtpostioccup.Name = "txtpostioccup";
            this.txtpostioccup.Size = new System.Drawing.Size(78, 20);
            this.txtpostioccup.TabIndex = 4;
            // 
            // txtpostitot
            // 
            this.txtpostitot.Location = new System.Drawing.Point(75, 47);
            this.txtpostitot.Name = "txtpostitot";
            this.txtpostitot.Size = new System.Drawing.Size(78, 20);
            this.txtpostitot.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Posti totali";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Classe";
            // 
            // cmbclasse
            // 
            this.cmbclasse.FormattingEnabled = true;
            this.cmbclasse.Items.AddRange(new object[] {
            "Prima",
            "Seconda"});
            this.cmbclasse.Location = new System.Drawing.Point(75, 20);
            this.cmbclasse.Name = "cmbclasse";
            this.cmbclasse.Size = new System.Drawing.Size(78, 21);
            this.cmbclasse.TabIndex = 1;
            // 
            // grpvagonemerci
            // 
            this.grpvagonemerci.Controls.Add(this.txtcaricoeff);
            this.grpvagonemerci.Controls.Add(this.txtmaxcarico);
            this.grpvagonemerci.Controls.Add(this.label9);
            this.grpvagonemerci.Controls.Add(this.label8);
            this.grpvagonemerci.Enabled = false;
            this.grpvagonemerci.Location = new System.Drawing.Point(178, 227);
            this.grpvagonemerci.Name = "grpvagonemerci";
            this.grpvagonemerci.Size = new System.Drawing.Size(148, 100);
            this.grpvagonemerci.TabIndex = 4;
            this.grpvagonemerci.TabStop = false;
            this.grpvagonemerci.Text = "Vagone merci";
            // 
            // txtcaricoeff
            // 
            this.txtcaricoeff.Location = new System.Drawing.Point(6, 74);
            this.txtcaricoeff.Name = "txtcaricoeff";
            this.txtcaricoeff.Size = new System.Drawing.Size(131, 20);
            this.txtcaricoeff.TabIndex = 3;
            // 
            // txtmaxcarico
            // 
            this.txtmaxcarico.Location = new System.Drawing.Point(6, 36);
            this.txtmaxcarico.Name = "txtmaxcarico";
            this.txtmaxcarico.Size = new System.Drawing.Size(131, 20);
            this.txtmaxcarico.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Carico effettivo (KG.)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Max carico merci (KG.)";
            // 
            // bttaggi
            // 
            this.bttaggi.Location = new System.Drawing.Point(13, 334);
            this.bttaggi.Name = "bttaggi";
            this.bttaggi.Size = new System.Drawing.Size(285, 23);
            this.bttaggi.TabIndex = 5;
            this.bttaggi.Text = "Aggiungi";
            this.bttaggi.UseVisualStyleBackColor = true;
            this.bttaggi.Click += new System.EventHandler(this.bttaggi_Click);
            // 
            // bttcalcola
            // 
            this.bttcalcola.Location = new System.Drawing.Point(13, 364);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(159, 23);
            this.bttcalcola.TabIndex = 6;
            this.bttcalcola.Text = "Calcola peso complessivo";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.bttcalcola_Click);
            // 
            // txtpesototale
            // 
            this.txtpesototale.Location = new System.Drawing.Point(209, 365);
            this.txtpesototale.Multiline = true;
            this.txtpesototale.Name = "txtpesototale";
            this.txtpesototale.Size = new System.Drawing.Size(117, 23);
            this.txtpesototale.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(178, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "KG.";
            // 
            // btterr
            // 
            this.btterr.Location = new System.Drawing.Point(304, 334);
            this.btterr.Name = "btterr";
            this.btterr.Size = new System.Drawing.Size(22, 23);
            this.btterr.TabIndex = 9;
            this.btterr.Text = " ";
            this.btterr.UseVisualStyleBackColor = true;
            // 
            // frmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 400);
            this.Controls.Add(this.btterr);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtpesototale);
            this.Controls.Add(this.bttcalcola);
            this.Controls.Add(this.bttaggi);
            this.Controls.Add(this.grpvagonemerci);
            this.Controls.Add(this.grpvagpass);
            this.Controls.Add(this.grpinfo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpgrafico);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmain";
            this.ShowInTaskbar = false;
            this.Text = "Composizione Treni";
            this.Load += new System.EventHandler(this.frmain_Load);
            this.grpgrafico.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpinfo.ResumeLayout(false);
            this.grpinfo.PerformLayout();
            this.grpvagpass.ResumeLayout(false);
            this.grpvagpass.PerformLayout();
            this.grpvagonemerci.ResumeLayout(false);
            this.grpvagonemerci.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpgrafico;
        private System.Windows.Forms.Button bttc5;
        private System.Windows.Forms.Button bttmotrice;
        private System.Windows.Forms.Button bttc1;
        private System.Windows.Forms.Button bttc4;
        private System.Windows.Forms.Button bttc2;
        private System.Windows.Forms.Button bttc3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbmerci;
        private System.Windows.Forms.RadioButton rdbpasseggeri;
        private System.Windows.Forms.GroupBox grpinfo;
        private System.Windows.Forms.TextBox txtanno;
        private System.Windows.Forms.TextBox txtpeso;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcostrutt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpvagpass;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtpostioccup;
        private System.Windows.Forms.TextBox txtpostitot;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbclasse;
        private System.Windows.Forms.GroupBox grpvagonemerci;
        private System.Windows.Forms.TextBox txtcaricoeff;
        private System.Windows.Forms.TextBox txtmaxcarico;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button bttaggi;
        private System.Windows.Forms.Button bttcalcola;
        private System.Windows.Forms.TextBox txtpesototale;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btterr;
    }
}

