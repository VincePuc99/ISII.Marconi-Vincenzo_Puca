﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiTreno
{
        public abstract class Vagoneferroviario
        { 
        private string Codice; //alfanumerico di 10 caratteri
        private int PesoVuoto; //valore intero espresso in Kg.
        private string AziendaCostruttrice;
        private int AnnoCostruzione;

        public Vagoneferroviario(string code,int pesovuot,string azienda,int anno)
        {
            Codice = code;
            PesoVuoto = pesovuot;
            AziendaCostruttrice = azienda;
            AnnoCostruzione = anno;
        }
        public abstract int peso();
    }
}
