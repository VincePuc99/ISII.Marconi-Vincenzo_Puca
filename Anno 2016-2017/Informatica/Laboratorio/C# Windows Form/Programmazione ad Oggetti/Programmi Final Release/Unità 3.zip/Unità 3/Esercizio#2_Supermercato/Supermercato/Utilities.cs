﻿
namespace Prodotti
{
    class Utilities
    {
        public static int ImportoScontato(int codprod, int sconto)
        {
            if (codprod == 1)
            {        
                return 10;
            }
            else
            {
                return 20;
            }
        }//fine metodo

    }//fine classe
}
