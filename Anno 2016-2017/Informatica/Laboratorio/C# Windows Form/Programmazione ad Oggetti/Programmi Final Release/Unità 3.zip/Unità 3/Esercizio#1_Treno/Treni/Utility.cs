﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiTreno
{
    class Utility
    {

        static public int Tolleranza(int t)
        {
            int tolleranza = 0;

            if (t == 1)
            {
                tolleranza = 50;
            }
            else
            {
                tolleranza = 100;
            }

            return tolleranza;
        }
    }
}
