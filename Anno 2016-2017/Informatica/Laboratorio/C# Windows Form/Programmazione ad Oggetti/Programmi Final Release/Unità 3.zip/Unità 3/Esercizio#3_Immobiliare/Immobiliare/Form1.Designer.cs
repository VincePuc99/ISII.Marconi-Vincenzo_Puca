﻿namespace Immobiliare
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpappartamenti = new System.Windows.Forms.GroupBox();
            this.grplegenda = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btttrilocale = new System.Windows.Forms.Button();
            this.bttbilocale = new System.Windows.Forms.Button();
            this.bttnongestito = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bttapp5 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.bttapp8 = new System.Windows.Forms.Button();
            this.bttapp4 = new System.Windows.Forms.Button();
            this.bttapp7 = new System.Windows.Forms.Button();
            this.bttapp6 = new System.Windows.Forms.Button();
            this.bttapp3 = new System.Windows.Forms.Button();
            this.bttapp2 = new System.Windows.Forms.Button();
            this.bttapp1 = new System.Windows.Forms.Button();
            this.grpinfoapp = new System.Windows.Forms.GroupBox();
            this.txtmetratura = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtpiano = new System.Windows.Forms.TextBox();
            this.txtannodicostr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtnumerocivico = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbvie = new System.Windows.Forms.ComboBox();
            this.rdbtrilocale = new System.Windows.Forms.RadioButton();
            this.rdbbilocale = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.grpbilocale = new System.Windows.Forms.GroupBox();
            this.chkpostoauto = new System.Windows.Forms.CheckBox();
            this.grptrilocale = new System.Windows.Forms.GroupBox();
            this.chkbalcone = new System.Windows.Forms.CheckBox();
            this.chkgarage = new System.Windows.Forms.CheckBox();
            this.bttaggiungiappartamento = new System.Windows.Forms.Button();
            this.btteliminappartamento = new System.Windows.Forms.Button();
            this.grpaffitto = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.rdbsingoloappartamento = new System.Windows.Forms.RadioButton();
            this.rdbtuttiappartamenti = new System.Windows.Forms.RadioButton();
            this.btterr = new System.Windows.Forms.Button();
            this.bttgiallo = new System.Windows.Forms.Button();
            this.bttrosso = new System.Windows.Forms.Button();
            this.bttverde = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.grpappartamenti.SuspendLayout();
            this.grplegenda.SuspendLayout();
            this.grpinfoapp.SuspendLayout();
            this.grpbilocale.SuspendLayout();
            this.grptrilocale.SuspendLayout();
            this.grpaffitto.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpappartamenti
            // 
            this.grpappartamenti.Controls.Add(this.grplegenda);
            this.grpappartamenti.Controls.Add(this.label6);
            this.grpappartamenti.Controls.Add(this.label5);
            this.grpappartamenti.Controls.Add(this.bttapp5);
            this.grpappartamenti.Controls.Add(this.label4);
            this.grpappartamenti.Controls.Add(this.bttapp8);
            this.grpappartamenti.Controls.Add(this.bttapp4);
            this.grpappartamenti.Controls.Add(this.bttapp7);
            this.grpappartamenti.Controls.Add(this.bttapp6);
            this.grpappartamenti.Controls.Add(this.bttapp3);
            this.grpappartamenti.Controls.Add(this.bttapp2);
            this.grpappartamenti.Controls.Add(this.bttapp1);
            this.grpappartamenti.Location = new System.Drawing.Point(13, 13);
            this.grpappartamenti.Name = "grpappartamenti";
            this.grpappartamenti.Size = new System.Drawing.Size(316, 158);
            this.grpappartamenti.TabIndex = 0;
            this.grpappartamenti.TabStop = false;
            this.grpappartamenti.Text = "Appartamenti gestiti";
            // 
            // grplegenda
            // 
            this.grplegenda.Controls.Add(this.label3);
            this.grplegenda.Controls.Add(this.label2);
            this.grplegenda.Controls.Add(this.label1);
            this.grplegenda.Controls.Add(this.btttrilocale);
            this.grplegenda.Controls.Add(this.bttbilocale);
            this.grplegenda.Controls.Add(this.bttnongestito);
            this.grplegenda.Location = new System.Drawing.Point(204, 47);
            this.grplegenda.Name = "grplegenda";
            this.grplegenda.Size = new System.Drawing.Size(106, 103);
            this.grplegenda.TabIndex = 9;
            this.grplegenda.TabStop = false;
            this.grplegenda.Text = "Legenda";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Trilocale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bilocale";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Non gestito";
            // 
            // btttrilocale
            // 
            this.btttrilocale.BackColor = System.Drawing.Color.Blue;
            this.btttrilocale.Enabled = false;
            this.btttrilocale.Location = new System.Drawing.Point(7, 74);
            this.btttrilocale.Name = "btttrilocale";
            this.btttrilocale.Size = new System.Drawing.Size(25, 23);
            this.btttrilocale.TabIndex = 2;
            this.btttrilocale.UseVisualStyleBackColor = false;
            // 
            // bttbilocale
            // 
            this.bttbilocale.BackColor = System.Drawing.Color.LimeGreen;
            this.bttbilocale.Enabled = false;
            this.bttbilocale.Location = new System.Drawing.Point(7, 45);
            this.bttbilocale.Name = "bttbilocale";
            this.bttbilocale.Size = new System.Drawing.Size(25, 23);
            this.bttbilocale.TabIndex = 1;
            this.bttbilocale.UseVisualStyleBackColor = false;
            // 
            // bttnongestito
            // 
            this.bttnongestito.BackColor = System.Drawing.Color.White;
            this.bttnongestito.Enabled = false;
            this.bttnongestito.Location = new System.Drawing.Point(7, 16);
            this.bttnongestito.Name = "bttnongestito";
            this.bttnongestito.Size = new System.Drawing.Size(25, 23);
            this.bttnongestito.TabIndex = 0;
            this.bttnongestito.Text = " ";
            this.bttnongestito.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(134, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Via Cella";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Via Bianchi";
            // 
            // bttapp5
            // 
            this.bttapp5.Enabled = false;
            this.bttapp5.Location = new System.Drawing.Point(82, 58);
            this.bttapp5.Name = "bttapp5";
            this.bttapp5.Size = new System.Drawing.Size(40, 35);
            this.bttapp5.TabIndex = 8;
            this.bttapp5.Text = "5";
            this.bttapp5.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Via Dante";
            // 
            // bttapp8
            // 
            this.bttapp8.Enabled = false;
            this.bttapp8.Location = new System.Drawing.Point(157, 27);
            this.bttapp8.Name = "bttapp8";
            this.bttapp8.Size = new System.Drawing.Size(19, 25);
            this.bttapp8.TabIndex = 6;
            this.bttapp8.Text = "8";
            this.bttapp8.UseVisualStyleBackColor = true;
            // 
            // bttapp4
            // 
            this.bttapp4.Enabled = false;
            this.bttapp4.Location = new System.Drawing.Point(73, 99);
            this.bttapp4.Name = "bttapp4";
            this.bttapp4.Size = new System.Drawing.Size(58, 35);
            this.bttapp4.TabIndex = 7;
            this.bttapp4.Text = "4";
            this.bttapp4.UseVisualStyleBackColor = true;
            // 
            // bttapp7
            // 
            this.bttapp7.Enabled = false;
            this.bttapp7.Location = new System.Drawing.Point(146, 58);
            this.bttapp7.Name = "bttapp7";
            this.bttapp7.Size = new System.Drawing.Size(40, 35);
            this.bttapp7.TabIndex = 5;
            this.bttapp7.Text = "7";
            this.bttapp7.UseVisualStyleBackColor = true;
            // 
            // bttapp6
            // 
            this.bttapp6.Enabled = false;
            this.bttapp6.Location = new System.Drawing.Point(137, 99);
            this.bttapp6.Name = "bttapp6";
            this.bttapp6.Size = new System.Drawing.Size(58, 35);
            this.bttapp6.TabIndex = 4;
            this.bttapp6.Text = "6";
            this.bttapp6.UseVisualStyleBackColor = true;
            // 
            // bttapp3
            // 
            this.bttapp3.Enabled = false;
            this.bttapp3.Location = new System.Drawing.Point(30, 27);
            this.bttapp3.Name = "bttapp3";
            this.bttapp3.Size = new System.Drawing.Size(19, 25);
            this.bttapp3.TabIndex = 3;
            this.bttapp3.Text = "3";
            this.bttapp3.UseVisualStyleBackColor = true;
            // 
            // bttapp2
            // 
            this.bttapp2.Enabled = false;
            this.bttapp2.Location = new System.Drawing.Point(19, 58);
            this.bttapp2.Name = "bttapp2";
            this.bttapp2.Size = new System.Drawing.Size(40, 35);
            this.bttapp2.TabIndex = 2;
            this.bttapp2.Text = "2";
            this.bttapp2.UseVisualStyleBackColor = true;
            // 
            // bttapp1
            // 
            this.bttapp1.Enabled = false;
            this.bttapp1.Location = new System.Drawing.Point(10, 99);
            this.bttapp1.Name = "bttapp1";
            this.bttapp1.Size = new System.Drawing.Size(57, 35);
            this.bttapp1.TabIndex = 1;
            this.bttapp1.Text = "1";
            this.bttapp1.UseVisualStyleBackColor = true;
            // 
            // grpinfoapp
            // 
            this.grpinfoapp.Controls.Add(this.txtmetratura);
            this.grpinfoapp.Controls.Add(this.label11);
            this.grpinfoapp.Controls.Add(this.txtpiano);
            this.grpinfoapp.Controls.Add(this.txtannodicostr);
            this.grpinfoapp.Controls.Add(this.label9);
            this.grpinfoapp.Controls.Add(this.label10);
            this.grpinfoapp.Controls.Add(this.txtnumerocivico);
            this.grpinfoapp.Controls.Add(this.label12);
            this.grpinfoapp.Controls.Add(this.cmbvie);
            this.grpinfoapp.Controls.Add(this.rdbtrilocale);
            this.grpinfoapp.Controls.Add(this.rdbbilocale);
            this.grpinfoapp.Controls.Add(this.label7);
            this.grpinfoapp.Controls.Add(this.label8);
            this.grpinfoapp.Location = new System.Drawing.Point(13, 178);
            this.grpinfoapp.Name = "grpinfoapp";
            this.grpinfoapp.Size = new System.Drawing.Size(286, 116);
            this.grpinfoapp.TabIndex = 1;
            this.grpinfoapp.TabStop = false;
            this.grpinfoapp.Text = "Informazioni appartamento";
            // 
            // txtmetratura
            // 
            this.txtmetratura.Location = new System.Drawing.Point(232, 79);
            this.txtmetratura.Name = "txtmetratura";
            this.txtmetratura.Size = new System.Drawing.Size(42, 20);
            this.txtmetratura.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(174, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Metratura";
            // 
            // txtpiano
            // 
            this.txtpiano.Location = new System.Drawing.Point(232, 43);
            this.txtpiano.Name = "txtpiano";
            this.txtpiano.Size = new System.Drawing.Size(24, 20);
            this.txtpiano.TabIndex = 10;
            // 
            // txtannodicostr
            // 
            this.txtannodicostr.Location = new System.Drawing.Point(113, 79);
            this.txtannodicostr.Name = "txtannodicostr";
            this.txtannodicostr.ReadOnly = true;
            this.txtannodicostr.Size = new System.Drawing.Size(48, 20);
            this.txtannodicostr.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Anno di costruzione";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(192, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Piano";
            // 
            // txtnumerocivico
            // 
            this.txtnumerocivico.Location = new System.Drawing.Point(162, 43);
            this.txtnumerocivico.Name = "txtnumerocivico";
            this.txtnumerocivico.ReadOnly = true;
            this.txtnumerocivico.Size = new System.Drawing.Size(24, 20);
            this.txtnumerocivico.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(134, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "N.ro";
            // 
            // cmbvie
            // 
            this.cmbvie.FormattingEnabled = true;
            this.cmbvie.Location = new System.Drawing.Point(35, 43);
            this.cmbvie.Name = "cmbvie";
            this.cmbvie.Size = new System.Drawing.Size(94, 21);
            this.cmbvie.TabIndex = 3;
            this.cmbvie.SelectedIndexChanged += new System.EventHandler(this.cmbvie_SelectedIndexChanged);
            // 
            // rdbtrilocale
            // 
            this.rdbtrilocale.AutoSize = true;
            this.rdbtrilocale.Location = new System.Drawing.Point(141, 20);
            this.rdbtrilocale.Name = "rdbtrilocale";
            this.rdbtrilocale.Size = new System.Drawing.Size(65, 17);
            this.rdbtrilocale.TabIndex = 2;
            this.rdbtrilocale.TabStop = true;
            this.rdbtrilocale.Text = "Trilocale";
            this.rdbtrilocale.UseVisualStyleBackColor = true;
            this.rdbtrilocale.CheckedChanged += new System.EventHandler(this.rdbtrilocale_CheckedChanged);
            // 
            // rdbbilocale
            // 
            this.rdbbilocale.AutoSize = true;
            this.rdbbilocale.Location = new System.Drawing.Point(73, 20);
            this.rdbbilocale.Name = "rdbbilocale";
            this.rdbbilocale.Size = new System.Drawing.Size(62, 17);
            this.rdbbilocale.TabIndex = 1;
            this.rdbbilocale.TabStop = true;
            this.rdbbilocale.Text = "Bilocale";
            this.rdbbilocale.UseVisualStyleBackColor = true;
            this.rdbbilocale.CheckedChanged += new System.EventHandler(this.rdbbilocale_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tipo locale:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Via";
            // 
            // grpbilocale
            // 
            this.grpbilocale.Controls.Add(this.chkpostoauto);
            this.grpbilocale.Location = new System.Drawing.Point(305, 178);
            this.grpbilocale.Name = "grpbilocale";
            this.grpbilocale.Size = new System.Drawing.Size(86, 47);
            this.grpbilocale.TabIndex = 2;
            this.grpbilocale.TabStop = false;
            this.grpbilocale.Text = "Bilocale";
            // 
            // chkpostoauto
            // 
            this.chkpostoauto.AutoSize = true;
            this.chkpostoauto.Location = new System.Drawing.Point(6, 20);
            this.chkpostoauto.Name = "chkpostoauto";
            this.chkpostoauto.Size = new System.Drawing.Size(78, 17);
            this.chkpostoauto.TabIndex = 0;
            this.chkpostoauto.Text = "Posto Auto";
            this.chkpostoauto.UseVisualStyleBackColor = true;
            // 
            // grptrilocale
            // 
            this.grptrilocale.Controls.Add(this.chkbalcone);
            this.grptrilocale.Controls.Add(this.chkgarage);
            this.grptrilocale.Location = new System.Drawing.Point(305, 231);
            this.grptrilocale.Name = "grptrilocale";
            this.grptrilocale.Size = new System.Drawing.Size(86, 63);
            this.grptrilocale.TabIndex = 3;
            this.grptrilocale.TabStop = false;
            this.grptrilocale.Text = "Trilocale";
            // 
            // chkbalcone
            // 
            this.chkbalcone.AutoSize = true;
            this.chkbalcone.Location = new System.Drawing.Point(6, 39);
            this.chkbalcone.Name = "chkbalcone";
            this.chkbalcone.Size = new System.Drawing.Size(65, 17);
            this.chkbalcone.TabIndex = 5;
            this.chkbalcone.Text = "Balcone";
            this.chkbalcone.UseVisualStyleBackColor = true;
            // 
            // chkgarage
            // 
            this.chkgarage.AutoSize = true;
            this.chkgarage.Location = new System.Drawing.Point(6, 19);
            this.chkgarage.Name = "chkgarage";
            this.chkgarage.Size = new System.Drawing.Size(61, 17);
            this.chkgarage.TabIndex = 4;
            this.chkgarage.Text = "Garage";
            this.chkgarage.UseVisualStyleBackColor = true;
            // 
            // bttaggiungiappartamento
            // 
            this.bttaggiungiappartamento.Location = new System.Drawing.Point(13, 301);
            this.bttaggiungiappartamento.Name = "bttaggiungiappartamento";
            this.bttaggiungiappartamento.Size = new System.Drawing.Size(378, 23);
            this.bttaggiungiappartamento.TabIndex = 4;
            this.bttaggiungiappartamento.Text = "Aggiungi appartamento in gestione";
            this.bttaggiungiappartamento.UseVisualStyleBackColor = true;
            this.bttaggiungiappartamento.Click += new System.EventHandler(this.bttaggiungiappartamento_Click);
            // 
            // btteliminappartamento
            // 
            this.btteliminappartamento.Enabled = false;
            this.btteliminappartamento.Location = new System.Drawing.Point(13, 331);
            this.btteliminappartamento.Name = "btteliminappartamento";
            this.btteliminappartamento.Size = new System.Drawing.Size(378, 23);
            this.btteliminappartamento.TabIndex = 5;
            this.btteliminappartamento.Text = "Elimina appartamento in gestione";
            this.btteliminappartamento.UseVisualStyleBackColor = true;
            this.btteliminappartamento.Click += new System.EventHandler(this.btteliminappartamento_Click);
            // 
            // grpaffitto
            // 
            this.grpaffitto.Controls.Add(this.label13);
            this.grpaffitto.Controls.Add(this.txtdisplay);
            this.grpaffitto.Controls.Add(this.bttcalcola);
            this.grpaffitto.Controls.Add(this.rdbsingoloappartamento);
            this.grpaffitto.Controls.Add(this.rdbtuttiappartamenti);
            this.grpaffitto.Enabled = false;
            this.grpaffitto.Location = new System.Drawing.Point(13, 361);
            this.grpaffitto.Name = "grpaffitto";
            this.grpaffitto.Size = new System.Drawing.Size(378, 68);
            this.grpaffitto.TabIndex = 6;
            this.grpaffitto.TabStop = false;
            this.grpaffitto.Text = "Calcola affitto";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(232, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 39);
            this.label13.TabIndex = 4;
            this.label13.Text = "$";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(274, 20);
            this.txtdisplay.Multiline = true;
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.ReadOnly = true;
            this.txtdisplay.Size = new System.Drawing.Size(98, 41);
            this.txtdisplay.TabIndex = 3;
            // 
            // bttcalcola
            // 
            this.bttcalcola.Location = new System.Drawing.Point(157, 20);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(69, 41);
            this.bttcalcola.TabIndex = 2;
            this.bttcalcola.Text = "Calcola";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.bttcalcola_Click);
            // 
            // rdbsingoloappartamento
            // 
            this.rdbsingoloappartamento.AutoSize = true;
            this.rdbsingoloappartamento.Location = new System.Drawing.Point(10, 44);
            this.rdbsingoloappartamento.Name = "rdbsingoloappartamento";
            this.rdbsingoloappartamento.Size = new System.Drawing.Size(128, 17);
            this.rdbsingoloappartamento.TabIndex = 1;
            this.rdbsingoloappartamento.TabStop = true;
            this.rdbsingoloappartamento.Text = "Singolo appartamento";
            this.rdbsingoloappartamento.UseVisualStyleBackColor = true;
            // 
            // rdbtuttiappartamenti
            // 
            this.rdbtuttiappartamenti.AutoSize = true;
            this.rdbtuttiappartamenti.Location = new System.Drawing.Point(10, 20);
            this.rdbtuttiappartamenti.Name = "rdbtuttiappartamenti";
            this.rdbtuttiappartamenti.Size = new System.Drawing.Size(123, 17);
            this.rdbtuttiappartamenti.TabIndex = 0;
            this.rdbtuttiappartamenti.TabStop = true;
            this.rdbtuttiappartamenti.Text = "Tutti gli appartamenti";
            this.rdbtuttiappartamenti.UseVisualStyleBackColor = true;
            this.rdbtuttiappartamenti.CheckedChanged += new System.EventHandler(this.rdbtuttiappartamenti_CheckedChanged);
            // 
            // btterr
            // 
            this.btterr.Enabled = false;
            this.btterr.Location = new System.Drawing.Point(335, 29);
            this.btterr.Name = "btterr";
            this.btterr.Size = new System.Drawing.Size(24, 23);
            this.btterr.TabIndex = 8;
            this.btterr.Text = " ";
            this.btterr.UseVisualStyleBackColor = true;
            // 
            // bttgiallo
            // 
            this.bttgiallo.BackColor = System.Drawing.Color.Yellow;
            this.bttgiallo.Enabled = false;
            this.bttgiallo.Location = new System.Drawing.Point(335, 71);
            this.bttgiallo.Name = "bttgiallo";
            this.bttgiallo.Size = new System.Drawing.Size(11, 11);
            this.bttgiallo.TabIndex = 9;
            this.bttgiallo.Text = " ";
            this.bttgiallo.UseVisualStyleBackColor = false;
            // 
            // bttrosso
            // 
            this.bttrosso.BackColor = System.Drawing.Color.Red;
            this.bttrosso.Enabled = false;
            this.bttrosso.Location = new System.Drawing.Point(335, 105);
            this.bttrosso.Name = "bttrosso";
            this.bttrosso.Size = new System.Drawing.Size(11, 11);
            this.bttrosso.TabIndex = 10;
            this.bttrosso.Text = " ";
            this.bttrosso.UseVisualStyleBackColor = false;
            // 
            // bttverde
            // 
            this.bttverde.BackColor = System.Drawing.Color.Green;
            this.bttverde.Enabled = false;
            this.bttverde.Location = new System.Drawing.Point(335, 88);
            this.bttverde.Name = "bttverde";
            this.bttverde.Size = new System.Drawing.Size(11, 11);
            this.bttverde.TabIndex = 11;
            this.bttverde.Text = " ";
            this.bttverde.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(350, 70);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Pieno";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(350, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Aggiunto";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(350, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 26);
            this.label17.TabIndex = 14;
            this.label17.Text = "Palazzo\r\npieno";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(332, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 15;
            this.label18.Text = "Legenda";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(332, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "Indicatore";
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 451);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.bttverde);
            this.Controls.Add(this.bttrosso);
            this.Controls.Add(this.bttgiallo);
            this.Controls.Add(this.btterr);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.grpaffitto);
            this.Controls.Add(this.btteliminappartamento);
            this.Controls.Add(this.bttaggiungiappartamento);
            this.Controls.Add(this.grptrilocale);
            this.Controls.Add(this.grpbilocale);
            this.Controls.Add(this.grpinfoapp);
            this.Controls.Add(this.grpappartamenti);
            this.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Immobiliare";
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpappartamenti.ResumeLayout(false);
            this.grpappartamenti.PerformLayout();
            this.grplegenda.ResumeLayout(false);
            this.grplegenda.PerformLayout();
            this.grpinfoapp.ResumeLayout(false);
            this.grpinfoapp.PerformLayout();
            this.grpbilocale.ResumeLayout(false);
            this.grpbilocale.PerformLayout();
            this.grptrilocale.ResumeLayout(false);
            this.grptrilocale.PerformLayout();
            this.grpaffitto.ResumeLayout(false);
            this.grpaffitto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpappartamenti;
        private System.Windows.Forms.GroupBox grplegenda;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btttrilocale;
        private System.Windows.Forms.Button bttbilocale;
        private System.Windows.Forms.Button bttnongestito;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bttapp5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bttapp8;
        private System.Windows.Forms.Button bttapp4;
        private System.Windows.Forms.Button bttapp7;
        private System.Windows.Forms.Button bttapp6;
        private System.Windows.Forms.Button bttapp3;
        private System.Windows.Forms.Button bttapp2;
        private System.Windows.Forms.Button bttapp1;
        private System.Windows.Forms.GroupBox grpinfoapp;
        private System.Windows.Forms.TextBox txtmetratura;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtpiano;
        private System.Windows.Forms.TextBox txtannodicostr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtnumerocivico;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbvie;
        private System.Windows.Forms.RadioButton rdbtrilocale;
        private System.Windows.Forms.RadioButton rdbbilocale;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox grpbilocale;
        private System.Windows.Forms.CheckBox chkpostoauto;
        private System.Windows.Forms.GroupBox grptrilocale;
        private System.Windows.Forms.CheckBox chkbalcone;
        private System.Windows.Forms.CheckBox chkgarage;
        private System.Windows.Forms.Button bttaggiungiappartamento;
        private System.Windows.Forms.Button btteliminappartamento;
        private System.Windows.Forms.GroupBox grpaffitto;
        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.Button bttcalcola;
        private System.Windows.Forms.RadioButton rdbsingoloappartamento;
        private System.Windows.Forms.RadioButton rdbtuttiappartamenti;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btterr;
        private System.Windows.Forms.Button bttgiallo;
        private System.Windows.Forms.Button bttrosso;
        private System.Windows.Forms.Button bttverde;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
    }
}

