﻿namespace Supermercato
{
    partial class frmmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpscelta = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcosto = new System.Windows.Forms.TextBox();
            this.cmbtipoprod = new System.Windows.Forms.ComboBox();
            this.cmbquantità = new System.Windows.Forms.ComboBox();
            this.bttacquista = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txttot = new System.Windows.Forms.TextBox();
            this.txttotsconto = new System.Windows.Forms.TextBox();
            this.btttot = new System.Windows.Forms.Button();
            this.btttotscont = new System.Windows.Forms.Button();
            this.btterror = new System.Windows.Forms.Button();
            this.grpscelta.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpscelta
            // 
            this.grpscelta.Controls.Add(this.btterror);
            this.grpscelta.Controls.Add(this.cmbquantità);
            this.grpscelta.Controls.Add(this.cmbtipoprod);
            this.grpscelta.Controls.Add(this.txtcosto);
            this.grpscelta.Controls.Add(this.label3);
            this.grpscelta.Controls.Add(this.label2);
            this.grpscelta.Controls.Add(this.label1);
            this.grpscelta.Location = new System.Drawing.Point(12, 12);
            this.grpscelta.Name = "grpscelta";
            this.grpscelta.Size = new System.Drawing.Size(200, 62);
            this.grpscelta.TabIndex = 0;
            this.grpscelta.TabStop = false;
            this.grpscelta.Text = "Oggi acquisto...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo prodotto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Costo in $";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(142, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantità";
            // 
            // txtcosto
            // 
            this.txtcosto.Location = new System.Drawing.Point(85, 32);
            this.txtcosto.Name = "txtcosto";
            this.txtcosto.Size = new System.Drawing.Size(51, 20);
            this.txtcosto.TabIndex = 4;
            // 
            // cmbtipoprod
            // 
            this.cmbtipoprod.FormattingEnabled = true;
            this.cmbtipoprod.Items.AddRange(new object[] {
            "Pasta",
            "Latte"});
            this.cmbtipoprod.Location = new System.Drawing.Point(9, 31);
            this.cmbtipoprod.Name = "cmbtipoprod";
            this.cmbtipoprod.Size = new System.Drawing.Size(67, 21);
            this.cmbtipoprod.TabIndex = 5;
            // 
            // cmbquantità
            // 
            this.cmbquantità.FormattingEnabled = true;
            this.cmbquantità.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbquantità.Location = new System.Drawing.Point(145, 31);
            this.cmbquantità.Name = "cmbquantità";
            this.cmbquantità.Size = new System.Drawing.Size(44, 21);
            this.cmbquantità.TabIndex = 6;
            // 
            // bttacquista
            // 
            this.bttacquista.Location = new System.Drawing.Point(12, 81);
            this.bttacquista.Name = "bttacquista";
            this.bttacquista.Size = new System.Drawing.Size(200, 23);
            this.bttacquista.TabIndex = 1;
            this.bttacquista.Text = "Acquista";
            this.bttacquista.UseVisualStyleBackColor = true;
            this.bttacquista.Click += new System.EventHandler(this.bttacquista_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Importo da pagare in $";
            // 
            // txttot
            // 
            this.txttot.Location = new System.Drawing.Point(15, 127);
            this.txttot.Name = "txttot";
            this.txttot.ReadOnly = true;
            this.txttot.Size = new System.Drawing.Size(100, 20);
            this.txttot.TabIndex = 3;
            // 
            // txttotsconto
            // 
            this.txttotsconto.Location = new System.Drawing.Point(15, 154);
            this.txttotsconto.Name = "txttotsconto";
            this.txttotsconto.ReadOnly = true;
            this.txttotsconto.Size = new System.Drawing.Size(100, 20);
            this.txttotsconto.TabIndex = 4;
            // 
            // btttot
            // 
            this.btttot.Enabled = false;
            this.btttot.Location = new System.Drawing.Point(122, 127);
            this.btttot.Name = "btttot";
            this.btttot.Size = new System.Drawing.Size(90, 20);
            this.btttot.TabIndex = 5;
            this.btttot.Text = "Totale";
            this.btttot.UseVisualStyleBackColor = true;
            this.btttot.Click += new System.EventHandler(this.btttot_Click);
            // 
            // btttotscont
            // 
            this.btttotscont.Enabled = false;
            this.btttotscont.Location = new System.Drawing.Point(123, 154);
            this.btttotscont.Name = "btttotscont";
            this.btttotscont.Size = new System.Drawing.Size(90, 20);
            this.btttotscont.TabIndex = 6;
            this.btttotscont.Text = "Totale scontato";
            this.btttotscont.UseVisualStyleBackColor = true;
            this.btttotscont.Click += new System.EventHandler(this.btttotscont_Click);
            // 
            // btterror
            // 
            this.btterror.Location = new System.Drawing.Point(180, -1);
            this.btterror.Name = "btterror";
            this.btterror.Size = new System.Drawing.Size(14, 14);
            this.btterror.TabIndex = 7;
            this.btterror.UseVisualStyleBackColor = true;
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(226, 188);
            this.Controls.Add(this.btttotscont);
            this.Controls.Add(this.btttot);
            this.Controls.Add(this.txttotsconto);
            this.Controls.Add(this.txttot);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bttacquista);
            this.Controls.Add(this.grpscelta);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Supermercato";
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpscelta.ResumeLayout(false);
            this.grpscelta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpscelta;
        private System.Windows.Forms.ComboBox cmbquantità;
        private System.Windows.Forms.ComboBox cmbtipoprod;
        private System.Windows.Forms.TextBox txtcosto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttacquista;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttot;
        private System.Windows.Forms.TextBox txttotsconto;
        private System.Windows.Forms.Button btttot;
        private System.Windows.Forms.Button btttotscont;
        private System.Windows.Forms.Button btterror;
    }
}

