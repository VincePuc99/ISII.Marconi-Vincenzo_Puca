﻿
namespace Prodotti
{
    abstract class Prodotto
    {
        private string denominazione;
        private int codice, sconto;

        public Prodotto()
        {
            denominazione = "";
            codice = 0;
            sconto = 0;
        }

        public Prodotto(string denominaz,int cod,int scont)
        {
            denominazione = denominaz;
            codice = cod;
            sconto = scont;       
        }

        public string DENOMINAZIONE
        {
            get { return denominazione; }
            set { denominazione = value; }
        }

        public int SCONTO
        {
            get { return sconto; }
            set { sconto = value; }
        }

        public int CODICE
        {
            get { return codice; }
            set { codice = value; }
        }
    }
}
