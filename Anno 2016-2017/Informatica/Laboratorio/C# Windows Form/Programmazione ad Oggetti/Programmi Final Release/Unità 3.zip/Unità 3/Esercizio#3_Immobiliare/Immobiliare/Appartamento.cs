﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggettiImmobiliare
{
    public abstract class Appartamento
    {
       private string via,numerocivico;
       private int metratura, piano, anno;

       public Appartamento(string vi,string numciv,int metr,int pian,int ann)
       {
           via = vi;
           numerocivico = numciv;
           metratura = metr;
           piano = pian;
           anno = ann;  
       }

       public abstract double Calcolaaffitto();
    }
}
