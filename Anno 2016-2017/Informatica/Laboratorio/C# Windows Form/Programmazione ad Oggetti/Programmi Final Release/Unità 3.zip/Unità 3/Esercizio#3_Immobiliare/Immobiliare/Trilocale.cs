﻿using System;

namespace OggettiImmobiliare
{
    class Trilocale : Appartamento
    {
        protected bool balcone,garage;
        protected int metratura;

         public Trilocale(bool balc,bool gara,string vi,string numciv,int metr,int pian,int ann) 
            : base (vi,numciv,metr,pian,ann)
        {
            balcone = balc;
            garage = gara;
            metratura = metr;
        }


        public override double Calcolaaffitto()
        {
            double importoaffitto;
            if (balcone == true)
            {
                importoaffitto = Convert.ToDouble(metratura) * 1000 * Utility.coefficenteappartamento(3) * 200;
            }
            else
            {
                importoaffitto = Convert.ToDouble(metratura) * 1000 * Utility.coefficenteappartamento(3);
            }
            return importoaffitto;
        }
    }
}
