﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Prodotti;

namespace Supermercato
{
    public partial class frmmain : Form
    {
        static int cont = 0, totale = 0;
        double totscont = 0.0;
        public frmmain()
        {
            InitializeComponent();
        }

        private void frmmain_Load(object sender, EventArgs e)
        {

        }

        private void bttacquista_Click(object sender, EventArgs e)
        {
            if (txtcosto.Text != "" && cmbtipoprod.Text != "" && cmbquantità.Text != "")
            {               
                if (cont < 4)
                {
                    if (cmbtipoprod.SelectedItem.ToString() == "Latte")
                    {
                        btterror.BackColor = Color.Green;

                        int quantita = Int32.Parse(cmbquantità.SelectedItem.ToString());
                        int costolitro = Int32.Parse(txtcosto.Text);

                        Globals.Carrello[cont] = new Latte("Latte",2,20,quantita,costolitro);
                        Latte lt = new Latte("Latte", 2, 20, quantita, costolitro);

                        int tot;
                        tot = lt.valorizzatore();
                        totale += tot;

                        double s, nuovotot;
                        s = (tot * 20) / 100;
                        nuovotot = tot - s;

                        totscont += nuovotot;
                    }
                    else
                    {
                        btterror.BackColor = Color.Green;

                        int quantita = Int32.Parse(cmbquantità.SelectedItem.ToString());
                        int costokg = Int32.Parse(txtcosto.Text);

                        Globals.Carrello[cont] = new Pasta("Pasta", 1, 10, quantita, costokg);
                        Pasta pt = new Pasta("Pasta", 1, 10, quantita, costokg);

                        int tot;
                        tot = pt.valorizzatore();
                        totale += tot;

                        double s, nuovotot;
                        s = (tot * 10) / 100;
                        nuovotot = tot - s;

                        totscont += nuovotot;
                    }
                    cont++;
                }
                else
                {
                    bttacquista.Enabled = false;
                    grpscelta.Enabled = false;
                    btterror.BackColor = Color.Yellow;
                    btttot.Enabled = true;
                    btttotscont.Enabled = true;
                }
            }
            else
            {
                btterror.BackColor = Color.Red;            
            }
            
        }//fine button

        private void btttot_Click(object sender, EventArgs e)
        {
            txttot.Text = "" + totale;
        }//fine button

        private void btttotscont_Click(object sender, EventArgs e)
        {
            txttotsconto.Text = "" + totscont;
        }//fine button
    }
}
