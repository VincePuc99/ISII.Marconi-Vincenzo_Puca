﻿namespace Phrasebuilder
{
    partial class frmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmain));
            this.grpdisplay = new System.Windows.Forms.GroupBox();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.bttdecomponi = new System.Windows.Forms.Button();
            this.grpelementi = new System.Windows.Forms.GroupBox();
            this.cmbscelta = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bttvedirusltato = new System.Windows.Forms.Button();
            this.grpdisplay.SuspendLayout();
            this.grpelementi.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdisplay
            // 
            this.grpdisplay.Controls.Add(this.txtdisplay);
            this.grpdisplay.Location = new System.Drawing.Point(12, 12);
            this.grpdisplay.Name = "grpdisplay";
            this.grpdisplay.Size = new System.Drawing.Size(226, 141);
            this.grpdisplay.TabIndex = 0;
            this.grpdisplay.TabStop = false;
            this.grpdisplay.Text = "Display";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(6, 19);
            this.txtdisplay.Multiline = true;
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.Size = new System.Drawing.Size(214, 116);
            this.txtdisplay.TabIndex = 0;
            // 
            // bttdecomponi
            // 
            this.bttdecomponi.Location = new System.Drawing.Point(12, 160);
            this.bttdecomponi.Name = "bttdecomponi";
            this.bttdecomponi.Size = new System.Drawing.Size(105, 23);
            this.bttdecomponi.TabIndex = 1;
            this.bttdecomponi.Text = "Decomponi testo";
            this.bttdecomponi.UseVisualStyleBackColor = true;
            this.bttdecomponi.Click += new System.EventHandler(this.bttdecomponi_Click);
            // 
            // grpelementi
            // 
            this.grpelementi.Controls.Add(this.cmbscelta);
            this.grpelementi.Controls.Add(this.label1);
            this.grpelementi.Location = new System.Drawing.Point(12, 190);
            this.grpelementi.Name = "grpelementi";
            this.grpelementi.Size = new System.Drawing.Size(226, 80);
            this.grpelementi.TabIndex = 2;
            this.grpelementi.TabStop = false;
            this.grpelementi.Text = "Elementi del testo";
            // 
            // cmbscelta
            // 
            this.cmbscelta.FormattingEnabled = true;
            this.cmbscelta.Location = new System.Drawing.Point(6, 50);
            this.cmbscelta.Name = "cmbscelta";
            this.cmbscelta.Size = new System.Drawing.Size(214, 21);
            this.cmbscelta.TabIndex = 1;
            this.cmbscelta.SelectedIndexChanged += new System.EventHandler(this.cmbscelta_SelectedIndexChanged);
            this.cmbscelta.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.cmbscelta_MouseDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Selezionare i singoli elementi sino a \r\ncomporre una frase di senso compiuto";
            // 
            // bttvedirusltato
            // 
            this.bttvedirusltato.Location = new System.Drawing.Point(136, 160);
            this.bttvedirusltato.Name = "bttvedirusltato";
            this.bttvedirusltato.Size = new System.Drawing.Size(102, 23);
            this.bttvedirusltato.TabIndex = 3;
            this.bttvedirusltato.Text = "Confronta";
            this.bttvedirusltato.UseVisualStyleBackColor = true;
            this.bttvedirusltato.Click += new System.EventHandler(this.bttvedirusltato_Click);
            // 
            // frmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 279);
            this.Controls.Add(this.bttvedirusltato);
            this.Controls.Add(this.grpelementi);
            this.Controls.Add(this.bttdecomponi);
            this.Controls.Add(this.grpdisplay);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmain";
            this.Text = "Phrase builder";
            this.grpdisplay.ResumeLayout(false);
            this.grpdisplay.PerformLayout();
            this.grpelementi.ResumeLayout(false);
            this.grpelementi.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpdisplay;
        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.Button bttdecomponi;
        private System.Windows.Forms.GroupBox grpelementi;
        private System.Windows.Forms.ComboBox cmbscelta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttvedirusltato;
    }
}

