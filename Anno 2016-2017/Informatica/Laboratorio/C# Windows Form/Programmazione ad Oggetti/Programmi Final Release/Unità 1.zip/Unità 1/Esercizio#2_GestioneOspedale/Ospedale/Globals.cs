﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ospedale
{
    class Globals
    {
        //Variabili Globali
        public static Paziente[] Reparto = new Paziente[5];
    }
}
