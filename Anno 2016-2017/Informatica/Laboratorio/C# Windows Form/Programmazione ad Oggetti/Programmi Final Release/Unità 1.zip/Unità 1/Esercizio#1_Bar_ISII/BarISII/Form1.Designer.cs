﻿namespace BarISII
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbBanco = new System.Windows.Forms.GroupBox();
            this.rdbAranciata = new System.Windows.Forms.RadioButton();
            this.rdbCappuccino = new System.Windows.Forms.RadioButton();
            this.rdbCaffe = new System.Windows.Forms.RadioButton();
            this.lbl2 = new System.Windows.Forms.Label();
            this.tbxnome = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnOrdina = new System.Windows.Forms.Button();
            this.btnCancOrd = new System.Windows.Forms.Button();
            this.btnCalcola = new System.Windows.Forms.Button();
            this.grbScontrino = new System.Windows.Forms.GroupBox();
            this.tbx2 = new System.Windows.Forms.TextBox();
            this.grbBanco.SuspendLayout();
            this.grbScontrino.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbBanco
            // 
            this.grbBanco.Controls.Add(this.rdbAranciata);
            this.grbBanco.Controls.Add(this.rdbCappuccino);
            this.grbBanco.Controls.Add(this.rdbCaffe);
            this.grbBanco.Controls.Add(this.lbl2);
            this.grbBanco.Controls.Add(this.tbxnome);
            this.grbBanco.Controls.Add(this.lbl1);
            this.grbBanco.Location = new System.Drawing.Point(13, 13);
            this.grbBanco.Name = "grbBanco";
            this.grbBanco.Size = new System.Drawing.Size(287, 110);
            this.grbBanco.TabIndex = 0;
            this.grbBanco.TabStop = false;
            this.grbBanco.Text = "Banco del bar";
            // 
            // rdbAranciata
            // 
            this.rdbAranciata.AutoSize = true;
            this.rdbAranciata.Location = new System.Drawing.Point(197, 82);
            this.rdbAranciata.Name = "rdbAranciata";
            this.rdbAranciata.Size = new System.Drawing.Size(70, 17);
            this.rdbAranciata.TabIndex = 5;
            this.rdbAranciata.TabStop = true;
            this.rdbAranciata.Text = "Aranciata";
            this.rdbAranciata.UseVisualStyleBackColor = true;
            // 
            // rdbCappuccino
            // 
            this.rdbCappuccino.AutoSize = true;
            this.rdbCappuccino.Location = new System.Drawing.Point(90, 82);
            this.rdbCappuccino.Name = "rdbCappuccino";
            this.rdbCappuccino.Size = new System.Drawing.Size(82, 17);
            this.rdbCappuccino.TabIndex = 4;
            this.rdbCappuccino.TabStop = true;
            this.rdbCappuccino.Text = "Cappuccino";
            this.rdbCappuccino.UseVisualStyleBackColor = true;
            // 
            // rdbCaffe
            // 
            this.rdbCaffe.AutoSize = true;
            this.rdbCaffe.Location = new System.Drawing.Point(9, 82);
            this.rdbCaffe.Name = "rdbCaffe";
            this.rdbCaffe.Size = new System.Drawing.Size(50, 17);
            this.rdbCaffe.TabIndex = 3;
            this.rdbCaffe.TabStop = true;
            this.rdbCaffe.Text = "Caffè";
            this.rdbCaffe.UseVisualStyleBackColor = true;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(38, 56);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(203, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "---------------- Cosa vuoi ordinare? ----------------";
            // 
            // tbxnome
            // 
            this.tbxnome.Location = new System.Drawing.Point(106, 20);
            this.tbxnome.Name = "tbxnome";
            this.tbxnome.Size = new System.Drawing.Size(161, 20);
            this.tbxnome.TabIndex = 1;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(6, 23);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(81, 13);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Come ti chiami?";
            // 
            // btnOrdina
            // 
            this.btnOrdina.Location = new System.Drawing.Point(12, 129);
            this.btnOrdina.Name = "btnOrdina";
            this.btnOrdina.Size = new System.Drawing.Size(288, 23);
            this.btnOrdina.TabIndex = 1;
            this.btnOrdina.Text = "Ordina";
            this.btnOrdina.UseVisualStyleBackColor = true;
            this.btnOrdina.Click += new System.EventHandler(this.btnOrdina_Click);
            // 
            // btnCancOrd
            // 
            this.btnCancOrd.Location = new System.Drawing.Point(12, 158);
            this.btnCancOrd.Name = "btnCancOrd";
            this.btnCancOrd.Size = new System.Drawing.Size(289, 23);
            this.btnCancOrd.TabIndex = 2;
            this.btnCancOrd.Text = "Cancella ordinazioni";
            this.btnCancOrd.UseVisualStyleBackColor = true;
            this.btnCancOrd.Click += new System.EventHandler(this.btnCancOrd_Click);
            // 
            // btnCalcola
            // 
            this.btnCalcola.Location = new System.Drawing.Point(12, 187);
            this.btnCalcola.Name = "btnCalcola";
            this.btnCalcola.Size = new System.Drawing.Size(289, 23);
            this.btnCalcola.TabIndex = 3;
            this.btnCalcola.Text = "Calcola conto";
            this.btnCalcola.UseVisualStyleBackColor = true;
            this.btnCalcola.Click += new System.EventHandler(this.btnCalcola_Click);
            // 
            // grbScontrino
            // 
            this.grbScontrino.Controls.Add(this.tbx2);
            this.grbScontrino.Location = new System.Drawing.Point(14, 216);
            this.grbScontrino.Name = "grbScontrino";
            this.grbScontrino.Size = new System.Drawing.Size(287, 129);
            this.grbScontrino.TabIndex = 4;
            this.grbScontrino.TabStop = false;
            this.grbScontrino.Text = "Scontrino";
            // 
            // tbx2
            // 
            this.tbx2.Location = new System.Drawing.Point(8, 19);
            this.tbx2.Multiline = true;
            this.tbx2.Name = "tbx2";
            this.tbx2.ReadOnly = true;
            this.tbx2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbx2.Size = new System.Drawing.Size(273, 94);
            this.tbx2.TabIndex = 0;
            this.tbx2.TextChanged += new System.EventHandler(this.tbx2_TextChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 351);
            this.Controls.Add(this.grbScontrino);
            this.Controls.Add(this.btnCalcola);
            this.Controls.Add(this.btnCancOrd);
            this.Controls.Add(this.btnOrdina);
            this.Controls.Add(this.grbBanco);
            this.Name = "frmMain";
            this.Text = "Bar ISII V.1.0";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grbBanco.ResumeLayout(false);
            this.grbBanco.PerformLayout();
            this.grbScontrino.ResumeLayout(false);
            this.grbScontrino.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbBanco;
        private System.Windows.Forms.RadioButton rdbAranciata;
        private System.Windows.Forms.RadioButton rdbCappuccino;
        private System.Windows.Forms.RadioButton rdbCaffe;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox tbxnome;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnOrdina;
        private System.Windows.Forms.Button btnCancOrd;
        private System.Windows.Forms.Button btnCalcola;
        private System.Windows.Forms.GroupBox grbScontrino;
        private System.Windows.Forms.TextBox tbx2;
    }
}

