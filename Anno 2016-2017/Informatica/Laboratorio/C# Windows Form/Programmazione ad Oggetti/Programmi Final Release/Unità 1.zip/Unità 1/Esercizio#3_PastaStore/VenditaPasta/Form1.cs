﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VenditaPasta
{
    public partial class frmMain : Form
    {
        static int cont;
        static double totale;
        Utils carrello;
        public frmMain()
        {
            InitializeComponent();
            cont = 0;
            totale = 0.0;
            carrello = new Utils();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //ho convertito in kili per comodità (potevo convertire invece di costo al kilo in costo al grammo
            cmbxpesi.Items.Add(0.2);
            cmbxpesi.Items.Add(0.5);
            cmbxpesi.Items.Add(0.75);
            cmbxpesi.Items.Add(1);
        }

        private void btnacquista_Click(object sender, EventArgs e)
        {
          

            if (cont < 5)
            {
                if (rdbfusilli.Checked == true)
                {
                    int quantitativo = Int32.Parse(cmbxpesi.Text);
                    Globals.Carrellospesa[cont] = new Cliente("Fusilli",quantitativo, 0.7);
                }

                if (rdbpenne.Checked == true)
                {
                    int quantitativo = Int32.Parse(cmbxpesi.Text);
                    Globals.Carrellospesa[cont] = new Cliente("Penne", quantitativo, 1);
                }

                if (rdbspaghetti.Checked == true)
                {
                    int quantitativo = Int32.Parse(cmbxpesi.Text);
                    Globals.Carrellospesa[cont] = new Cliente("Spaghetti", quantitativo, 0.6);
                }
                cont++;
            }
            else
            {
                btnacquista.Enabled = false;
            }
        }

        private void cmbxpesi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbxpesi.Text != null)
            {
                btnacquista.Enabled = true;
            }
        }

        private void bttconto_Click(object sender, EventArgs e)
        {

            for(int i = 0;i < 5; i++)
            {
                txtdisplay.Text += "- Prodotto ";
                txtdisplay.Text += Globals.Carrellospesa[i].DENOMINAZIONE;
                txtdisplay.Text += ", Quantità: ";
                txtdisplay.Text += Globals.Carrellospesa[i].QUANTITA.ToString();
                txtdisplay.Text += ", Costo al kilo: ";
                txtdisplay.Text += Globals.Carrellospesa[i].COSTOKILO.ToString();

                totale += carrello.sommacosto(Globals.Carrellospesa[i].QUANTITA * Globals.Carrellospesa[i].COSTOKILO);
                
            }
            totale = totale / 2; //in quanto in cliente.cs viene già fatta la somma quindi qui viene ripetuta raddoppiando il prezzo
            txtdisplay.Text += "- Totale : " + totale;
           
          

        }
    }
}
