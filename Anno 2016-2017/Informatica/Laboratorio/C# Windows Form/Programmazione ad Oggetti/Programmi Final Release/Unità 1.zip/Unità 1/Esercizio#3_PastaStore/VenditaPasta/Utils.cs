﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VenditaPasta;

namespace VenditaPasta
{
    class Utils
    {
        private double tot;

        public Utils()
        {
            tot = 0.0;
        }

        public Utils(int somma)
        {
            tot = somma;
        }

        public double TOTALE
        {
            get { return tot; }
            set { tot = value;}
        }

        public double sommacosto(double i)
        {
            tot += i;
            return tot;
        }
    }
   
}
