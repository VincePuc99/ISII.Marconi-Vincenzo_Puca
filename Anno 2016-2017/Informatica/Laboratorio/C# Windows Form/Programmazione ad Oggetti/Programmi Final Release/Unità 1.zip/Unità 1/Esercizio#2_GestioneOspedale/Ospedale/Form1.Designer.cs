﻿namespace Ospedale
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnindietro = new System.Windows.Forms.Button();
            this.grpscheda = new System.Windows.Forms.GroupBox();
            this.bttregistra = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdimissioni = new System.Windows.Forms.TextBox();
            this.txtricovero = new System.Windows.Forms.TextBox();
            this.txtpatologia = new System.Windows.Forms.TextBox();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.btnavanti = new System.Windows.Forms.Button();
            this.grpelenco = new System.Windows.Forms.GroupBox();
            this.btn = new System.Windows.Forms.Button();
            this.tnelncocompleto = new System.Windows.Forms.Button();
            this.txtdesktop = new System.Windows.Forms.TextBox();
            this.btnrimuovi = new System.Windows.Forms.Button();
            this.bttmodifica = new System.Windows.Forms.Button();
            this.bttrestart = new System.Windows.Forms.Button();
            this.bttcarica = new System.Windows.Forms.Button();
            this.bttricerca = new System.Windows.Forms.Button();
            this.grpscheda.SuspendLayout();
            this.grpelenco.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnindietro
            // 
            this.btnindietro.Enabled = false;
            this.btnindietro.Location = new System.Drawing.Point(6, 19);
            this.btnindietro.Name = "btnindietro";
            this.btnindietro.Size = new System.Drawing.Size(25, 135);
            this.btnindietro.TabIndex = 0;
            this.btnindietro.Text = "<";
            this.btnindietro.UseVisualStyleBackColor = true;
            this.btnindietro.Click += new System.EventHandler(this.btnindietro_Click);
            // 
            // grpscheda
            // 
            this.grpscheda.Controls.Add(this.bttricerca);
            this.grpscheda.Controls.Add(this.bttmodifica);
            this.grpscheda.Controls.Add(this.btnrimuovi);
            this.grpscheda.Controls.Add(this.bttregistra);
            this.grpscheda.Controls.Add(this.label4);
            this.grpscheda.Controls.Add(this.label3);
            this.grpscheda.Controls.Add(this.label2);
            this.grpscheda.Controls.Add(this.label1);
            this.grpscheda.Controls.Add(this.txtdimissioni);
            this.grpscheda.Controls.Add(this.txtricovero);
            this.grpscheda.Controls.Add(this.txtpatologia);
            this.grpscheda.Controls.Add(this.txtcognome);
            this.grpscheda.Controls.Add(this.btnavanti);
            this.grpscheda.Controls.Add(this.btnindietro);
            this.grpscheda.Location = new System.Drawing.Point(12, 6);
            this.grpscheda.Name = "grpscheda";
            this.grpscheda.Size = new System.Drawing.Size(270, 169);
            this.grpscheda.TabIndex = 1;
            this.grpscheda.TabStop = false;
            this.grpscheda.Text = "Scheda Paziente";
            // 
            // bttregistra
            // 
            this.bttregistra.Location = new System.Drawing.Point(165, 123);
            this.bttregistra.Name = "bttregistra";
            this.bttregistra.Size = new System.Drawing.Size(58, 23);
            this.bttregistra.TabIndex = 10;
            this.bttregistra.Text = "Registra";
            this.bttregistra.UseVisualStyleBackColor = true;
            this.bttregistra.Click += new System.EventHandler(this.bttregistra_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Data dimissioni";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Data di ricovero";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Patologia";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cognome";
            // 
            // txtdimissioni
            // 
            this.txtdimissioni.Location = new System.Drawing.Point(131, 94);
            this.txtdimissioni.Name = "txtdimissioni";
            this.txtdimissioni.Size = new System.Drawing.Size(100, 20);
            this.txtdimissioni.TabIndex = 5;
            // 
            // txtricovero
            // 
            this.txtricovero.Location = new System.Drawing.Point(131, 71);
            this.txtricovero.Name = "txtricovero";
            this.txtricovero.Size = new System.Drawing.Size(100, 20);
            this.txtricovero.TabIndex = 4;
            // 
            // txtpatologia
            // 
            this.txtpatologia.Location = new System.Drawing.Point(131, 45);
            this.txtpatologia.Name = "txtpatologia";
            this.txtpatologia.Size = new System.Drawing.Size(100, 20);
            this.txtpatologia.TabIndex = 3;
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(131, 19);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(100, 20);
            this.txtcognome.TabIndex = 2;
            // 
            // btnavanti
            // 
            this.btnavanti.Enabled = false;
            this.btnavanti.Location = new System.Drawing.Point(237, 19);
            this.btnavanti.Name = "btnavanti";
            this.btnavanti.Size = new System.Drawing.Size(25, 135);
            this.btnavanti.TabIndex = 1;
            this.btnavanti.Text = ">";
            this.btnavanti.UseVisualStyleBackColor = true;
            this.btnavanti.Click += new System.EventHandler(this.btnavanti_Click);
            // 
            // grpelenco
            // 
            this.grpelenco.Controls.Add(this.bttcarica);
            this.grpelenco.Controls.Add(this.bttrestart);
            this.grpelenco.Controls.Add(this.btn);
            this.grpelenco.Controls.Add(this.tnelncocompleto);
            this.grpelenco.Controls.Add(this.txtdesktop);
            this.grpelenco.Location = new System.Drawing.Point(12, 181);
            this.grpelenco.Name = "grpelenco";
            this.grpelenco.Size = new System.Drawing.Size(270, 153);
            this.grpelenco.TabIndex = 2;
            this.grpelenco.TabStop = false;
            this.grpelenco.Text = "Elenco Pazienti";
            // 
            // btn
            // 
            this.btn.Enabled = false;
            this.btn.Location = new System.Drawing.Point(6, 124);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(161, 23);
            this.btn.TabIndex = 2;
            this.btn.Text = "Elenco pazienti ricoverati";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // tnelncocompleto
            // 
            this.tnelncocompleto.Enabled = false;
            this.tnelncocompleto.Location = new System.Drawing.Point(6, 100);
            this.tnelncocompleto.Name = "tnelncocompleto";
            this.tnelncocompleto.Size = new System.Drawing.Size(161, 23);
            this.tnelncocompleto.TabIndex = 1;
            this.tnelncocompleto.Text = "Elenco completo pazienti";
            this.tnelncocompleto.UseVisualStyleBackColor = true;
            this.tnelncocompleto.Click += new System.EventHandler(this.tnelncocompleto_Click);
            // 
            // txtdesktop
            // 
            this.txtdesktop.Location = new System.Drawing.Point(6, 19);
            this.txtdesktop.Multiline = true;
            this.txtdesktop.Name = "txtdesktop";
            this.txtdesktop.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtdesktop.Size = new System.Drawing.Size(256, 74);
            this.txtdesktop.TabIndex = 0;
            // 
            // btnrimuovi
            // 
            this.btnrimuovi.Enabled = false;
            this.btnrimuovi.Location = new System.Drawing.Point(37, 113);
            this.btnrimuovi.Name = "btnrimuovi";
            this.btnrimuovi.Size = new System.Drawing.Size(58, 23);
            this.btnrimuovi.TabIndex = 11;
            this.btnrimuovi.Text = "Rimuovi ";
            this.btnrimuovi.UseVisualStyleBackColor = true;
            this.btnrimuovi.Click += new System.EventHandler(this.btnrimuovi_Click);
            // 
            // bttmodifica
            // 
            this.bttmodifica.Enabled = false;
            this.bttmodifica.Location = new System.Drawing.Point(37, 140);
            this.bttmodifica.Name = "bttmodifica";
            this.bttmodifica.Size = new System.Drawing.Size(58, 23);
            this.bttmodifica.TabIndex = 12;
            this.bttmodifica.Text = "Modifica";
            this.bttmodifica.UseVisualStyleBackColor = true;
            this.bttmodifica.Click += new System.EventHandler(this.bttmodifica_Click);
            // 
            // bttrestart
            // 
            this.bttrestart.Location = new System.Drawing.Point(173, 100);
            this.bttrestart.Name = "bttrestart";
            this.bttrestart.Size = new System.Drawing.Size(89, 23);
            this.bttrestart.TabIndex = 3;
            this.bttrestart.Text = "Canc. Archivio";
            this.bttrestart.UseVisualStyleBackColor = true;
            this.bttrestart.Click += new System.EventHandler(this.bttrestart_Click);
            // 
            // bttcarica
            // 
            this.bttcarica.Enabled = false;
            this.bttcarica.Location = new System.Drawing.Point(173, 124);
            this.bttcarica.Name = "bttcarica";
            this.bttcarica.Size = new System.Drawing.Size(89, 23);
            this.bttcarica.TabIndex = 4;
            this.bttcarica.Text = "Carica su .txt";
            this.bttcarica.UseVisualStyleBackColor = true;
            this.bttcarica.Click += new System.EventHandler(this.bttcarica_Click);
            // 
            // bttricerca
            // 
            this.bttricerca.Enabled = false;
            this.bttricerca.Location = new System.Drawing.Point(101, 123);
            this.bttricerca.Name = "bttricerca";
            this.bttricerca.Size = new System.Drawing.Size(58, 23);
            this.bttricerca.TabIndex = 3;
            this.bttricerca.Text = "Ricerca";
            this.bttricerca.UseVisualStyleBackColor = true;
            this.bttricerca.Click += new System.EventHandler(this.bttricerca_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 340);
            this.Controls.Add(this.grpelenco);
            this.Controls.Add(this.grpscheda);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Gestione Ospedaliera";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpscheda.ResumeLayout(false);
            this.grpscheda.PerformLayout();
            this.grpelenco.ResumeLayout(false);
            this.grpelenco.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnindietro;
        private System.Windows.Forms.GroupBox grpscheda;
        private System.Windows.Forms.Button bttregistra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdimissioni;
        private System.Windows.Forms.TextBox txtricovero;
        private System.Windows.Forms.TextBox txtpatologia;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.Button btnavanti;
        private System.Windows.Forms.GroupBox grpelenco;
        private System.Windows.Forms.TextBox txtdesktop;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button tnelncocompleto;
        private System.Windows.Forms.Button btnrimuovi;
        private System.Windows.Forms.Button bttmodifica;
        private System.Windows.Forms.Button bttrestart;
        private System.Windows.Forms.Button bttcarica;
        private System.Windows.Forms.Button bttricerca;
    }
}

