﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace Ospedale
{
    public partial class frmMain : Form
    {
        static int i;
        static int x;
        public frmMain()
        {
            InitializeComponent();
            i = 0;
            x = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void bttregistra_Click(object sender, EventArgs e)
        {
            if (i < 5)
            {
                Globals.Reparto[i] = new Paziente(txtcognome.Text, txtpatologia.Text, txtricovero.Text, txtdimissioni.Text);
                i++;
            }
            else
            {
                bttregistra.Enabled = false;
                tnelncocompleto.Enabled = true;
                btn.Enabled = true;
                btnavanti.Enabled = true;
                btnindietro.Enabled = true;
                btnrimuovi.Enabled = true;
                bttmodifica.Enabled = true;
                bttcarica.Enabled = true;
                bttricerca.Enabled = true;
            }

            txtcognome.Text = "";
            txtpatologia.Text = "";
            txtricovero.Text = "";
            txtdimissioni.Text = "";

        }

        private void tnelncocompleto_Click(object sender, EventArgs e)
        {
            txtdesktop.Text = "";
            for (int i = 0; i < 5; i++)
            {                
                txtdesktop.Text += "Cognome: ";
                txtdesktop.Text += Globals.Reparto[i].COGNOME;
                txtdesktop.Text += " Patologia: ";
                txtdesktop.Text += Globals.Reparto[i].PATOLOGIA;
                txtdesktop.Text += " Ricovero: ";
                txtdesktop.Text += Globals.Reparto[i].RICOVERO;
                txtdesktop.Text += " Dimissioni: ";
                txtdesktop.Text += Globals.Reparto[i].DIMISSIONI;
                txtdesktop.Text += "\r\n";
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            txtdesktop.Text = "";
            for (int i = 0; i < 5; i++)
            {
                if (Globals.Reparto[i].DIMISSIONI == "")
                {
                    txtdesktop.Text += " ";
                    txtdesktop.Text += "Cognome:";                   
                    txtdesktop.Text += Globals.Reparto[i].COGNOME;
                    txtdesktop.Text += "\r\n";
                }
            }
        }

        private void btnavanti_Click(object sender, EventArgs e)
        {
       
            if (x == 4)
            {               
                txtcognome.Text = Globals.Reparto[x].COGNOME;
                txtpatologia.Text = Globals.Reparto[x].PATOLOGIA;
                txtricovero.Text = Globals.Reparto[x].RICOVERO;
                txtdimissioni.Text = Globals.Reparto[x].DIMISSIONI;
                x++;
                btnavanti.Enabled = false;
            }
            else
            {
                txtcognome.Text = Globals.Reparto[x].COGNOME;
                txtpatologia.Text = Globals.Reparto[x].PATOLOGIA;
                txtricovero.Text = Globals.Reparto[x].RICOVERO;
                txtdimissioni.Text = Globals.Reparto[x].DIMISSIONI;
                x++;
            }

            
        }

        private void btnindietro_Click(object sender, EventArgs e)
        {

            x--;
            if (x != 4)
            {
                btnavanti.Enabled = true;
            }
            if (x < 0)
            {
                x++;
                txtcognome.Text = Globals.Reparto[x].COGNOME;
                txtpatologia.Text = Globals.Reparto[x].PATOLOGIA;
                txtricovero.Text = Globals.Reparto[x].RICOVERO;
                txtdimissioni.Text = Globals.Reparto[x].DIMISSIONI;
            }
            else
            {
                txtcognome.Text = Globals.Reparto[x].COGNOME;
                txtpatologia.Text = Globals.Reparto[x].PATOLOGIA;
                txtricovero.Text = Globals.Reparto[x].RICOVERO;
                txtdimissioni.Text = Globals.Reparto[x].DIMISSIONI;
            
            }
           
        }

        private void btnrimuovi_Click(object sender, EventArgs e)
        {
            x--;
                Globals.Reparto[x].COGNOME = "";
                Globals.Reparto[x].PATOLOGIA = "";
                Globals.Reparto[x].DIMISSIONI = "";
                Globals.Reparto[x].RICOVERO = "";
                x++;
                
            
        }

        private void bttmodifica_Click(object sender, EventArgs e)
        {

            x--;
                Globals.Reparto[x].COGNOME = txtcognome.Text.ToString();
                Globals.Reparto[x].PATOLOGIA = txtpatologia.Text.ToString();
                Globals.Reparto[x].DIMISSIONI = txtdimissioni.Text.ToString();
                Globals.Reparto[x].RICOVERO = txtricovero.Text.ToString();
                x++;
               
                
        }

        private void bttrestart_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void bttcarica_Click(object sender, EventArgs e)
        {
            string coll = @"C:\";
            StreamWriter scrivi = new StreamWriter(coll,true);
            for (int z = 0; z < 5; z++)
            {
                scrivi.WriteLine(Globals.Reparto[z].COGNOME);
                scrivi.WriteLine(Globals.Reparto[z].PATOLOGIA);
                scrivi.WriteLine(Globals.Reparto[z].RICOVERO);
                scrivi.WriteLine(Globals.Reparto[z].DIMISSIONI);
            }
            scrivi.Close();
        }

        private void bttricerca_Click(object sender, EventArgs e)
        {
            Form frm = new Ricerca();
            this.Hide();
            frm.ShowDialog();
            
        }//fine void
    }
}
