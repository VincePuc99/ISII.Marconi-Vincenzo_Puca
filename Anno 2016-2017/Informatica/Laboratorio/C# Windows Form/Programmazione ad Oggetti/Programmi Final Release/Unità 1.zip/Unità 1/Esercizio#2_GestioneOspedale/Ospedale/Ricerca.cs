﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ospedale
{
    public partial class Ricerca : Form
    {
        public Ricerca()
        {
            InitializeComponent();
        }

        private void Ricerca_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int k = 0; k < 5; k++)
            {
                if (txtcognome.Text == Globals.Reparto[k].COGNOME)
                {
                    txtdisplay.Text += "Primo trovato per cognome ";
                    txtdisplay.Text = Globals.Reparto[k].COGNOME;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].PATOLOGIA;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].RICOVERO;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].DIMISSIONI;
                    goto jump;
                }

                if (txtpatologia.Text == Globals.Reparto[k].PATOLOGIA)
                {
                    txtdisplay.Text += "Primo trovato per patologia ";
                    txtdisplay.Text = Globals.Reparto[k].COGNOME;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].PATOLOGIA;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].RICOVERO;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].DIMISSIONI;
                    goto jump;
                }

                if (txtric.Text == Globals.Reparto[k].RICOVERO)
                {
                    txtdisplay.Text += "Primo trovato per ricovero ";
                    txtdisplay.Text = Globals.Reparto[k].COGNOME;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].PATOLOGIA;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].RICOVERO;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].DIMISSIONI;
                    goto jump;
                }

                if (txtdim.Text == Globals.Reparto[k].DIMISSIONI)
                {
                    txtdisplay.Text += "Primo trovato per dimissioni ";
                    txtdisplay.Text = Globals.Reparto[k].COGNOME;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].PATOLOGIA;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].RICOVERO;
                    txtdisplay.Text += " ";
                    txtdisplay.Text += Globals.Reparto[k].DIMISSIONI;
                    goto jump;
                }
    
            }
            jump:
            if (txtdisplay.Text == "")
            {
                txtdisplay.Text = "Nessun paziente trovato";
            }
        }
    }
}
