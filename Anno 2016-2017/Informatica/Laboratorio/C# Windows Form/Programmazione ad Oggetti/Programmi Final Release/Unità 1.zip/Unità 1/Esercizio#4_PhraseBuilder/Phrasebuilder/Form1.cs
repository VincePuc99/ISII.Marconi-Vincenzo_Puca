﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phrasebuilder
{
    public partial class frmain : Form
    {
        static string inizio, fine;
        public frmain()
        {
            InitializeComponent();
            txtdisplay.Text = "";
            cmbscelta.Items.Clear();
        }

        private void bttdecomponi_Click(object sender, EventArgs e)
        {
            if (txtdisplay.Text != "")
            {
                inizio = txtdisplay.Text;
                string frase = "";
                txtdisplay.Text += " ";
                for (int i = 0; i < txtdisplay.Text.Length; i++)
                {
                    if (txtdisplay.Text[i] == ' ')
                    {
                        cmbscelta.Items.Add(frase);
                        frase = "";
                    }
                    else
                    {
                        frase += "" + txtdisplay.Text[i];
                    }

                }
                txtdisplay.Text = "";
            }
            else
            {
                txtdisplay.Text = "Nessuna frase da scomporre";
            }
        }

        private void cmbscelta_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtdisplay.Text += " " + cmbscelta.Text;
        }

        private void cmbscelta_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
        }

        private void bttvedirusltato_Click(object sender, EventArgs e)
        {
            fine = txtdisplay.Text;

            if (inizio == fine)
            {
                txtdisplay.Text = "Vittoria!!!";              
            }
            else
            {
                txtdisplay.Text = "Corrispondenza inesatta hai perso!!!";
            }
            cmbscelta.Items.Clear();
        }
    }
}
