﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ospedale
{
    class Paziente
    {
        //attributi
        private string cognome;
        private string patologia;
        private string dataricov;
        private string datadimissioni;

        public Paziente() //costruttore di default
        {
            cognome = "";
            patologia = "";
            dataricov = "";
            datadimissioni = "";
        }

        //costruttore di overloaded
        public Paziente(string cogn,string patol,string datrico,string datdimi)
        {
            cognome = cogn;
            patologia = patol;
            dataricov = datrico;
            datadimissioni = datdimi;
        }
        //proprietà
        public string COGNOME
        {
            get { return cognome; }
            set { cognome = value; }
        }

        public string PATOLOGIA
        {
            get { return patologia; }
            set { patologia = value; }
        }

        public string RICOVERO
        {
            get { return dataricov; }
            set { dataricov = value; }
        }

        public string DIMISSIONI
        {
            get { return datadimissioni; }
            set { datadimissioni = value; }
        }

    }
}
