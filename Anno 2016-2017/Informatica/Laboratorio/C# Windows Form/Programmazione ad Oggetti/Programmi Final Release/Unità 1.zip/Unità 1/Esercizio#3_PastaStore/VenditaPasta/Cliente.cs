﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VenditaPasta
{
    class Cliente
    {
        private string nome;
        private int quantita;
        private double costoalkilo;

        //classico
        public Cliente()
        {
            nome = "";
            quantita = 0;
            costoalkilo = 0;
        }
        //overloaded
        public Cliente(string nom, int quant, double costkil)
        {
            nome = nom;
            quantita = quant;
            costoalkilo = costkil;
        }

        //proprietà
        public string DENOMINAZIONE
        {
            get { return nome; }
            set { nome = value; }
        }

        public int QUANTITA
        {
            get { return quantita; }
            set { quantita = value; }
        }

        public double COSTOKILO
        {
            get { return costoalkilo; }
            set { costoalkilo = value; }
        }
    }
}
