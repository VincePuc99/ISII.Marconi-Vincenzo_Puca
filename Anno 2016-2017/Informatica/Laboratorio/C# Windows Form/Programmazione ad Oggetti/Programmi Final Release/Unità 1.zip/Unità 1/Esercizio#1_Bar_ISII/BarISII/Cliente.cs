﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarISII
{
    class Cliente
    {
        //attributi
        static string Nome;
        static int[] Ordinazioni = new int[5];
        static int conteggio = 0;

        //costruttori
        public Cliente()
        {   
        }

        public void Inizianome(string n)
        {
            Nome = n;
        }

        public bool ordine(int scelta)
        {
            if (conteggio < 5)
            {
                if (Ordinazioni[conteggio] == 0)
                {
                    Ordinazioni[conteggio] = scelta;
                    conteggio++;
                    return true;
                }
                else
                    return false; //false se nella posizione ce già un altro numero
            }
            else
                return false; ///restituisce false se l array è full
            
        }

        public void cancellaordinativi()
        {
            for (int i = 0; i < Ordinazioni.Length; i++)
            {
                Ordinazioni[i] = 0;
            }
            conteggio = 0;

        }

       
    }
}
