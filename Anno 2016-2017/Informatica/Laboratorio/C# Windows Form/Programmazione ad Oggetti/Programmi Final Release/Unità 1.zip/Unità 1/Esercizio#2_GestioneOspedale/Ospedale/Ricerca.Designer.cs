﻿namespace Ospedale
{
    partial class Ricerca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtdim = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpatologia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtric = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnindietro = new System.Windows.Forms.Button();
            this.btntrova = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtdim);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtcognome);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtpatologia);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtric);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(207, 131);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Campi di ricerca";
            // 
            // txtdim
            // 
            this.txtdim.Location = new System.Drawing.Point(97, 105);
            this.txtdim.Name = "txtdim";
            this.txtdim.Size = new System.Drawing.Size(100, 20);
            this.txtdim.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Data dimissioni";
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(97, 27);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(100, 20);
            this.txtcognome.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Data di ricovero";
            // 
            // txtpatologia
            // 
            this.txtpatologia.Location = new System.Drawing.Point(97, 53);
            this.txtpatologia.Name = "txtpatologia";
            this.txtpatologia.Size = new System.Drawing.Size(100, 20);
            this.txtpatologia.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Patologia";
            // 
            // txtric
            // 
            this.txtric.Location = new System.Drawing.Point(97, 79);
            this.txtric.Name = "txtric";
            this.txtric.Size = new System.Drawing.Size(100, 20);
            this.txtric.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Cognome";
            // 
            // btnindietro
            // 
            this.btnindietro.Location = new System.Drawing.Point(12, 149);
            this.btnindietro.Name = "btnindietro";
            this.btnindietro.Size = new System.Drawing.Size(75, 23);
            this.btnindietro.TabIndex = 20;
            this.btnindietro.Text = "Indietro";
            this.btnindietro.UseVisualStyleBackColor = true;
            // 
            // btntrova
            // 
            this.btntrova.Location = new System.Drawing.Point(268, 149);
            this.btntrova.Name = "btntrova";
            this.btntrova.Size = new System.Drawing.Size(75, 23);
            this.btntrova.TabIndex = 21;
            this.btntrova.Text = "Trova";
            this.btntrova.UseVisualStyleBackColor = true;
            this.btntrova.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtdisplay);
            this.groupBox2.Location = new System.Drawing.Point(226, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(117, 130);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Paziente";
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(7, 20);
            this.txtdisplay.Multiline = true;
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.ReadOnly = true;
            this.txtdisplay.Size = new System.Drawing.Size(104, 104);
            this.txtdisplay.TabIndex = 0;
            // 
            // Ricerca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 177);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btntrova);
            this.Controls.Add(this.btnindietro);
            this.Controls.Add(this.groupBox1);
            this.Name = "Ricerca";
            this.Text = "Ricerca";
            this.Load += new System.EventHandler(this.Ricerca_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtdim;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtpatologia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtric;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnindietro;
        private System.Windows.Forms.Button btntrova;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtdisplay;
    }
}