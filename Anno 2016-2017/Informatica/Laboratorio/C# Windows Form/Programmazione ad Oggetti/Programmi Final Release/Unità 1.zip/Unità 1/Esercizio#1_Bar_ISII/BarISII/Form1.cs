﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BarISII
{
    public partial class frmMain : Form
    {
        static TipoOrdinazione Uno = TipoOrdinazione.Aranciata;
        static TipoOrdinazione Due = TipoOrdinazione.Caffè;
        static TipoOrdinazione Tre = TipoOrdinazione.Cappuccino;
        static int conto = 0;
        static int i = 0;

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnOrdina_Click(object sender, EventArgs e)
        {
            if (tbxnome.Text == "" || rdbAranciata.Checked == false && rdbCaffe.Checked == false && rdbCappuccino.Checked == false)
            {
                DialogResult messaggio;
                messaggio = MessageBox.Show("Campo nome vuoto o nessuna ordinazione fatta", "Errore", MessageBoxButtons.OK);
                return;
            }

            i++;

            if (i == 6)
            {
                btnOrdina.Enabled = false;
                tbx2.Text += "-----------------------";
                return;
            }
            
            bool risultato = false;
            Cliente C = new Cliente();          
            C.Inizianome(tbxnome.Text);

            if(rdbAranciata.Checked == true)
            {
               risultato = C.ordine(1);
               if (risultato == true)
               {
                   tbx2.Text += "" + Uno;
                   tbx2.Text += " 1$\r\n";
                   conto += 1;
               }
            }

            if (rdbCaffe.Checked == true)
            {
               risultato = C.ordine(2);
               if (risultato == true)
               {
                   tbx2.Text += "" + Due;
                   tbx2.Text += " 2$\r\n";
                   conto += 2;
               }
            }

            if (rdbCappuccino.Checked == true)
            {
               risultato = C.ordine(3);
               if (risultato == true)
               {
                   tbx2.Text += "" + Tre;
                   tbx2.Text += " 3$\r\n";
                   conto += 3;
               }           
            }            

        }

        private void btnCancOrd_Click(object sender, EventArgs e)
        {
            Cliente C = new Cliente();
            C.cancellaordinativi();
            i = 0;
            btnOrdina.Enabled = true;
            tbx2.Text = "";
            btnCalcola.Enabled = true;
        }

        private void btnCalcola_Click(object sender, EventArgs e)
        {
            btnCalcola.Enabled = false;
          
            string nome = tbxnome.Text;
            tbx2.Text = "----- Scontrino fiscale di " + nome;
            tbx2.Text += " -----";
            tbx2.Text += "\r\n";

            tbx2.Text += "Totale: $ "+ conto;
            conto = 0;
        }

        private void tbx2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
