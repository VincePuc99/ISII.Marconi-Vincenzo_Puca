﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Mezziditrasporto;
using Farmacia;

namespace Logistica_ecologica
{
    public partial class frmmain : Form
    {
        //static string[][] magazzino;
        static int i;
        static int contatore;
        static int a;

        public frmmain()
        {
            InitializeComponent();          
            //magazzino = new string[5][];
            i = 0;
            a = 0;
            contatore = 1;
           
            for (int h = 0; h < 5; h++)
            {
                Globals.ParcoMoto[h] = new Ciclomotore(contatore, contatore, true);
                Globals.Magazzino[h] = new Prodotto();
                contatore++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbdenominaz.Items.Add("Insulina");
            cmbdenominaz.Items.Add("Eparina");
            cmbdenominaz.Items.Add("Urbason");
            txtpeso.Text = "";
            pgboccupaz.Value = 0;
            bttassocia.Enabled = false;
            btt1ciclomotor.BackColor = Color.White;
            btt2ciclomotor.BackColor = Color.White;
            btt3ciclomotor.BackColor = Color.White;
            btt4ciclomotor.BackColor = Color.White;
            btt5ciclomotor.BackColor = Color.White;
            error.BackColor = Color.White;
            
        }//fine load

        private void bttadd_Click(object sender, EventArgs e)
        {
            if (cmbdenominaz.Text == "" || txtpeso.Text == "")
            {
                error.BackColor = Color.Red;
            }
            else
            {
                if (i < 5)
                {
                    Globals.Magazzino[i].DESCRIZIONE = cmbdenominaz.Text;

                    int p = Int32.Parse(txtpeso.Text);
                    Globals.Magazzino[i].PESO = p;
                    
                    //magazzino[i] = new string[2];
                    //magazzino[i][0] = cmbdenominaz.Text;
                    //magazzino[i][1] = txtpeso.Text; 

                    i++;
                    error.BackColor = Color.Green;
                    pgboccupaz.Value += 20;                 
                }
                else
                {
                    bttadd.Enabled = false;
                    error.BackColor = Color.Yellow;
                    grpdati.Enabled = false;
                    bttassocia.Enabled = true;
                }
            }
          
        }

        private void error_Click(object sender, EventArgs e)
        {
            this.BackColor = error.BackColor;
        }

        private void bttassocia_Click(object sender, EventArgs e)
        {
            for (int g = 0; g < 5; g++)
            {              
               if (Globals.ParcoMoto[g].STATO == true)
               {
                   a = 0;
                    do
                    {
                        if (a < 5)
                        {
                            //int f = Int32.Parse(magazzino[a][1]);
                            if (Globals.ParcoMoto[g].CARICOMAX >= Globals.Magazzino[a].PESO)
                            {
                                Globals.ParcoMoto[g].STATO = false; //eliminazione ciclomotore dal parcomoto
                                //magazzino[g][0] = "";
                                //magazzino[g][1] = "10";
                                Globals.Magazzino[g].DESCRIZIONE = "";
                                Globals.Magazzino[g].PESO = 10;
                                pgboccupaz.Value -= 20;
                                if (g == 0)
                                {
                                    btt1ciclomotor.BackColor = Color.Yellow;
                                }
                                if (g == 1)
                                {
                                    btt2ciclomotor.BackColor = Color.Yellow;
                                }

                                if (g == 2)
                                {
                                    btt3ciclomotor.BackColor = Color.Yellow;
                                }

                                if (g == 3)
                                {
                                    btt4ciclomotor.BackColor = Color.Yellow;
                                }

                                if (g == 4)
                                {
                                    btt5ciclomotor.BackColor = Color.Yellow;
                                }
                                break;
                            }
                            else
                            {
                                a++;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }while(true);
                }           
            }//fine for 
            bttassocia.Enabled = false;
        }

        private void bttcanc_Click(object sender, EventArgs e)
        {
            Thread.Sleep(2000);
            for (int q = 0; q < 5; q++)
            {
                Globals.ParcoMoto[q].STATO = true;
            }

            btt1ciclomotor.BackColor = Color.White;
            btt2ciclomotor.BackColor = Color.White;
            btt3ciclomotor.BackColor = Color.White;
            btt4ciclomotor.BackColor = Color.White;
            btt5ciclomotor.BackColor = Color.White;

            pgboccupaz.Value = 0;

            //magazzino = new string[5][];
            grpdati.Enabled = true;
            bttadd.Enabled = true;

            error.BackColor = Color.White;
            cmbdenominaz.Text = "";
            txtpeso.Text = "";
            i = 0;

            this.BackColor = DefaultBackColor;
        
            //Application.Restart();
        }//fine button
    }
}
