﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ufficioamministrativo
{
    class Mylibary
    {
        static decimal tasse;
        static decimal nuovotot;
        public decimal calcolatasse(decimal tot)
         {
            if (tot < 3000)
            {
                tasse = (tot * 10) / 100;
                nuovotot = tot - tasse;
            }
            if (tot > 3000 && tot < 6000)
            {
                tasse = (tot * 20) / 100;
                nuovotot = tot - tasse;
            }
            else
            {
                tasse = (tot * 30) / 100;
                nuovotot = tot - tasse;
            }
            return tasse;

         }
    }
}
