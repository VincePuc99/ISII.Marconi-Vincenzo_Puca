﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personale
{
    class Operaio : Dipendente
    {
        private decimal pagaoraria;
        private decimal tot;

        public Operaio() : base()
        {
            pagaoraria = 0;
        }

        public Operaio(string nom,string cogn,decimal ore) : base(nom, cogn, ore)
        {
            pagaoraria = 20;
            tot = 0;                 
        }
        
        public decimal Calcola()
        {
            decimal totale;
            tot = oredilav * pagaoraria;
            Ufficioamministrativo.Mylibary c = new Ufficioamministrativo.Mylibary();
            totale = c.calcolatasse(tot);
            return totale;
        }

    }
}
