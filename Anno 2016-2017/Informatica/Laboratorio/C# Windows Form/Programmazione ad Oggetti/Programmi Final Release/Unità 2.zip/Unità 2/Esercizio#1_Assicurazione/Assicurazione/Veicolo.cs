﻿
namespace Mezzi
{
    class Veicolo
    {
        protected string tipo;
        protected string targa;
        protected int anno;
        protected int cavalli;

        public Veicolo()
        {
            tipo = "";
            targa = "";
            anno = 0;
            cavalli = 0;
        }

        public Veicolo(string tip,string targ,int ann,int caval)
        {
            tipo = tip;
            targa = targ;
            anno = ann;
            cavalli = caval; 
        }

        public string TIPO
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public string TARGA
        {
            get { return targa; }
            set { targa = value; }        
        }

        public int ANNO
        {
            get { return anno; }
            set { anno = value; }
        }

        public int CAVALLI
        {
            get { return cavalli; }
            set { cavalli = value; }
        }

    }//fine class
}
