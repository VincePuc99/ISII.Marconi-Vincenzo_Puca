﻿namespace Supermercato
{
    partial class Frmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmain));
            this.grpcarrello = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbuova = new System.Windows.Forms.ComboBox();
            this.cmblatte = new System.Windows.Forms.ComboBox();
            this.cmbpane = new System.Windows.Forms.ComboBox();
            this.chkuova = new System.Windows.Forms.CheckBox();
            this.chklatte = new System.Windows.Forms.CheckBox();
            this.chkpane = new System.Windows.Forms.CheckBox();
            this.bttacquista = new System.Windows.Forms.Button();
            this.grptotale = new System.Windows.Forms.GroupBox();
            this.txttot = new System.Windows.Forms.TextBox();
            this.grpcarrello.SuspendLayout();
            this.grptotale.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpcarrello
            // 
            this.grpcarrello.Controls.Add(this.label3);
            this.grpcarrello.Controls.Add(this.label2);
            this.grpcarrello.Controls.Add(this.label1);
            this.grpcarrello.Controls.Add(this.cmbuova);
            this.grpcarrello.Controls.Add(this.cmblatte);
            this.grpcarrello.Controls.Add(this.cmbpane);
            this.grpcarrello.Controls.Add(this.chkuova);
            this.grpcarrello.Controls.Add(this.chklatte);
            this.grpcarrello.Controls.Add(this.chkpane);
            this.grpcarrello.Location = new System.Drawing.Point(12, 12);
            this.grpcarrello.Name = "grpcarrello";
            this.grpcarrello.Size = new System.Drawing.Size(221, 91);
            this.grpcarrello.TabIndex = 0;
            this.grpcarrello.TabStop = false;
            this.grpcarrello.Text = "Carrello della spesa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "N.RO";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "LT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "KG";
            // 
            // cmbuova
            // 
            this.cmbuova.FormattingEnabled = true;
            this.cmbuova.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbuova.Location = new System.Drawing.Point(91, 63);
            this.cmbuova.Name = "cmbuova";
            this.cmbuova.Size = new System.Drawing.Size(121, 21);
            this.cmbuova.TabIndex = 5;
            // 
            // cmblatte
            // 
            this.cmblatte.FormattingEnabled = true;
            this.cmblatte.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmblatte.Location = new System.Drawing.Point(91, 40);
            this.cmblatte.Name = "cmblatte";
            this.cmblatte.Size = new System.Drawing.Size(121, 21);
            this.cmblatte.TabIndex = 4;
            // 
            // cmbpane
            // 
            this.cmbpane.FormattingEnabled = true;
            this.cmbpane.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbpane.Location = new System.Drawing.Point(91, 17);
            this.cmbpane.Name = "cmbpane";
            this.cmbpane.Size = new System.Drawing.Size(121, 21);
            this.cmbpane.TabIndex = 3;
            // 
            // chkuova
            // 
            this.chkuova.AutoSize = true;
            this.chkuova.Location = new System.Drawing.Point(6, 65);
            this.chkuova.Name = "chkuova";
            this.chkuova.Size = new System.Drawing.Size(52, 17);
            this.chkuova.TabIndex = 2;
            this.chkuova.Text = "Uova";
            this.chkuova.UseVisualStyleBackColor = true;
            this.chkuova.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // chklatte
            // 
            this.chklatte.AutoSize = true;
            this.chklatte.Location = new System.Drawing.Point(6, 42);
            this.chklatte.Name = "chklatte";
            this.chklatte.Size = new System.Drawing.Size(50, 17);
            this.chklatte.TabIndex = 1;
            this.chklatte.Text = "Latte";
            this.chklatte.UseVisualStyleBackColor = true;
            // 
            // chkpane
            // 
            this.chkpane.AutoSize = true;
            this.chkpane.Location = new System.Drawing.Point(6, 19);
            this.chkpane.Name = "chkpane";
            this.chkpane.Size = new System.Drawing.Size(51, 17);
            this.chkpane.TabIndex = 0;
            this.chkpane.Text = "Pane";
            this.chkpane.UseVisualStyleBackColor = true;
            // 
            // bttacquista
            // 
            this.bttacquista.Location = new System.Drawing.Point(12, 109);
            this.bttacquista.Name = "bttacquista";
            this.bttacquista.Size = new System.Drawing.Size(221, 23);
            this.bttacquista.TabIndex = 1;
            this.bttacquista.Text = "Acquista";
            this.bttacquista.UseVisualStyleBackColor = true;
            this.bttacquista.Click += new System.EventHandler(this.bttacquista_Click);
            // 
            // grptotale
            // 
            this.grptotale.Controls.Add(this.txttot);
            this.grptotale.Location = new System.Drawing.Point(12, 138);
            this.grptotale.Name = "grptotale";
            this.grptotale.Size = new System.Drawing.Size(221, 46);
            this.grptotale.TabIndex = 2;
            this.grptotale.TabStop = false;
            this.grptotale.Text = "Totale $";
            // 
            // txttot
            // 
            this.txttot.Location = new System.Drawing.Point(6, 19);
            this.txttot.Name = "txttot";
            this.txttot.ReadOnly = true;
            this.txttot.Size = new System.Drawing.Size(209, 20);
            this.txttot.TabIndex = 0;
            // 
            // Frmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 190);
            this.Controls.Add(this.grptotale);
            this.Controls.Add(this.bttacquista);
            this.Controls.Add(this.grpcarrello);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frmain";
            this.Text = "Supermercato";
            this.Load += new System.EventHandler(this.Frmain_Load);
            this.grpcarrello.ResumeLayout(false);
            this.grpcarrello.PerformLayout();
            this.grptotale.ResumeLayout(false);
            this.grptotale.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpcarrello;
        private System.Windows.Forms.ComboBox cmbuova;
        private System.Windows.Forms.ComboBox cmblatte;
        private System.Windows.Forms.ComboBox cmbpane;
        private System.Windows.Forms.CheckBox chkuova;
        private System.Windows.Forms.CheckBox chklatte;
        private System.Windows.Forms.CheckBox chkpane;
        private System.Windows.Forms.Button bttacquista;
        private System.Windows.Forms.GroupBox grptotale;
        private System.Windows.Forms.TextBox txttot;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

