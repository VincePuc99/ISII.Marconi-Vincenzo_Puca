﻿namespace Farmacia
{
    class Prodotto
    {
        protected string descrizione;
        protected int peso;

        public Prodotto()
        {
            descrizione = "";
            peso = 0;
        }

        public Prodotto(string desc, int pes)
        {
            descrizione = desc;
            peso = pes;
        }

        public string DESCRIZIONE
        {
            get { return descrizione; }
            set { descrizione = value; }
        }

        public int PESO
        {
            get { return peso; }
            set { peso = value; }
        }
    }
}
