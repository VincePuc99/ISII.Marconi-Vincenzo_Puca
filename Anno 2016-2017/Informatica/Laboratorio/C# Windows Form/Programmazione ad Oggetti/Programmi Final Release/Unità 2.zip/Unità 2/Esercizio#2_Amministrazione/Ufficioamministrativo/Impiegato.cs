﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personale
{
    class Impiegato : Dipendente
    {
        private decimal pagaoraria;
        private decimal tot;

        public Impiegato() : base()
        {
            pagaoraria = 0;
        }

        public Impiegato(string nom, string cogn, decimal ore) : base(nom, cogn, ore)
        {
            pagaoraria = 30;
            tot = 0;
        }

        public decimal Calcola()
        {
            decimal totale;
            tot = oredilav * pagaoraria;
            Ufficioamministrativo.Mylibary c = new Ufficioamministrativo.Mylibary();
            totale = c.calcolatasse(tot);
            return totale;
        }
    }
}
