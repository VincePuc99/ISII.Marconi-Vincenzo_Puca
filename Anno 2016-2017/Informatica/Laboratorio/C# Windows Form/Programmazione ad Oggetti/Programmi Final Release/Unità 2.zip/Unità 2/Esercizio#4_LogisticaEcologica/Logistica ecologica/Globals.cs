﻿using Mezziditrasporto;
using Farmacia;

namespace Logistica_ecologica
{
    class Globals
    {
        public static Ciclomotore[] ParcoMoto = new Ciclomotore[5];
        public static Prodotto[] Magazzino = new Prodotto[5];
    }
}
