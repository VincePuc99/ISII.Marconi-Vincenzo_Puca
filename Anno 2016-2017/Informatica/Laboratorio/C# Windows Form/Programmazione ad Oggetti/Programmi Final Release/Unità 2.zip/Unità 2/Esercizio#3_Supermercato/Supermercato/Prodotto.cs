﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supermercato
{
    class Prodotto
    {
        //attributi
        protected int codiceprod;
        protected string categ;
        protected int costounit;
        protected int sconto;
        //costruttori
        public Prodotto()
        {
            costounit = 0;
            categ = "";
            sconto = 5;
            codiceprod = 0;
        }

        public Prodotto(int code, string cat, int costou)
        {
            codiceprod = code;
            categ = cat;
            costounit = costou; 
        }
        //proprietà

        public string CATEGORIA
        {
            get { return categ; }
            set { categ = value; }
        }

        public int CODICEPRODOTTO
        {
            get { return codiceprod; }
            set { codiceprod = value; }
        }

        public int COSTOUNITARIO
        {
            get { return costounit; }
            set { costounit = value; }        
        }
    }
}
