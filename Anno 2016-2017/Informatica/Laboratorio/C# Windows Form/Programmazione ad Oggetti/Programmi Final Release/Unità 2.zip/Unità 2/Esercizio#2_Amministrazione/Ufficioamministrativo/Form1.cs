﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ufficioamministrativo
{
    public partial class frmmain : Form
    {
        public frmmain()
        {
            InitializeComponent();
        }

        private void bttcalcola_Click(object sender, EventArgs e)
        {

        }

        private void frmmain_Load(object sender, EventArgs e)
        {

        }

        private void bttcalcola_Click_1(object sender, EventArgs e)
        {
            if (rdbimpiegato.Checked == true || rdboperaio.Checked == true)
            {
                Personale.Dipendente richiamoclasse = new Personale.Dipendente(txtnome.Text,txtcognome.Text, decimal.Parse(txtoredilav.Text));

                if (rdbimpiegato.Checked == true)
                {
                    Personale.Impiegato chiamo = new Personale.Impiegato(txtnome.Text, txtcognome.Text, decimal.Parse(txtoredilav.Text));
                    decimal tot = chiamo.Calcola();
                    txtpaga.Text = "" + tot;

                }

                if (rdboperaio.Checked == true)
                {
                    Personale.Operaio chiamo = new Personale.Operaio(txtnome.Text, txtcognome.Text, decimal.Parse(txtoredilav.Text));
                    decimal tot = chiamo.Calcola();                  
                    txtpaga.Text = "" + tot;
                }
            }
            else
            {
                txtpaga.Text = "Errore";
            }

        }
    }
}
