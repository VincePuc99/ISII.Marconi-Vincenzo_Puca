﻿
namespace Mezzi
{
    class Auto : Veicolo
    {
        private bool abs;

        public Auto(string tip,string targ,int ann,int caval,bool abs1) 
            : base(tip,targ,ann,caval)
        {
            abs = abs1;
        }

        public double CalcolaPreventivo()
        {
            double tot;
            anno = 2016 - anno;
            if (abs == true)
            {
                if (anno > 10)
                {
                    tot = 3 * cavalli;
                }
                else
                {
                    tot = 2.5 * cavalli;
                }
            }
            else 
            {
                if (anno > 10)
                {
                    tot = 3.5 * cavalli;
                }
                else
                {
                    tot = 3 * cavalli;
                }              
            }
            return tot;
        }
    }
}
