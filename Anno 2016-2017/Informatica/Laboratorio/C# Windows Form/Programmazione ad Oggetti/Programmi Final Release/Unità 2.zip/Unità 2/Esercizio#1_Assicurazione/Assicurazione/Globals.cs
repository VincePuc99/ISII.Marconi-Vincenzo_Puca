﻿
namespace Mezzi
{
    class Globals
    {
        public static Veicolo[] PacchettoAssicurativo = new Veicolo[4];
    }
}
