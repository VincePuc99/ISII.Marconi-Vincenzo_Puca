﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Mezzi;

namespace Assicurazione
{
    public partial class frmmain : Form
    {
        static int cont;
        static double totale1;
        public frmmain()
        {
            InitializeComponent();
            cont = 0;
            totale1 = 0.0;
        }

        private void bttmem_Click(object sender, EventArgs e)
        {
            this.BackColor = DefaultBackColor;
            if (cmbtipo.Text == "" || cmbanno.Text == "" || txttarga.Text == "" || txtcavall.Text == "")
            {
                error.BackColor = Color.Red;
            }
            else
            { 
            if (cont < 4)
                {
                    error.BackColor = Color.Green;
                    Globals.PacchettoAssicurativo[cont] = new Veicolo(cmbtipo.Text, txttarga.Text, Int32.Parse(cmbanno.Text), Int16.Parse(txtcavall.Text));
                    cont++;
                }
                else
                {
                    error.BackColor = Color.Yellow;
                    bttmem.Enabled = false;
                    grpcaratter.Enabled = false;
                    grpopzioni.Enabled = true;
                    bttcalcola.Enabled = true;
                }
            
            }//fine prima if

        }//fine button

        private void bttcalcola_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                if (Globals.PacchettoAssicurativo[i].TIPO == "Auto")
                {
                    double totale = 0;
                    Auto A = new Auto(Globals.PacchettoAssicurativo[i].TIPO, Globals.PacchettoAssicurativo[i].TARGA, Globals.PacchettoAssicurativo[i].ANNO, Globals.PacchettoAssicurativo[i].CAVALLI,true);
                    totale = A.CalcolaPreventivo();
                    totale1 += totale;
                }
                else
                {
                    double totale = 0;
                    Moto M = new Moto(Globals.PacchettoAssicurativo[i].TIPO, Globals.PacchettoAssicurativo[i].TARGA, Globals.PacchettoAssicurativo[i].ANNO, Globals.PacchettoAssicurativo[i].CAVALLI, true);
                    totale = M.CalcolaPreventivo();
                    totale1 += totale;
                }        
            }

            if (rdbesclusiva.Checked == true)
            {
                double s, nuovotot;
                s = (totale1 * 20) / 100;
                nuovotot = totale1 - s;
                txttotale.Text = "" + nuovotot;
            }
            else
            {
                double s, nuovotot;
                s = (totale1 * 10) / 100;
                nuovotot = totale1 - s;
                txttotale.Text = "" + nuovotot;
            }

            bttcalcola.Enabled = false;
            grpopzioni.Enabled = false;
        }

        private void frmmain_Load(object sender, EventArgs e)
        {

        }

        private void error_Click(object sender, EventArgs e)
        {
            this.BackColor = error.BackColor;
        }//fine button

    }//fine class
}//fine namespace
