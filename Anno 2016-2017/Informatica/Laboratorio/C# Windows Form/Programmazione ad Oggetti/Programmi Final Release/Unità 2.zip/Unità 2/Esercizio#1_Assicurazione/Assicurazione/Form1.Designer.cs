﻿namespace Assicurazione
{
    partial class frmmain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpcaratter = new System.Windows.Forms.GroupBox();
            this.error = new System.Windows.Forms.Button();
            this.txttarga = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbtipo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcavall = new System.Windows.Forms.TextBox();
            this.cmbanno = new System.Windows.Forms.ComboBox();
            this.bttmem = new System.Windows.Forms.Button();
            this.grpopzioni = new System.Windows.Forms.GroupBox();
            this.rdbesclusiva = new System.Windows.Forms.RadioButton();
            this.rdbesperta = new System.Windows.Forms.RadioButton();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txttotale = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.grpcaratter.SuspendLayout();
            this.grpopzioni.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpcaratter
            // 
            this.grpcaratter.Controls.Add(this.error);
            this.grpcaratter.Controls.Add(this.txttarga);
            this.grpcaratter.Controls.Add(this.label4);
            this.grpcaratter.Controls.Add(this.label3);
            this.grpcaratter.Controls.Add(this.label2);
            this.grpcaratter.Controls.Add(this.cmbtipo);
            this.grpcaratter.Controls.Add(this.label1);
            this.grpcaratter.Controls.Add(this.txtcavall);
            this.grpcaratter.Controls.Add(this.cmbanno);
            this.grpcaratter.Location = new System.Drawing.Point(12, 10);
            this.grpcaratter.Name = "grpcaratter";
            this.grpcaratter.Size = new System.Drawing.Size(206, 100);
            this.grpcaratter.TabIndex = 0;
            this.grpcaratter.TabStop = false;
            this.grpcaratter.Text = "Caratteristiche Veicolo";
            // 
            // error
            // 
            this.error.Location = new System.Drawing.Point(185, 16);
            this.error.Name = "error";
            this.error.Size = new System.Drawing.Size(13, 13);
            this.error.TabIndex = 7;
            this.error.Text = " ";
            this.error.UseVisualStyleBackColor = true;
            this.error.Click += new System.EventHandler(this.error_Click);
            // 
            // txttarga
            // 
            this.txttarga.Location = new System.Drawing.Point(9, 72);
            this.txttarga.Name = "txttarga";
            this.txttarga.Size = new System.Drawing.Size(92, 20);
            this.txttarga.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(105, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Cavalli fiscali";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Targa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Anno";
            // 
            // cmbtipo
            // 
            this.cmbtipo.FormattingEnabled = true;
            this.cmbtipo.Items.AddRange(new object[] {
            "Auto",
            "Moto"});
            this.cmbtipo.Location = new System.Drawing.Point(9, 32);
            this.cmbtipo.Name = "cmbtipo";
            this.cmbtipo.Size = new System.Drawing.Size(92, 21);
            this.cmbtipo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo Veicolo";
            // 
            // txtcavall
            // 
            this.txtcavall.Location = new System.Drawing.Point(108, 72);
            this.txtcavall.Name = "txtcavall";
            this.txtcavall.Size = new System.Drawing.Size(90, 20);
            this.txtcavall.TabIndex = 6;
            // 
            // cmbanno
            // 
            this.cmbanno.FormattingEnabled = true;
            this.cmbanno.Items.AddRange(new object[] {
            "2002",
            "2003",
            "2004",
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016"});
            this.cmbanno.Location = new System.Drawing.Point(107, 32);
            this.cmbanno.Name = "cmbanno";
            this.cmbanno.Size = new System.Drawing.Size(91, 21);
            this.cmbanno.TabIndex = 2;
            // 
            // bttmem
            // 
            this.bttmem.Location = new System.Drawing.Point(12, 116);
            this.bttmem.Name = "bttmem";
            this.bttmem.Size = new System.Drawing.Size(206, 23);
            this.bttmem.TabIndex = 7;
            this.bttmem.Text = "Memorizza Dati";
            this.bttmem.UseVisualStyleBackColor = true;
            this.bttmem.Click += new System.EventHandler(this.bttmem_Click);
            // 
            // grpopzioni
            // 
            this.grpopzioni.Controls.Add(this.rdbesclusiva);
            this.grpopzioni.Controls.Add(this.rdbesperta);
            this.grpopzioni.Enabled = false;
            this.grpopzioni.Location = new System.Drawing.Point(12, 145);
            this.grpopzioni.Name = "grpopzioni";
            this.grpopzioni.Size = new System.Drawing.Size(206, 47);
            this.grpopzioni.TabIndex = 8;
            this.grpopzioni.TabStop = false;
            this.grpopzioni.Text = "Opzioni Assicurative";
            // 
            // rdbesclusiva
            // 
            this.rdbesclusiva.AutoSize = true;
            this.rdbesclusiva.Location = new System.Drawing.Point(100, 19);
            this.rdbesclusiva.Name = "rdbesclusiva";
            this.rdbesclusiva.Size = new System.Drawing.Size(100, 17);
            this.rdbesclusiva.TabIndex = 1;
            this.rdbesclusiva.Text = "Guida esclusiva";
            this.rdbesclusiva.UseVisualStyleBackColor = true;
            // 
            // rdbesperta
            // 
            this.rdbesperta.AutoSize = true;
            this.rdbesperta.Checked = true;
            this.rdbesperta.Location = new System.Drawing.Point(9, 19);
            this.rdbesperta.Name = "rdbesperta";
            this.rdbesperta.Size = new System.Drawing.Size(91, 17);
            this.rdbesperta.TabIndex = 0;
            this.rdbesperta.TabStop = true;
            this.rdbesperta.Text = "Guida esperta";
            this.rdbesperta.UseVisualStyleBackColor = true;
            // 
            // bttcalcola
            // 
            this.bttcalcola.Enabled = false;
            this.bttcalcola.Location = new System.Drawing.Point(12, 198);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(206, 23);
            this.bttcalcola.TabIndex = 9;
            this.bttcalcola.Text = "Calcola";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.bttcalcola_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Totale $";
            // 
            // txttotale
            // 
            this.txttotale.Location = new System.Drawing.Point(64, 227);
            this.txttotale.Name = "txttotale";
            this.txttotale.ReadOnly = true;
            this.txttotale.Size = new System.Drawing.Size(154, 20);
            this.txttotale.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(203, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "(Importo riferito a tutti i veicoli memorizzati)";
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 270);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txttotale);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bttcalcola);
            this.Controls.Add(this.grpopzioni);
            this.Controls.Add(this.bttmem);
            this.Controls.Add(this.grpcaratter);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Assicurazione";
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpcaratter.ResumeLayout(false);
            this.grpcaratter.PerformLayout();
            this.grpopzioni.ResumeLayout(false);
            this.grpopzioni.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpcaratter;
        private System.Windows.Forms.TextBox txttarga;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbtipo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtcavall;
        private System.Windows.Forms.ComboBox cmbanno;
        private System.Windows.Forms.Button bttmem;
        private System.Windows.Forms.GroupBox grpopzioni;
        private System.Windows.Forms.RadioButton rdbesclusiva;
        private System.Windows.Forms.RadioButton rdbesperta;
        private System.Windows.Forms.Button bttcalcola;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttotale;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button error;
    }
}

