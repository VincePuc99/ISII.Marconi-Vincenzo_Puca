﻿
namespace Mezzi
{
    class Moto : Veicolo
    {
        private bool PossibilitaPasseggero;

        public Moto(string tip, string targ, int ann, int caval, bool PossibilitaPasseggero1)
            : base(tip, targ, ann, caval)
        {
            PossibilitaPasseggero = PossibilitaPasseggero1;
        }

        public double CalcolaPreventivo()
        {
            double tot;
            anno = 2016 - anno;
            if (PossibilitaPasseggero == true)
            {
                if (anno > 10)
                {
                    tot = 2.5 * cavalli;
                }
                else
                {
                    tot = 2 * cavalli;
                }              
            }
            else 
            {
                if (anno > 10)
                {
                    tot = 2 * cavalli;
                }
                else 
                {
                    tot = 1.5 * cavalli;
                }            
            }
            return tot;
        }
    }
}
