﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Supermercato
{
    public partial class Frmain : Form
    {
        static double totale;
        public Frmain()
        {
            InitializeComponent();
        }

        private void Frmain_Load(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bttacquista_Click(object sender, EventArgs e)
        {
            //costo unitario e sconto scelto da me
            if (chkpane.Checked == true)
            {
                int q;
                Prodotto p = new Prodotto(0,"Pane",1);
                q = Int32.Parse(cmbpane.SelectedItem.ToString());
                Pane l = new Pane(0,"Pane",1,"Pane tipo 00",q,10);
                double tot;
                tot = l.prezzotot();
                totale += tot;
                txttot.Text = "" + totale;
            }

            if (chklatte.Checked == true)
            {
                int q;
                Prodotto p = new Prodotto(1, "Latte", 2);
                q = Int32.Parse(cmblatte.SelectedItem.ToString());
                Latte l = new Latte(2, "Latte", 2, "Latto Pastorizzato", q, 10);
                double tot;
                tot = l.prezzotot();
                totale += tot;
                txttot.Text = "" + totale;
            }

            if (chkuova.Checked == true)
            {
                int q;
                Prodotto p = new Prodotto(3, "Uova",3);
                q = Int32.Parse(cmbuova.SelectedItem.ToString());
                Uova l = new Uova(3, "Uova", 3, "Uova allevate a terra", q, 10);
                double tot;
                tot = l.prezzotot();
                totale += tot;
                txttot.Text = "" + totale;
            }
        }
    }
}
