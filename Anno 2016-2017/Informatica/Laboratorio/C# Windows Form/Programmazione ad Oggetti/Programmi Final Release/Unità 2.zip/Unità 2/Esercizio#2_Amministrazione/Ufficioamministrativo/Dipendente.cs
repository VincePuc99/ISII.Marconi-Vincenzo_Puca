﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personale
{
    class Dipendente
    {
        protected string nome;
        protected string cognome;
        protected decimal oredilav;

        //Costruttore
        public Dipendente()
        {
            nome = "";
            cognome = "";
           
        }

        //Costruttore overloaded
        public Dipendente(string nom, string cogn, decimal ore)
        {
            nome = nom;
            cogn = cognome;
            oredilav = ore;
        }


        public string NOME
        {
            get { return nome; }
            set { nome = value; }
        }

        public string COGNOME
        {
            get { return cognome; }
            set { cognome = value; }
        }
    }



}
