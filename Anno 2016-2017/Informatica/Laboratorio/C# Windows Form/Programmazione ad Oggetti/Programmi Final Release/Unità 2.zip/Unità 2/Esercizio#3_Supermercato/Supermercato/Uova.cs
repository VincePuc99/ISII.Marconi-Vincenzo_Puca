﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supermercato
{
    class Uova : Prodotto
    {
        private string denominazione;
        private int quantita;
        private double scon;
        private int costou0;

        public Uova()
        {
            denominazione = "";
            quantita = 0;
            scon = 0;   
        }

        public Uova(int code, string cat, int costou, string denomin, int quant, double scont)
            : base(code, cat, costou)
        {
            denominazione = "Uova allevate a terra";
            costou0 = costou;
            quantita = quant;
            if (scont > scon)
            {
                scon = scont;
            }
        }

        public double prezzotot()
        {
            double tot, nuovotot;
            double s;
            tot = quantita * costou0;
            s = (tot * scon) / 100;
            nuovotot = tot - s;
            return nuovotot;
        }
    }
}
