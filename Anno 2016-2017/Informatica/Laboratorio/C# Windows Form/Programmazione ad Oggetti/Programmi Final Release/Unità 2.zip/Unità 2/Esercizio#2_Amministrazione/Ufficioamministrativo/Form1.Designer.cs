﻿namespace Ufficioamministrativo
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpdatidip = new System.Windows.Forms.GroupBox();
            this.txtcognome = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpcatdip = new System.Windows.Forms.GroupBox();
            this.rdbimpiegato = new System.Windows.Forms.RadioButton();
            this.rdboperaio = new System.Windows.Forms.RadioButton();
            this.grpore = new System.Windows.Forms.GroupBox();
            this.txtoredilav = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtpaga = new System.Windows.Forms.TextBox();
            this.bttcalcola = new System.Windows.Forms.Button();
            this.grpdatidip.SuspendLayout();
            this.grpcatdip.SuspendLayout();
            this.grpore.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdatidip
            // 
            this.grpdatidip.Controls.Add(this.txtcognome);
            this.grpdatidip.Controls.Add(this.txtnome);
            this.grpdatidip.Controls.Add(this.label2);
            this.grpdatidip.Controls.Add(this.label1);
            this.grpdatidip.Location = new System.Drawing.Point(12, 12);
            this.grpdatidip.Name = "grpdatidip";
            this.grpdatidip.Size = new System.Drawing.Size(199, 64);
            this.grpdatidip.TabIndex = 0;
            this.grpdatidip.TabStop = false;
            this.grpdatidip.Text = "Dati Dipendenti";
            // 
            // txtcognome
            // 
            this.txtcognome.Location = new System.Drawing.Point(91, 35);
            this.txtcognome.Name = "txtcognome";
            this.txtcognome.Size = new System.Drawing.Size(100, 20);
            this.txtcognome.TabIndex = 3;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(91, 12);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(100, 20);
            this.txtnome.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cognome";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // grpcatdip
            // 
            this.grpcatdip.Controls.Add(this.rdbimpiegato);
            this.grpcatdip.Controls.Add(this.rdboperaio);
            this.grpcatdip.Location = new System.Drawing.Point(12, 82);
            this.grpcatdip.Name = "grpcatdip";
            this.grpcatdip.Size = new System.Drawing.Size(82, 83);
            this.grpcatdip.TabIndex = 1;
            this.grpcatdip.TabStop = false;
            this.grpcatdip.Text = "Categoria Dipendente";
            // 
            // rdbimpiegato
            // 
            this.rdbimpiegato.AutoSize = true;
            this.rdbimpiegato.Location = new System.Drawing.Point(6, 60);
            this.rdbimpiegato.Name = "rdbimpiegato";
            this.rdbimpiegato.Size = new System.Drawing.Size(71, 17);
            this.rdbimpiegato.TabIndex = 1;
            this.rdbimpiegato.TabStop = true;
            this.rdbimpiegato.Text = "Impiegato";
            this.rdbimpiegato.UseVisualStyleBackColor = true;
            // 
            // rdboperaio
            // 
            this.rdboperaio.AutoSize = true;
            this.rdboperaio.Location = new System.Drawing.Point(6, 37);
            this.rdboperaio.Name = "rdboperaio";
            this.rdboperaio.Size = new System.Drawing.Size(62, 17);
            this.rdboperaio.TabIndex = 0;
            this.rdboperaio.TabStop = true;
            this.rdboperaio.Text = "Operaio";
            this.rdboperaio.UseVisualStyleBackColor = true;
            // 
            // grpore
            // 
            this.grpore.Controls.Add(this.txtoredilav);
            this.grpore.Location = new System.Drawing.Point(103, 82);
            this.grpore.Name = "grpore";
            this.grpore.Size = new System.Drawing.Size(108, 43);
            this.grpore.TabIndex = 2;
            this.grpore.TabStop = false;
            this.grpore.Text = "Ore di lavoro";
            // 
            // txtoredilav
            // 
            this.txtoredilav.Location = new System.Drawing.Point(6, 17);
            this.txtoredilav.Name = "txtoredilav";
            this.txtoredilav.Size = new System.Drawing.Size(96, 20);
            this.txtoredilav.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Importo Stipendio $";
            // 
            // txtpaga
            // 
            this.txtpaga.Location = new System.Drawing.Point(111, 169);
            this.txtpaga.Name = "txtpaga";
            this.txtpaga.ReadOnly = true;
            this.txtpaga.Size = new System.Drawing.Size(100, 20);
            this.txtpaga.TabIndex = 5;
            // 
            // bttcalcola
            // 
            this.bttcalcola.Location = new System.Drawing.Point(104, 131);
            this.bttcalcola.Name = "bttcalcola";
            this.bttcalcola.Size = new System.Drawing.Size(107, 34);
            this.bttcalcola.TabIndex = 6;
            this.bttcalcola.Text = "Calcola Stipendio";
            this.bttcalcola.UseVisualStyleBackColor = true;
            this.bttcalcola.Click += new System.EventHandler(this.bttcalcola_Click_1);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 197);
            this.Controls.Add(this.bttcalcola);
            this.Controls.Add(this.txtpaga);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.grpore);
            this.Controls.Add(this.grpcatdip);
            this.Controls.Add(this.grpdatidip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Amministratore";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.grpdatidip.ResumeLayout(false);
            this.grpdatidip.PerformLayout();
            this.grpcatdip.ResumeLayout(false);
            this.grpcatdip.PerformLayout();
            this.grpore.ResumeLayout(false);
            this.grpore.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox grpdatidip;
        private System.Windows.Forms.TextBox txtcognome;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpcatdip;
        private System.Windows.Forms.RadioButton rdbimpiegato;
        private System.Windows.Forms.RadioButton rdboperaio;
        private System.Windows.Forms.GroupBox grpore;
        private System.Windows.Forms.TextBox txtoredilav;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtpaga;
        private System.Windows.Forms.Button bttcalcola;
    }
}

