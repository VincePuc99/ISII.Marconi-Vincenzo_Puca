﻿namespace Logistica_ecologica
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.grpdati = new System.Windows.Forms.GroupBox();
            this.error = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtpeso = new System.Windows.Forms.TextBox();
            this.Peso = new System.Windows.Forms.Label();
            this.cmbdenominaz = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bttadd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pgboccupaz = new System.Windows.Forms.ProgressBar();
            this.grpportatamax = new System.Windows.Forms.GroupBox();
            this.btt5ciclomotor = new System.Windows.Forms.Button();
            this.btt4ciclomotor = new System.Windows.Forms.Button();
            this.btt3ciclomotor = new System.Windows.Forms.Button();
            this.btt2ciclomotor = new System.Windows.Forms.Button();
            this.btt1ciclomotor = new System.Windows.Forms.Button();
            this.bttassocia = new System.Windows.Forms.Button();
            this.bttcanc = new System.Windows.Forms.Button();
            this.grpdati.SuspendLayout();
            this.grpportatamax.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpdati
            // 
            this.grpdati.Controls.Add(this.error);
            this.grpdati.Controls.Add(this.label3);
            this.grpdati.Controls.Add(this.txtpeso);
            this.grpdati.Controls.Add(this.Peso);
            this.grpdati.Controls.Add(this.cmbdenominaz);
            this.grpdati.Controls.Add(this.label1);
            this.grpdati.Location = new System.Drawing.Point(12, 12);
            this.grpdati.Name = "grpdati";
            this.grpdati.Size = new System.Drawing.Size(242, 67);
            this.grpdati.TabIndex = 0;
            this.grpdati.TabStop = false;
            this.grpdati.Text = "Dati Prodotto";
            // 
            // error
            // 
            this.error.Location = new System.Drawing.Point(212, 13);
            this.error.Name = "error";
            this.error.Size = new System.Drawing.Size(21, 21);
            this.error.TabIndex = 5;
            this.error.Text = " ";
            this.error.UseVisualStyleBackColor = true;
            this.error.Click += new System.EventHandler(this.error_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(212, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Kg.";
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(93, 38);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.Size = new System.Drawing.Size(113, 20);
            this.txtpeso.TabIndex = 3;
            // 
            // Peso
            // 
            this.Peso.AutoSize = true;
            this.Peso.Location = new System.Drawing.Point(7, 45);
            this.Peso.Name = "Peso";
            this.Peso.Size = new System.Drawing.Size(31, 13);
            this.Peso.TabIndex = 2;
            this.Peso.Text = "Peso";
            // 
            // cmbdenominaz
            // 
            this.cmbdenominaz.FormattingEnabled = true;
            this.cmbdenominaz.Location = new System.Drawing.Point(93, 13);
            this.cmbdenominaz.Name = "cmbdenominaz";
            this.cmbdenominaz.Size = new System.Drawing.Size(113, 21);
            this.cmbdenominaz.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Denominazione";
            // 
            // bttadd
            // 
            this.bttadd.Location = new System.Drawing.Point(12, 85);
            this.bttadd.Name = "bttadd";
            this.bttadd.Size = new System.Drawing.Size(242, 23);
            this.bttadd.TabIndex = 1;
            this.bttadd.Text = "Aggiungi al magazzino";
            this.bttadd.UseVisualStyleBackColor = true;
            this.bttadd.Click += new System.EventHandler(this.bttadd_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "% Occupazione magazzino";
            // 
            // pgboccupaz
            // 
            this.pgboccupaz.Location = new System.Drawing.Point(12, 127);
            this.pgboccupaz.Name = "pgboccupaz";
            this.pgboccupaz.Size = new System.Drawing.Size(242, 23);
            this.pgboccupaz.TabIndex = 3;
            // 
            // grpportatamax
            // 
            this.grpportatamax.Controls.Add(this.btt5ciclomotor);
            this.grpportatamax.Controls.Add(this.btt4ciclomotor);
            this.grpportatamax.Controls.Add(this.btt3ciclomotor);
            this.grpportatamax.Controls.Add(this.btt2ciclomotor);
            this.grpportatamax.Controls.Add(this.btt1ciclomotor);
            this.grpportatamax.Location = new System.Drawing.Point(12, 156);
            this.grpportatamax.Name = "grpportatamax";
            this.grpportatamax.Size = new System.Drawing.Size(242, 100);
            this.grpportatamax.TabIndex = 4;
            this.grpportatamax.TabStop = false;
            this.grpportatamax.Text = "Ciclomotore portata max Kg.";
            // 
            // btt5ciclomotor
            // 
            this.btt5ciclomotor.Location = new System.Drawing.Point(194, 19);
            this.btt5ciclomotor.Name = "btt5ciclomotor";
            this.btt5ciclomotor.Size = new System.Drawing.Size(41, 75);
            this.btt5ciclomotor.TabIndex = 4;
            this.btt5ciclomotor.Text = "5";
            this.btt5ciclomotor.UseVisualStyleBackColor = true;
            // 
            // btt4ciclomotor
            // 
            this.btt4ciclomotor.Location = new System.Drawing.Point(147, 19);
            this.btt4ciclomotor.Name = "btt4ciclomotor";
            this.btt4ciclomotor.Size = new System.Drawing.Size(41, 75);
            this.btt4ciclomotor.TabIndex = 3;
            this.btt4ciclomotor.Text = "4";
            this.btt4ciclomotor.UseVisualStyleBackColor = true;
            // 
            // btt3ciclomotor
            // 
            this.btt3ciclomotor.Location = new System.Drawing.Point(100, 19);
            this.btt3ciclomotor.Name = "btt3ciclomotor";
            this.btt3ciclomotor.Size = new System.Drawing.Size(41, 75);
            this.btt3ciclomotor.TabIndex = 2;
            this.btt3ciclomotor.Text = "3";
            this.btt3ciclomotor.UseVisualStyleBackColor = true;
            // 
            // btt2ciclomotor
            // 
            this.btt2ciclomotor.Location = new System.Drawing.Point(53, 19);
            this.btt2ciclomotor.Name = "btt2ciclomotor";
            this.btt2ciclomotor.Size = new System.Drawing.Size(41, 75);
            this.btt2ciclomotor.TabIndex = 1;
            this.btt2ciclomotor.Text = "2";
            this.btt2ciclomotor.UseVisualStyleBackColor = true;
            // 
            // btt1ciclomotor
            // 
            this.btt1ciclomotor.Location = new System.Drawing.Point(6, 19);
            this.btt1ciclomotor.Name = "btt1ciclomotor";
            this.btt1ciclomotor.Size = new System.Drawing.Size(41, 75);
            this.btt1ciclomotor.TabIndex = 0;
            this.btt1ciclomotor.Text = "1";
            this.btt1ciclomotor.UseVisualStyleBackColor = true;
            // 
            // bttassocia
            // 
            this.bttassocia.Location = new System.Drawing.Point(12, 262);
            this.bttassocia.Name = "bttassocia";
            this.bttassocia.Size = new System.Drawing.Size(169, 23);
            this.bttassocia.TabIndex = 5;
            this.bttassocia.Text = "Associa prodotto a ciclomotore";
            this.bttassocia.UseVisualStyleBackColor = true;
            this.bttassocia.Click += new System.EventHandler(this.bttassocia_Click);
            // 
            // bttcanc
            // 
            this.bttcanc.Location = new System.Drawing.Point(187, 262);
            this.bttcanc.Name = "bttcanc";
            this.bttcanc.Size = new System.Drawing.Size(68, 23);
            this.bttcanc.TabIndex = 6;
            this.bttcanc.Text = "Riavvia";
            this.bttcanc.UseVisualStyleBackColor = true;
            this.bttcanc.Click += new System.EventHandler(this.bttcanc_Click);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 291);
            this.Controls.Add(this.bttcanc);
            this.Controls.Add(this.bttassocia);
            this.Controls.Add(this.grpportatamax);
            this.Controls.Add(this.pgboccupaz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bttadd);
            this.Controls.Add(this.grpdati);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmmain";
            this.Text = "Spedizione";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpdati.ResumeLayout(false);
            this.grpdati.PerformLayout();
            this.grpportatamax.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpdati;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtpeso;
        private System.Windows.Forms.Label Peso;
        private System.Windows.Forms.ComboBox cmbdenominaz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttadd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ProgressBar pgboccupaz;
        private System.Windows.Forms.GroupBox grpportatamax;
        private System.Windows.Forms.Button bttassocia;
        private System.Windows.Forms.Button btt5ciclomotor;
        private System.Windows.Forms.Button btt4ciclomotor;
        private System.Windows.Forms.Button btt3ciclomotor;
        private System.Windows.Forms.Button btt2ciclomotor;
        private System.Windows.Forms.Button btt1ciclomotor;
        private System.Windows.Forms.Button error;
        private System.Windows.Forms.Button bttcanc;
    }
}

