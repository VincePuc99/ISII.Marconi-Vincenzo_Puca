﻿namespace Mezziditrasporto
{
    class Ciclomotore
    {
        private int identificatore;
        private int caricomax;
        private bool stato;

        public Ciclomotore()
        {
            identificatore = 0;
            caricomax = 0;
            stato = false;
        }

        public Ciclomotore(int iden, int carmax, bool stat)
        {
            identificatore = iden;
            caricomax = carmax;
            stato = stat;
        }

        public int IDENTIFICATORE
        {
            get { return identificatore; }
            set { identificatore = value; }
        }

        public int CARICOMAX
        {
            get { return caricomax; }
            set { caricomax = value; }
        }

        public bool STATO
        {
            get { return stato; }
            set { stato = value; }
        }
    }
}
