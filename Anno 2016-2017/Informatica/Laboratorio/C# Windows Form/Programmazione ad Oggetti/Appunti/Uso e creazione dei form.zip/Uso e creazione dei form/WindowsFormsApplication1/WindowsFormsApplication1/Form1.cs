﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmMain : Form
    {
        static bool click = false;
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           this.Text = "#1";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (click == false)
            {
                Form frm = new frm2(); //inizializza una variabile form richiamando in questo caso il form3
                frm.Show(); //mostra il form contenuto nella variabile
                //this.Hide(); //nasconde il form (è ancora operativo)
                click = true;
                button1.Text = "Chiudi 1";
            }
            else
                this.Close();


            //frm.ShowDialog(); //creazione di una finestra modale
            //una finestra è modale se ti obbliga a cliccarla per forza (avvisi,licenze,ecc)
        }
    }
}
