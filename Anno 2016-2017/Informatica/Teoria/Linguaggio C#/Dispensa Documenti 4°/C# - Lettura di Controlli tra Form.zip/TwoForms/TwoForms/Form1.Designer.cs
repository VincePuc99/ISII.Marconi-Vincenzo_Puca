﻿namespace TwoForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Form2Show = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Form2Show
            // 
            this.Form2Show.Location = new System.Drawing.Point(307, 208);
            this.Form2Show.Name = "Form2Show";
            this.Form2Show.Size = new System.Drawing.Size(115, 42);
            this.Form2Show.TabIndex = 1;
            this.Form2Show.Text = "Form2 Show";
            this.Form2Show.UseVisualStyleBackColor = true;
            this.Form2Show.Click += new System.EventHandler(this.Form2Show_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(30, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(251, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Inizio";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 262);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Form2Show);
            this.Name = "Form1";
            this.Text = "Lettura di controlli tra Form - Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        //1.
        //private System.Windows.Forms.Label textBox1;
        private System.Windows.Forms.Button Form2Show;
        public System.Windows.Forms.TextBox textBox1;
    }
}

