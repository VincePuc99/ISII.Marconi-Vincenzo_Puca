﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TwoForms
{

    public partial class Form2 : Form
    {

private Form1 myForm1;

public Form2(Form1 form1)
{
    myForm1 = form1;
    InitializeComponent();
}

private void Ricopia_Click(object sender, EventArgs e)
{
    //lbl2.Text = myForm1.textBox1.Text;
    //lbl2.Text = myForm1.MyProptextBox1;
    lbl2.Text = myForm1.MytextBox1();
}


    }
}
