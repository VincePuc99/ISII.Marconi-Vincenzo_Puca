﻿namespace TwoForms
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl2 = new System.Windows.Forms.Label();
            this.Ricopia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(50, 51);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(58, 13);
            this.lbl2.TabIndex = 0;
            this.lbl2.Text = "Etichetta 2";
            // 
            // Ricopia
            // 
            this.Ricopia.Location = new System.Drawing.Point(285, 220);
            this.Ricopia.Name = "Ricopia";
            this.Ricopia.Size = new System.Drawing.Size(128, 30);
            this.Ricopia.TabIndex = 1;
            this.Ricopia.Text = "Ricopia";
            this.Ricopia.UseVisualStyleBackColor = true;
            this.Ricopia.Click += new System.EventHandler(this.Ricopia_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 262);
            this.Controls.Add(this.Ricopia);
            this.Controls.Add(this.lbl2);
            this.Name = "Form2";
            this.Text = "Lettura di controlli tra Form - Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Button Ricopia;
    }
}