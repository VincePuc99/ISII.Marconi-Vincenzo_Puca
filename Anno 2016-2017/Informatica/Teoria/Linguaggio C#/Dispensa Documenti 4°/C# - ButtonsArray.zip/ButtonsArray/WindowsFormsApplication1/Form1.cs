﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Button[] btnArray = new Button[] { myButton1, myButton2 };
            for (int i = 0; i < btnArray.Length; i++)
                btnArray[i].Click += new System.EventHandler(ClickButton);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Vuoi uscire?", "Conferma uscita", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        public void ClickButton(Object sender, System.EventArgs e)
        {
            Button btn = (Button)sender;
            MessageBox.Show("You clicked character [" + btn.Text + "]");
        } 
    }
}
