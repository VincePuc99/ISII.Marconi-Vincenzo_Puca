﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices; 

namespace Controllo_menù_PC
{
    class Program
    {

        [DllImport("PowrProf.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool SetSuspendState(bool hiberate, bool forceCritical, bool disableWakeEvent);

        [DllImport("user32")]
        public static extern bool ExitWindowsEx(uint uFlags, uint dwReason);

        [DllImport("user32")]
        public static extern void LockWorkStation();

        static void Main(string[] args)
        {
            int scelta;
            int conterr = 3;
            string def;

            
            restart:
            Console.Clear();
            do
            {

            Console.WriteLine("==========================================");
            Console.WriteLine("Benvenuto nel programma di controllo PC...");
            Console.WriteLine("==========================================");
            Console.WriteLine("Seleziona un opzione a scelta:            ");
            Console.WriteLine("==========================================");
            Console.WriteLine("1)Spegni il PC");
            Console.WriteLine("2)Riavvia il PC");
            Console.WriteLine("3)Ibernazione");
            Console.WriteLine("4)Disconnetti e cambia utente");
            Console.WriteLine("5)Blocca il PC");
            Console.WriteLine("6)Esci dal programma");
            Console.WriteLine("==========================================\n");
            Console.Write("Immetere l'opzione desiderata --> ");
            scelta = Convert.ToInt32(Console.ReadLine());

            Thread.Sleep(1000);
            if (scelta > 6 || scelta < 1)
            {
                Console.Clear();
                conterr--;
                Console.Write("Caricamento in corso");
                Thread.Sleep(1000);
                Console.Write(".");
                Thread.Sleep(1000);
                Console.Write(".");
                Thread.Sleep(1000);
                Console.WriteLine(".");
                Thread.Sleep(1000);
                Console.WriteLine("Attenzione scelta non prevista,tentativi rimasti {0}.\n", conterr);
            }
                if (conterr == 0)             
                {
                    Console.WriteLine("Limite tentativi raggiunto...Chiusura programma in corso...");
                    break;
                }
              
            } while (scelta > 6 || scelta < 1);

            Console.Clear();
            Console.Write("Caricamento in corso");
            Thread.Sleep(1000);
            Console.Write(".");
            Thread.Sleep(1000);
            Console.Write(".");
            Thread.Sleep(1000);
            Console.WriteLine(".");
            Thread.Sleep(1000);

            if (scelta == 1)
            {
                Console.Clear();
                Console.Beep();
                Console.WriteLine("\n!ATTENZIONE!\n");
                Console.WriteLine("=====================================");
                Console.WriteLine("Arrestando il sistema...");
                Console.WriteLine("=====================================");
                Console.WriteLine("° Verranno chiusi tutti i programmi in esecuzione...");
                Console.WriteLine("° I dati non salvati andranno persi...");
                Console.WriteLine("° Verrà chiusa la sessione seguente e il sistema verrà arrestato...");
                Console.WriteLine("=====================================");
                Console.Write("Continuare? (SI)--(NO): ");
                def = Console.ReadLine();

                if (def.ToUpper() == "SI")
                {
                    Process.Start("shutdown", "/s /t 0");
                }

                if (def.ToUpper() == "NO")
                {
                    Console.Clear();
                    Console.Write("Ritorno ad Inizio");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.WriteLine(".");
                    Thread.Sleep(1000);
                    goto restart;
                }
            }
                if (scelta == 2)
                {
                    Console.Clear();
                    Console.Beep();
                    Console.WriteLine("\n!ATTENZIONE!\n");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Riavviando il sistema...");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("° Verranno chiusi tutti i programmi in esecuzione...");
                    Console.WriteLine("° I dati non salvati andranno persi...");
                    Console.WriteLine("° Verrà chiusa la sessione seguente e riavvia Windows...");
                    Console.WriteLine("=====================================");
                    Console.Write("Continuare? (SI)--(NO): ");
                    def = Console.ReadLine();
                
                if (def.ToUpper() == "SI")
                {
                    Process.Start("shutdown", "/r /t 0");
                }

                if (def.ToUpper() == "NO")
                {
                    Console.Clear();
                    Console.Write("Ritorno ad Inizio");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.WriteLine(".");
                    Thread.Sleep(1000);
                    goto restart;
                }
                }

                if (scelta == 3)
                {
                    Console.Clear();
                    Console.Beep();
                    Console.WriteLine("\n!ATTENZIONE!\n");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Ibernando il sistema...");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("° Salva la sessione e arresta il sistema...");
                    Console.WriteLine("° All' accensione la sessione verrà ripristinata...");
                    Console.WriteLine("° Tuttavia nessun dato andrà perso...");
                    Console.WriteLine("=====================================");
                    Console.Write("Continuare? (SI)--(NO): ");
                    def = Console.ReadLine();
                
                if (def.ToUpper() == "SI")
                {
                    SetSuspendState(true, true, true);
                }

                if (def.ToUpper() == "NO")
                {
                    Console.Clear();
                    Console.Write("Ritorno ad Inizio");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.WriteLine(".");
                    Thread.Sleep(1000);
                    goto restart;
                }
                }

                if (scelta == 4)
                {
                    Console.Clear();
                    Console.Beep();
                    Console.WriteLine("\n!ATTENZIONE!\n");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Disconnetti e cambia utente...");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("° Chiude i programmi in esecuzione...");
                    Console.WriteLine("° I dati non salvati andranno persi...");
                    Console.WriteLine("° Chiude la sessione e cambia utente...");
                    Console.WriteLine("=====================================");
                    Console.Write("Continuare? (SI)--(NO): ");
                    def = Console.ReadLine();
                
                if (def.ToUpper() == "SI")
                {
                    ExitWindowsEx(0, 0);
                }

                if (def.ToUpper() == "NO")
                {
                    Console.Clear();
                    Console.Write("Ritorno ad Inizio");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.Write(".");
                    Thread.Sleep(1000);
                    Console.WriteLine(".");
                    Thread.Sleep(1000);
                    goto restart;
                }
                }
                if (scelta == 5)
                {
                    Console.Clear();
                    Console.Beep();
                    Console.WriteLine("\n!ATTENZIONE!\n");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Bloccando il sistema...");
                    Console.WriteLine("=====================================");
                    Console.WriteLine("° Salva la sessione e blocca il sistema...");
                    Console.WriteLine("° Ri-Loggandosi la sessione verrà ripristinata...");
                    Console.WriteLine("° Tuttavia nessun dato andrà perso...");
                    Console.WriteLine("=====================================");
                    Console.Write("Continuare? (SI)--(NO): ");
                    def = Console.ReadLine();
                
                    if (def.ToUpper() == "SI")
                    {
                        LockWorkStation(); 
                    }

                    if (def.ToUpper() == "NO")
                    {
                        Console.Clear();
                        Console.Write("Ritorno ad Inizio");
                        Thread.Sleep(1000);
                        Console.Write(".");
                        Thread.Sleep(1000);
                        Console.Write(".");
                        Thread.Sleep(1000);
                        Console.WriteLine(".");
                        Thread.Sleep(1000);
                        goto restart;
                    }
                }
                if (scelta == 6)
                    do
                    {
                        Console.Clear();
                        Console.Beep();
                        Console.Write("Chiusura programma in corso");                        
                        Thread.Sleep(1000);
                        Console.Write(".");
                        Thread.Sleep(1000);
                        Console.Write(".");
                        Thread.Sleep(1000);
                        Console.WriteLine(".");
                        Thread.Sleep(1000);
                        break;
                    } while (true);                           
            
        }
    }
}
