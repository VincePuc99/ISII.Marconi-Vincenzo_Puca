﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ricerca_Numerica
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                int radno = Newnum(1, 101);
                int count = 1;
                while (true)
                {
                    Console.WriteLine("Scrivere un numero da 1 a 100 (0 per uscire): ");
                    int input = Convert.ToInt32(Console.ReadLine());
                    if (input == 0)
                        return;
                    else if (input < radno)
                    {
                        Console.WriteLine("Poco,riprova.");
                        ++count;
                        continue;
                    }
                    else if (input > radno)
                    {
                        Console.WriteLine("Alto,riprova.");
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("Lo hai trovato! Il numero era {0}!", radno);
                        Console.WriteLine("Lo hai trovato in {0} {1} \n", count, count == 1 ? "tentativo" : "tentavi");
                        break;
                    }
                }
            }
                      
        }
        static int Newnum(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}
