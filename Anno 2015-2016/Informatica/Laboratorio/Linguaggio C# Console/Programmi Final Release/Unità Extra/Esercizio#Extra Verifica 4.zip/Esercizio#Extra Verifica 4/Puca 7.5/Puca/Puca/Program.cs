﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO; //per gestire i file 

namespace Puca
{
    class Program
    {
        static void Main(string[] args)
        {//inizio programma

            //variabili
            string collegamento = @"C:\Users\M_inf2.terza\Desktop\rubrica.txt";
            int cont = 0;
            int scelta = 0;
            string nome, cognome, numero, partecognome;

           //programma codice
                do
                {
                    //menu
                    Console.WriteLine("========== Rubrica ========");
                    Console.WriteLine("1) Inserimento singolo contatto");
                    Console.WriteLine("2) Ricerca per cognome");
                    Console.WriteLine("3) Criterio di ricerca");
                    Console.WriteLine("4) Termina esecuzione programma");
                    Console.WriteLine("===========================");
                    Console.Write("Inserire scelta desiderata: ");
                    scelta = Convert.ToInt16(Console.ReadLine());

                    Thread.Sleep(300); //pausa di 0.3 sec
                    Console.Clear(); //cancellazione cosole
                    switch (scelta)  //codice menu
                    {

                        case 1: //Inserimento singolo contatto

                            Console.WriteLine("Inserire Cognome del contatto: ");
                            cognome = Console.ReadLine();

                            Console.WriteLine("Inserire Nome del contatto: ");
                            nome = Console.ReadLine();

                            do
                            {
                                Console.WriteLine("Inserire Numero del contatto (es, xxx-xxxxxxx): ");
                                numero = Console.ReadLine();

                                if (numero.Length < 11)
                                {
                                    Console.WriteLine("Numero non valido");
                                }

                            } while (numero.Length < 11);
                            StreamWriter scrivi = new StreamWriter(collegamento, true); //scrittura
                            scrivi.WriteLine(cognome); //scrittura nel file
                            scrivi.WriteLine(nome);
                            scrivi.WriteLine(numero);
                            scrivi.Close();

                            cont += 3;

                            break;

                        case 2: //Ricerca per cognome

                             try //prova
                            {

                            Console.WriteLine("Inserire cognome da ricercare: ");
                            cognome = Console.ReadLine();

                            StreamReader leggi = new StreamReader(collegamento); //lettura del file
                            string[] riempimento = new string[cont];

                            for (int i = 0; i < riempimento.GetLength(0); i++) //riempimento array con i dati file
                            {
                                riempimento[i] = leggi.ReadLine();
                            }

                            for (int i = 0; i < riempimento.GetLength(0); i++ )  //ricerca semplice  
                            {
                                if (cognome == riempimento[i])
                                {
                                    Console.WriteLine("{0}/{1}", riempimento[i + 1], riempimento[i + 2]); //visualizzazione
                                }
                                else
                                    Console.WriteLine("Contatto non trovato");
     
                            }
                            Console.ReadLine();
                            leggi.Close();

                             }
                             catch (FileNotFoundException) //file non trovato
                             {
                                 Console.WriteLine("File non trovato");
                             }
                             finally //conclusione
                             {
                                 Console.WriteLine("Fine programma");
                             }

                            break;

                        case 3: // Criterio di ricerca

                            Console.WriteLine("Inserire una parte di cognome: "); //input cognome
                            partecognome = Console.ReadLine();

                            StreamReader leggi2 = new StreamReader(collegamento); //lettura del file
                             string[] riempimento2 = new string[cont];

                            for (int i = 0; i < riempimento2.GetLength(0); i++) //riempimento array con i dati file
                            {
                                riempimento2[i] = leggi2.ReadLine();
                            }

                            for (int i = 0; i < riempimento2.GetLength(0); i++) //verifica del prefisso-suffisso
                            {
                                if (riempimento2[i].EndsWith(partecognome) == true)
                                {
                                    Console.WriteLine("{0}/{1}", riempimento2[i + 1], riempimento2[i + 2]);
                                }
                                if (riempimento2[i].StartsWith(partecognome) == true)
                                {
                                    Console.WriteLine("{0}/{1}", riempimento2[i + 1], riempimento2[i + 2]);
                                }
                                else
                                    Console.WriteLine("Nessun contatto soddisfa i criteri");

                            }


                            break;

                        case 4: //Termina esecuzione programma
                            Console.WriteLine("Chiusura");
                            return;
                    }
                    Console.Clear(); //cancellazione console

                } while (true); //il programma gira all'infinito
            

        }//fine programmma
    }
}
