﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Puca
{
    class Program
    {
        static void Main(string[] args)
        {
            //area dati
            int scelta = 0;
            string[,] tabella = new string[,] { {"MOV CL,05","B1","05", }, 
                                                 {"INC CL"   ,"FA","31",},   
                                                 {"DEC CL"   ,"FE","C9",},      
                                                 {"JNZ 0110" ,"75","F9" } };
            int cont = 0;
            string[,] input = new string[4,2];
            int mod = 0;
            string nuovo = "";

            //manu e sviluppo
            do
            {

            Console.WriteLine("================= MENU ===============");
            Console.WriteLine("1)Visualizza la tabella del linguaggio");
            Console.WriteLine("2)Input programma assembly 80X86      ");
            Console.WriteLine("3)Esegui istruzione assembler 80X86   ");
            Console.WriteLine("4)Modifica istruzione                 ");
            Console.WriteLine("5)Fine                                ");
            Console.WriteLine("======================================");

                //scelta dal menu
            do
            {
                Console.Write("Inserire opzione scelta → ");
                scelta = Convert.ToInt16(Console.ReadLine());

                    if(scelta < 1 || scelta > 5)
                    {
                    Console.WriteLine("Numero non valido riprova");
                    }

            } while (scelta < 1 || scelta > 5);

            Thread.Sleep(1000);
            Console.Clear();

            switch (scelta)
            { 
                    //visualizzazione tabella
                case 1:
                    Console.WriteLine("Istruzione         C.O         Operando");
                    for (int i = 0; i < tabella.GetLength(0); i++) //gestione righe
                    { 
                        for ( int j =0; j<tabella.GetLength(1);j++) //gestione colonne
                        {
                            cont++;
                            if ( cont% 3 == 0)
                            {
                                Console.WriteLine("{0}         ",tabella[i, j]);
                            }
                            else
                                Console.Write("{0}            ", tabella[i, j]);
                        }
                    
                    }
                    break;
            
                case 2:

                    //inserimento programma
                    cont = 0;
                    for (int i = 0; i < input.GetLength(0); i++)                       
                    {
                        for (int j = 0; j < tabella.GetLength(1); j++)
                        {
                            cont++;
                            do
                            {                               
                                Console.WriteLine("Inserire in {0},l'istruzione(come da tabella): ",cont);
                                input[i, j] = Console.ReadLine().ToUpper();

                                if (input[i, j] != tabella[0, 0] && input[i, j] != tabella[1,0] && input[i, j] != tabella[2,0] && input[i, j] != tabella[3,0])
                                {
                                    Console.WriteLine("Valore inserito non in tabella!");                                
                                }

                            } while (input[i, j] != tabella[0, 0] && input[i, j] != tabella[1, 0] && input[i, j] != tabella[2, 0] && input[i, j] != tabella[3, 0]);
                        }
                    }
                    break;
            
                case 3:

                    //esegui assembler
                    for (int i = 0; i < input.GetLength(0); i++)
                    {
                        for (int j = 0; j < tabella.GetLength(1); j++)
                        {
                            do
                            {
                                Console.WriteLine("Inserire l'istruzione da tradurre(come da tabella): ", cont);
                                input[i, j] = Console.ReadLine().ToUpper();

                                if (input[i, j] != tabella[0, 0] && input[i, j] != tabella[1, 0] && input[i, j] != tabella[2, 0] && input[i, j] != tabella[3, 0])
                                {
                                    Console.WriteLine("Valore inserito non in tabella!");
                                }
                            } while (input[i, j] != tabella[0, 0] && input[i, j] != tabella[1, 0] && input[i, j] != tabella[2, 0] && input[i, j] != tabella[3, 0]);

                            Console.WriteLine(input[i,j+2]);  //errore nella visualizzazione della traduzione
                        }
                    }

                    break;
            
                case 4:

                    //modifica istruzioni input già inserite
                    do
                    {
                        Console.WriteLine("Inserire istruzione da modificare (da 1 a 4): ");
                        mod = Convert.ToInt16(Console.ReadLine());

                        if(mod < 1|| mod > 4)
                        {
                          Console.WriteLine("Comando inserito inesistente");
                        }

                    } while (mod < 1|| mod > 4);

                    if (mod == 1)
                    { 
                        Console.WriteLine("Inserire una nuova istruzione: ");
                        nuovo = Console.ReadLine();
                        input[0, 0] = nuovo;
                    }

                    if (mod == 2)
                    {
                        Console.WriteLine("Inserire una nuova istruzione: ");
                        nuovo = Console.ReadLine();
                        input[1, 0] = nuovo;
                    }

                    if (mod == 3)
                    {
                        Console.WriteLine("Inserire una nuova istruzione: ");
                        nuovo = Console.ReadLine();
                        input[2, 0] = nuovo;
                    }

                    if (mod == 4)
                    {
                        Console.WriteLine("Inserire una nuova istruzione: ");
                        nuovo = Console.ReadLine();
                        input[3, 0] = nuovo;
                    }
                    break;  
       
                case 5:
                    return;         
            }

            Thread.Sleep(300);
            Console.Clear();
        }while(true);

    //fine programma

        }
    }
}
