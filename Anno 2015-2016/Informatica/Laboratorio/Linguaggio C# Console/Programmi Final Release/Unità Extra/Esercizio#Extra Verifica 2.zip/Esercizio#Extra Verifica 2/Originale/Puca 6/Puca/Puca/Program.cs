﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Puca
{
    class Program
    {   //verifica di puca
        //11:00   01/12/15 ver. 1.0
        static void Main(string[] args)
        {
            //area dati
            int scelta, conterr = 0, biglietti = 5, persona1, persona2, persona3;
            Random rnd = new Random();
            int vincenti;

            //elaborazione
            do
            {


                
                Console.WriteLine("========= Lotteria ========");//menu scelta
                Console.WriteLine("\t1) Vendita biglietti            ");
                Console.WriteLine("\t2) Estrazione biglietti vincenti");
                Console.WriteLine("\t3) Fine programma               ");
                Console.WriteLine("==================================");

                Console.Write("Inserire opzione scelta--> ");
                scelta = Convert.ToInt16(Console.ReadLine());

                if (scelta < 1 || scelta > 3)
                {
                    Console.WriteLine("Opzione non presente, riprovare");
                    Thread.Sleep(500);
                        
                    Console.Clear();
                    conterr++;
                }
                if (conterr == 3)
                {
                    Console.WriteLine("Numero tentativi massimo raggiunto,chiusura.");
                    return;
                }
            } while (scelta < 1 || scelta > 3);

            Thread.Sleep(1000);
            Console.Clear();

            switch (scelta)
            { 
                case 1:
                    
                    do
                    {
                        Console.WriteLine("========= Lotteria ========");//vendita biglietti
                        Console.WriteLine(">>>>>Vendita Biglietti<<<<<<<<<<<<");
                        Console.WriteLine("Persona 1: quanti biglietti vuoi acquistare? ");
                        persona1 = Convert.ToInt16(Console.ReadLine());
                        //vendita persona 1
                        if (persona1 == 0)
                        {
                            Console.WriteLine("Non ha acquistato biglietti...");
                        }

                        if (persona1 > 3)
                        {
                            Console.WriteLine("Acquisto non consetito max 3 biglietti");
                            biglietti += persona1;
                            
                        }

                        if (persona1 < 3 && persona1 != 0 )
                        {
                            Console.WriteLine("Acquisto effettuato con successo!!");
                            biglietti -= persona1;
                        }
                        if (persona1 == 1 )
                        {
                            Console.WriteLine("Hai il biglietto 1");
                        
                        }
                        if (persona1 == 2)
                        {
                            Console.WriteLine("Hai il biglietto 1-2");

                        }
                        if (persona1 == 3)
                        {
                            Console.WriteLine("Hai il biglietto 1-2-3");

                        }
                    } while (persona1 > 3 );
                    Thread.Sleep(1000);
                    Console.Clear();

                    do
                    {
                        Console.WriteLine("Persona 2: quanti biglietti vuoi acquistare? ");
                        persona2 = Convert.ToInt16(Console.ReadLine());
                        //vendita persona 2
                        if (persona2 == 0)
                        {
                            Console.WriteLine("Non ha acquistato biglietti...");
                        }

                        if (persona2 > 3)
                        {
                            Console.WriteLine("Acquisto non consetito max 3 biglietti");
                            biglietti += persona2;

                        }

                        if (persona2 < 3 && persona2 != 0)
                        {
                            Console.WriteLine("Acquisto effettuato con successo!!");
                            biglietti -= persona2;
                        }

                        if (persona2 == 1)
                        {
                            Console.WriteLine("Hai il biglietto 1");

                        }
                        if (persona2 == 2)
                        {
                            Console.WriteLine("Hai il biglietto 1-2");

                        }
                        if (persona2 == 3)
                        {
                            Console.WriteLine("Hai il biglietto 1-2-3");

                        }
                        if (biglietti < 0)
                        {
                            Console.WriteLine("Acquisto non consentito");
                            biglietti += persona2;
                        }
                    } while (persona2 > 3);
                    Thread.Sleep(1000);
                    Console.Clear();
                    do
                    {
                        Console.WriteLine("Persona 3: quanti biglietti vuoi acquistare? ");
                        persona3 = Convert.ToInt16(Console.ReadLine());
                        //vendita persona 3
                        if (persona3 == 0)
                        {
                            Console.WriteLine("Non ha acquistato biglietti...");
                        }

                        if (persona3 > 3)
                        {
                            Console.WriteLine("Acquisto non consetito max 3 biglietti");
                            biglietti += persona1;

                        }

                        if (persona3 < 3 && persona3 != 0)
                        {
                            Console.WriteLine("Acquisto effettuato con successo!!");
                            biglietti -= persona3;
                        }

                        if (persona3 == 1)
                        {
                            Console.WriteLine("Hai il biglietto 1");

                        }
                        if (persona3 == 2)
                        {
                            Console.WriteLine("Hai il biglietto 1-2");

                        }
                        if (persona3 == 3)
                        {
                            Console.WriteLine("Hai il biglietto 1-2-3");

                        }
                        if (biglietti < 0)
                        {
                            Console.WriteLine("Acquisto non consentito");
                            biglietti += persona3;
                        }
                    } while (persona3 > 3);

                        Console.WriteLine("===========Fine Vendita==========");
                        break;
                    //estrazione
                case 2:
                    vincenti = rnd.Next(1, 6);
                    //output
                    Console.WriteLine("Estrazione vincente");
                    Console.WriteLine("===========================");
                    Console.WriteLine("<<<<<<<<<<Primo Premio>>>>>>");
                    Console.WriteLine("TV 60'' Led");
                    Console.WriteLine("<<<<<<<<<<Secondo Premio>>>>>>");
                    Console.WriteLine("Smartphone");
                    Console.Write("Estrazione biglietto");
                    Thread.Sleep(500);
                    Console.Write(".");
                    Thread.Sleep(500);
                    Console.Write(".");
                    Thread.Sleep(500);
                    Console.Write(".");
                    Console.WriteLine("{0}",vincenti);

                    //if (persona1 == vincenti)
                    //{
                    //    Console.WriteLine("La persona 1 ha vinto");
                    //}

                    //if (persona2 == vincenti)
                    //{
                    //    Console.WriteLine("La persona 2 ha vinto");
                    //}

                    //if (persona3 == vincenti)
                    //{
                    //    Console.WriteLine("La persona 3 ha vinto");
                    //}
              
                    break;
                    //chiusura
                case 3:
                    Console.WriteLine("Chiusura programma");
                    Thread.Sleep(1000);
                    return;
            }

            





        }
    }
}
