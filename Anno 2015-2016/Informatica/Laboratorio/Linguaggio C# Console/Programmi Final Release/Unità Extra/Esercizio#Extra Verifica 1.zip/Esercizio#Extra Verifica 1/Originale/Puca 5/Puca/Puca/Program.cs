﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Puca
{
    class Program
    {
        //Programma della verifica
        //ver 1.0 by puca,problema loop
        static void Main(string[] args)
        {
            //Variabili
            int scelta;
            int biro = 100;
            int matita = 50;
            int gomme = 30;
            int fogli = 200;
            //visualizzare magazzino
            Console.WriteLine("=======Cartoleria SchoolShop=======");
            Console.WriteLine(">>>>>>>Giacenza iniziale<<<<<<<<<<<");
            Console.WriteLine("Articolo             Quantità");
            Console.WriteLine("Biro                     100 ");
            Console.WriteLine("Matite                   50 ");
            Console.WriteLine("Gomme                    30");
            Console.WriteLine("Fogli                    200 ");
            Console.WriteLine("==================================");
            //input
            do
            {
                Console.WriteLine("Inserire il codice del prodotto che si vuole acquistare(Biro=0,Matita=1,Gomma=2,Fogli=3): ");
                scelta = Convert.ToInt32(Console.ReadLine());

                if (scelta < 0 || scelta > 3 )
                    Console.WriteLine("Codice articolo inesistente...");

            } while (scelta < 0 || scelta > 3);//condizione input errato

            //elaborazione
            do
            {
                if (scelta == 0)
                {
                    Console.WriteLine("-1 Biro");
                }
                else biro--;

                if (scelta == 1)
                {
                    Console.WriteLine("Matite -1");
                }
                else matita--;


                if (scelta == 2)
                {
                    Console.WriteLine("Gomme -1");
                }
                else gomme--;


                if (scelta == 3)
                {
                    Console.WriteLine("fogli -1");
                    
                }
                else fogli--;
                               
                if (biro + matita + gomme + fogli == 0)
                 {
                    Console.WriteLine("Score finite");
                    
                 }
                //incompreso loop inserisco break
                //non decrementa 
                break;
            } while (true);
            //output

            Console.Write("Sono state vendute {0} Biro {1} Matite {2} gomme {3} fogli", biro,matita,gomme,fogli);

            
            Console.ReadKey();
        }
    }
}
