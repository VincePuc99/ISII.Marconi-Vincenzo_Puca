﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verifica
{
    class Program
    {
        static void Main(string[] args)
        {
            int scelta;
            int biro = 100;
            int matite = 3;
            int gomme = 30;
            int fogli = 200;
            bool control = false;


            Console.WriteLine("========Cartoleria SchoolShop=======");
            Console.WriteLine(">>>>>>>>>>Giazenza iniziale<<<<<<<<<");
            Console.WriteLine("Articolo    Quantità");
            Console.WriteLine("Biro         100");
            Console.WriteLine("Matite       50");
            Console.WriteLine("Gomme        30");
            Console.WriteLine("Fogli        200");
            Console.WriteLine("====================================\n");


            do
            {
                Console.WriteLine("Codici Articoli: 0=biro, 1=matite, 2=gomme, 3=fogli protocollo");
                Console.Write("Inserire il codice dell'articolo che si vuole acquistare: ");
                scelta = Convert.ToInt16(Console.ReadLine());

                if (scelta > 3 ||scelta < 0)
                    Console.WriteLine("Codice articolo inesistente,riprovare...");

            } while (scelta > 3 || scelta < 0);


            do
            {
                Console.Write("Ordinazione dal magazzino...Immetere il codice articolo: ");
                scelta = Convert.ToInt32(Console.ReadLine());

                if (scelta == 0 || scelta ==1 || scelta ==2 || scelta ==3)
               {
                //biro
                if (scelta == 0)
                    if (biro == 0)
                    {
                        Console.WriteLine("Scorte Esaurite...");
                    }
                    else biro--;
                //matite
                if (scelta == 1)
                {
                    if (matite == 0)
                        Console.WriteLine("Scorte Esaurite...");
                    else matite--;
                }
                //gomme
                if (scelta == 2)
                {
                    if (gomme == 0)
                        Console.WriteLine("Scorte Esaurite...");
                    else gomme--;
                }
                //fogli
                if (scelta == 3)
                {
                    if (fogli == 0)
                        Console.WriteLine("Scorte Esaurite...");
                    else fogli--;
                }
                //magazzino finito
                if (biro + matite + gomme + fogli == 0)
                {
                    Console.WriteLine("Magazzino esaurito");
                    control = true;
                }

               }
            } while (control == false);

           Console.WriteLine("Listino Prezzi:biro = 1 €uro,matita = 0.80 €uro,gomma = 1.20 €uro,foglio protocollo = 0.30 €uro");
           Console.WriteLine("");

           Console.ReadKey();



        }
    }
}
