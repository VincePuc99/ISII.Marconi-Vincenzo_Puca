﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Prova
{
    class Program
    {
        static void Main(string[] args)
        {
            Random mioRand = new Random();
            long addendo;
            long password;
            long casuale = mioRand.Next(5000, 10000001);

            do
            {
                Console.WriteLine("\n----------------------- Casual Password ---------------------\n");
                Console.Write("Scrivi un valore tra 50000 e 10000000 (compresi): ");
                addendo = Convert.ToInt64(Console.ReadLine());

                if (addendo < 50000 || addendo > 10000000)
                    Console.WriteLine("Valore sbagliato");

            } while (addendo < 50000 || addendo > 10000000);
            
            Console.WriteLine("Valore generato {0} ", casuale);      
                       
            password = casuale + addendo;

            Console.WriteLine("La tua password casuale è {0}", password);
            Console.WriteLine("\n----------------------------------------------------------------\n");
            Console.ReadKey();
               
        }
    }
}
