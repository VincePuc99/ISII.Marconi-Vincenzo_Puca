﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string password;
            do
            {
                Console.Write("Inserire password: ");
                 password = Console.ReadLine().ToLower();
                if (password.Length == 1)
                { }
            } while (password.Length == 1);
            do
            {
                char scatola;
                Random rn = new Random();
                int casuale = rn.Next(100);
                int casuale1 = rn.Next(100);
                int casuale2 = rn.Next(100000);

                for (int i = 0; i < casuale2; i++)
                {
                    scatola = password[password.Length - 1];
                    password = password.Remove(password.Length - 1, 1);
                    password = scatola + password;
                    password = password.Replace('y', 'z');
                    password = password.Replace('q', 'r');
                    password = password.Replace('c', 'd');
                    password = password.Replace('m', 'n');
                    password = password.Replace('e', 'f');
                    password = password.Replace('g', 'h');
                    password = password.Replace('a', 'b');
                    password = password.Replace('k', 'l');
                    password = password.Replace('i', 'j');
                    password = password.Replace('o', 'p');
                    password = password.Replace('s', 't');
                    password = password.Replace('d', 'e');
                    password = password.Replace('u', 'v');
                    password = password.Replace('w', 'x');
                    password = password.Replace('°', '?');
                    password = password.Replace('!', ')');
                    password = password.Replace('1', '2');
                    password = password.Replace('3', '4');
                    password = password.Replace('5', '6');
                    password = password.Replace('7', '8');
                    password = password.Replace('9', '0');
                }
                password = password.Insert(0, casuale.ToString());
                password = password.Insert(password.Length, casuale1.ToString());
                for (int i = 0; i < 7; i++)
                {
                    scatola = password[password.Length - 1];
                    password = password.Remove(password.Length - 1, 1);
                    password = password.Insert(2, scatola.ToString());
                }
                Console.Clear();
                Console.WriteLine("Password Criptata: {0}", password);
                Console.ReadLine();
            } while (true);
           
        }
    }
}
