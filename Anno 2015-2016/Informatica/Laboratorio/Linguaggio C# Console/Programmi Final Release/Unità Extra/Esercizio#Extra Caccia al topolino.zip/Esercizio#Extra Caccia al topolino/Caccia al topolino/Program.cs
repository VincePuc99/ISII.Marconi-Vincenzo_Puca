﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace caccia_al_topo
{
    class Program
    {
        static void Main(string[] args)
        {

            string pos1 = "☼", pos2 = "☼", pos3 = "☼", pos4 = "☼", pos5 = "☼", pos6 = "☼", pos7 = "☼", pos8 = "☼", pos9 = "☼";
            int topolino = 0, scelta = 0;

            ConsoleKeyInfo mossica;
            Random r1 = new Random();

            Console.Title = "( ◡␣◡) CACCIA AL TOPO                         Usare le freccie per Muoversi";
            Console.WindowHeight = 50;
            Console.WindowWidth = 80;
            Console.WriteLine(@".___________.  ______   .______     ______    __       __  .__   __.   ______  ");
            Console.WriteLine(@"|           | /  __  \  |   _  \   /  __  \  |  |     |  | |  \ |  |  /  __  \ ");
            Console.WriteLine(@"`---|  |----`|  |  |  | |  |_)  | |  |  |  | |  |     |  | |   \|  | |  |  |  |");
            Console.WriteLine(@"    |  |     |  |  |  | |   ___/  |  |  |  | |  |     |  | |  . `  | |  |  |  |");
            Console.WriteLine(@"    |  |     |  `--'  | |  |      |  `--'  | |  `----.|  | |  |\   | |  `--'  |");
            Console.WriteLine(@"    |__|      \______/  | _|       \______/  |_______||__| |__| \__|  \______/ ");

            Console.ReadLine();

            pos1 = "■";
            do
            {
                do
                {
                    Console.Clear();
                    topolino = r1.Next(1, 10);
                    Console.WriteLine("\n\n\n\n\n\t\t\t{0} {1} {2}", pos1, pos2, pos3);
                    Console.WriteLine("\t\t\t{0} {1} {2}", pos4, pos5, pos6);
                    Console.WriteLine("\t\t\t{0} {1} {2}", pos7, pos8, pos9);
                    mossica = Console.ReadKey();
                    if (mossica.Key == ConsoleKey.Enter)
                    {
                        if (pos1 == "■")
                        {
                            scelta = 1;

                            if (topolino == 1)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos2 == "■")
                        {
                            scelta = 2;
                            if (topolino == 2)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos3 == "■")
                        {
                            scelta = 3;
                            if (topolino == 3)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos4 == "■")
                        {
                            scelta = 4;
                            if (topolino == 4)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos5 == "■")
                        {
                            scelta = 5;
                            if (topolino == 5)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos6 == "■")
                        {
                            scelta = 6;
                            if (topolino == 6)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos7 == "■")
                        {
                            scelta = 7;
                            if (topolino == 7)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos8 == "■")
                        {
                            scelta = 8;
                            if (topolino == 8)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }

                        if (pos9 == "■")
                        {
                            scelta = 9;
                            if (topolino == 9)
                            {
                                Console.WriteLine("Bravo hai tovato il topo");
                                return;
                            }
                            else
                                Console.WriteLine("Il topo non è qua");

                        }
                        else
                            Console.WriteLine("Il topo non è qua");

                    }
                    switch (mossica.Key)
                    {
                        case ConsoleKey.RightArrow:

                            if (pos1 == "■")
                            {
                                pos1 = "☼";
                                pos2 = "■";
                                break;
                            }
                            if (pos2 == "■")
                            {
                                pos2 = "☼";
                                pos3 = "■";
                                break;
                            }
                            if (pos3 == "■")
                            {
                                pos3 = "■";
                                break;
                            }
                            if (pos4 == "■")
                            {
                                pos4 = "☼";
                                pos5 = "■";
                                break;
                            }
                            if (pos5 == "■")
                            {
                                pos5 = "☼";
                                pos6 = "■";
                                break;
                            }
                            if (pos6 == "■")
                            {
                                pos6 = "■";
                                break;
                            }
                            if (pos7 == "■")
                            {
                                pos7 = "☼";
                                pos8 = "■";
                                break;
                            }
                            if (pos8 == "■")
                            {
                                pos8 = "☼";
                                pos9 = "■";
                                break;
                            }
                            if (pos9 == "■")
                            {
                                pos9 = "■";
                                break;
                            }
                            break;
                        case ConsoleKey.LeftArrow:

                            if (pos1 == "■")
                            {
                                pos1 = "■";
                                break;
                            }
                            if (pos2 == "■")
                            {
                                pos2 = "☼";
                                pos1 = "■";
                                break;
                            }
                            if (pos3 == "■")
                            {
                                pos3 = "☼";
                                pos2 = "■";
                                break;
                            }
                            if (pos4 == "■")
                            {
                                pos4 = "■";
                                break;
                            }
                            if (pos5 == "■")
                            {
                                pos5 = "☼";
                                pos4 = "■";
                                break;
                            }
                            if (pos6 == "■")
                            {
                                pos6 = "☼";
                                pos5 = "■";
                                break;
                            }
                            if (pos7 == "■")
                            {
                                pos7 = "■";
                                break;
                            }
                            if (pos8 == "■")
                            {
                                pos8 = "☼";
                                pos7 = "■";
                                break;
                            }
                            if (pos9 == "■")
                            {
                                pos8 = "■";
                                pos9 = "☼";
                                break;
                            }

                            break;

                        case ConsoleKey.UpArrow:
                            if (pos1 == "■")
                            {
                                pos1 = "■";
                                break;
                            }
                            if (pos2 == "■")
                            {
                                pos2 = "■";
                                break;
                            }
                            if (pos3 == "■")
                            {
                                pos3 = "■";
                                break;
                            }
                            if (pos4 == "■")
                            {
                                pos4 = "☼";
                                pos1 = "■";
                                break;
                            }
                            if (pos5 == "■")
                            {
                                pos5 = "☼";
                                pos2 = "■";
                                break;
                            }
                            if (pos6 == "■")
                            {
                                pos6 = "☼";
                                pos3 = "■";
                                break;
                            }
                            if (pos7 == "■")
                            {
                                pos7 = "☼";
                                pos4 = "■";
                                break;
                            }
                            if (pos8 == "■")
                            {
                                pos8 = "☼";
                                pos5 = "■";
                                break;
                            }
                            if (pos9 == "■")
                            {
                                pos9 = "☼";
                                pos6 = "■";
                                break;
                            }

                            break;
                        case ConsoleKey.DownArrow:
                            if (pos1 == "■")
                            {
                                pos1 = "☼";
                                pos4 = "■";
                                break;
                            }
                            if (pos2 == "■")
                            {
                                pos2 = "☼";
                                pos5 = "■";
                                break;
                            }
                            if (pos3 == "■")
                            {
                                pos3 = "☼";
                                pos6 = "■";
                                break;
                            }
                            if (pos4 == "■")
                            {
                                pos4 = "☼";
                                pos7 = "■";
                                break;
                            }
                            if (pos5 == "■")
                            {
                                pos5 = "☼";
                                pos8 = "■";
                                break;
                            }
                            if (pos6 == "■")
                            {
                                pos6 = "☼";
                                pos9 = "■";
                                break;
                            }
                            if (pos7 == "■")
                            {
                                pos7 = "■";
                                break;
                            }
                            if (pos8 == "■")
                            {
                                pos8 = "■";
                                break;
                            }
                            if (pos9 == "■")
                            {
                                pos9 = "■";
                                break;
                            }

                            break;

                    }

                } while (true);
            } while (true);

            Console.ReadKey();


        }
    }
}
