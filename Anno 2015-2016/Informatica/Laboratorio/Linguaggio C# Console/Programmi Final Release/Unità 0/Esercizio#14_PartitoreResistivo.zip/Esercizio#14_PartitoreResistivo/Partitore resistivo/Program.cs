﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partitore_resistivo
{
    class Program
    {
        static void Main(string[] args)
        {
            double generatore;
            double r1;
            int rvar = 0;
            double intensità;
            double differenziapotenziale;



            Console.Write("Inserire il valore del generatore inserito nella maglia (In Volt) : ");
            generatore = Convert.ToDouble(Console.ReadLine());

            Console.Write("Inserire il valore della prima resitenza (In Ohm) : ");
            r1 = Convert.ToDouble(Console.ReadLine());

            while (rvar <= 1000)
            {
                intensità = generatore / (r1 + rvar);
                differenziapotenziale = rvar * intensità;
                Console.WriteLine("La tensione ai capi di RVAR quando questa vale {0} Ohm è: {1} V", rvar, differenziapotenziale);
                rvar += 100;
            }

            Console.ReadKey();

        }
    }
}
