﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analizzatore_Parentesi
{
    class Program
    {
        static void Main(string[] args)
        {

            string input;
            int cont = 0, cont1=0, cont2=0, cont3=0, cont4=0, cont5=0;
            int index, index1, index2, index3, index4, index5;
            int vuota;
            string stringavuota="";
            bool prova=false;
            bool prova1 = false;
            bool prova2 = false;
            bool prova3 = false;
            bool prova4 = false;
            bool prova5 = false;

            Console.WriteLine("==============  Analizzatore di parentesi   ==============");
            Console.WriteLine("Inserisci una espressione anche con parentesi:\n\n ");
            input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {

                if (input[i] == '(')
                {
                    cont++;
                    
                }
                
                if (input[i] == '[')
                {
                    cont1++;
                    
                }

                if (input[i] == '{')
                {
                    
                    cont2++;
                    
                }

                if (input[i] == ')')
                {
                    cont3++;
                }

                if (input[i] == ']')
                {
                    cont4++;
                }

                if (input[i] == '}')
                {
                    cont5++;
                }

                
            }

            index = input.IndexOf('(');
            index1 = input.IndexOf('[');
            index2 = input.IndexOf('{');
            index3 = input.IndexOf(')');
            index4 = input.IndexOf(']');
            index5 = input.IndexOf('}');

            vuota = input.Length;
            stringavuota = stringavuota.PadLeft(vuota);

            
            if (index == -1)
            {
                prova = true;
            }

            if (index1 == -1)
            {
                prova1 = true;
            }

            if (index2 == -1)
            {
                prova2 = true;
            }

            if (index3 == -1)
            {
                prova3 = true;
            }

            if (index4 == -1)
            {
                prova4 = true;
            }

            if (index5 == -1)
            {
                prova5 = true;
            }




            if (cont != cont3)
            {
                
                if (prova == false)
                {
                    stringavuota = stringavuota.Insert(index, "^");
                }

                if (prova3 == false)
                {

                    stringavuota = stringavuota.Insert(index3, "^");
                }
            }

            if (cont1 != cont4)
            {
                
                if (prova1 == false)
                {
                    stringavuota = stringavuota.Insert(index1, "^");
                }
                if (prova4 == false) 
                {
                    stringavuota = stringavuota.Insert(index4, "^");
                }
            }
            
            if (cont2 != cont5)
            {
                
                if (prova2 == false)
                {
                    stringavuota = stringavuota.Insert(index2, "^");
                }
                if (prova5 == false)
                {
                    stringavuota = stringavuota.Insert(index5, "^");
                }
            }

            Console.WriteLine(stringavuota);

            

            Console.WriteLine("Numero di Tonde  Aperte = {0}", cont);
            Console.WriteLine("Numero di Quadre Aperte = {0}", cont1);
            Console.WriteLine("Numero di Graffe Aperte = {0}", cont2);
            Console.WriteLine("Numero di Tonde  Chiuse = {0}", cont3);
            Console.WriteLine("Numero di Quadre Chiuse = {0}", cont4);
            Console.WriteLine("Numero di Graffe Chiuse = {0}", cont5);



















        }
    }
}
