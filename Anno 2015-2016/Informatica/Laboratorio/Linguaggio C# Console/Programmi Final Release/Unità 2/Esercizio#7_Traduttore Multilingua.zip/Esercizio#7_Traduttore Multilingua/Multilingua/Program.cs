﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilingua
{
    class Program
    {
        static void Main(string[] args)
        {
            int scelta;
            string lingua, parola, lingua1;
            string dizionario1 ="italiano#1@casa#2@auto#3@ragazza";
            string dizionario2 ="inglese#1@house#2@car#3@girl";
            string dizionario3 ="francese#1@maison#2@voiture#3@fille";
            string parolaitanew, parolafranew, parolainglnew, elimina;
            int cont = 3;
            string sn, scelta1;
            int index;




            Console.WriteLine("********* TRADUTTORE MULTILINGUA **********");
            Console.WriteLine(" 1.Traduzione                              ");
            Console.WriteLine(" 2.inserimento nuova parola                ");
            Console.WriteLine(" 3.Eliminazione parola esistente           ");
            Console.WriteLine(" 4.Termina programma                       ");
            Console.WriteLine("===========================================");

            Console.Write("Inserire scelta desiderata: ");
            scelta = Convert.ToInt16(Console.ReadLine());

            switch (scelta)
            { 
                case 1:
                 Console.Write("Inserire parola desiderata: ");
                 parola = Console.ReadLine();
                 Console.Write("Specificare la lingua in cui è espressa: ");
                 lingua = Console.ReadLine();
                 Console.Write("Specificare la lingua in cui la si vuol tradurre: ");
                 lingua1=Console.ReadLine();
                 Console.WriteLine("====================================");

                 if (lingua == "italiano")
                 {

                     if (parola == "casa")
                     {
                         if (lingua1 == "inglese")
                         {
                             for (int i = 0; i < dizionario2.Length; i++)
                             {

                                 if (dizionario1[i] == '#')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 3, 5));
                                     break;
                                 }
                             }
                         }

                         if (lingua1 == "francese")
                         {
                             for (int i = 0; i < dizionario3.Length; i++)
                             {

                                 if (dizionario3[i] == '#')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 3, 6));
                                     break;
                                 }
                             }
                         }
                         for (int i = 0; i < dizionario1.Length; i++)
                         {

                             if (dizionario1[i] == '#')
                             {
                                 Console.WriteLine(dizionario1.Substring(i + 3, 4));
                                 break;
                             }
                         }
                     }

                     if (parola == "auto")
                     {
                         if (lingua1 == "inglese")
                         {
                             for (int i = 0; i < dizionario2.Length; i++)
                             {

                                 if (dizionario1[i] == '@')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 1, 3));
                                     break;
                                 }
                             }

                         }

                         if (lingua1 == "francese")
                         {
                             for (int i = 0; i < dizionario3.Length; i++)
                             {

                                 if (dizionario3[i] == '@')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 1, 7));
                                     break;
                                 }
                             }

                         }

                         for (int i = 0; i < dizionario1.Length; i++)
                         {

                             if (dizionario1[i] == '@')
                             {
                                 Console.WriteLine(dizionario1.Substring(i + 1, 4));
                                 break;
                             }
                         }
                     }

                     if (parola == "ragazza")
                     {
                         if (lingua1 == "francese")
                         {
                             for (int i = 0; i < dizionario3.Length; i++)
                             {
                                 if (dizionario3[i] == '3')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 2, 5));
                                     break;
                                 }
                             }
                         }

                         if (lingua1 == "inglese")
                         {
                             for (int i = 0; i < dizionario2.Length; i++)
                             {
                                 if (dizionario2[i] == '3')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 2, 4));
                                     break;
                                 }
                             }
                         
                         }
                         for (int i = 0; i < dizionario1.Length; i++)
                         {
                             if (dizionario1[i] == '3')
                             {
                                 Console.WriteLine(dizionario1.Substring(i + 2, 7));
                                 break;
                             }
                         }
                     }

                    
                    //francese

                 }

                 if (lingua == "francese")
                 {

                     if (parola == "maison")
                     {
                         if (lingua1 == "italiano")
                         {
                             for (int i = 0; i < dizionario1.Length; i++)
                             {

                                 if (dizionario1[i] == '#')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 3, 4));
                                     break;
                                 }
                             }
                         }

                         if (lingua1 == "inglese")
                         {
                             for (int i = 0; i < dizionario2.Length; i++)
                             {

                                 if (dizionario1[i] == '#')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 3, 5));
                                     break;
                                 }
                             }
                         }

                         for (int i = 0; i < dizionario3.Length; i++)
                         {

                             if (dizionario3[i] == '#')
                             {
                                 Console.WriteLine(dizionario3.Substring(i + 3, 6));
                                 break;
                             }
                         }
                     }
                     //auto francese
                     if (parola == "voiture")
                     {

                         if (lingua1 == "italiano")
                         {
                             for (int i = 0; i < dizionario1.Length; i++)
                             {

                                 if (dizionario1[i] == '@')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 1, 4));
                                     break;
                                 }
                             }
                         }
                         if (lingua1 == "inglese")
                         {

                             for (int i = 0; i < dizionario2.Length; i++)
                             {

                                 if (dizionario1[i] == '@')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 1, 3));
                                     break;
                                 }
                             }

                         }
                         for (int i = 0; i < dizionario3.Length; i++)
                         {

                             if (dizionario3[i] == '@')
                             {
                                 Console.WriteLine(dizionario3.Substring(i + 1, 7));
                                 break;
                             }
                         }
                     }
                     //ragazza francese

                     if (parola == "fille")
                     {
                         if (lingua1 == "italiano")
                         {
                             for (int i = 0; i < dizionario1.Length; i++)
                             {
                                 if (dizionario1[i] == '3')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 2, 7));
                                     break;
                                 }
                             }
                         }

                         if (lingua1 == "inglese")
                         {

                             for (int i = 0; i < dizionario2.Length; i++)
                             {
                                 if (dizionario2[i] == '3')
                                 {
                                     Console.WriteLine(dizionario2.Substring(i + 2, 4));
                                     break;
                                 }
                             }
                         }

                         for (int i = 0; i < dizionario3.Length; i++)
                         {
                             if (dizionario3[i] == '3')
                             {
                                 Console.WriteLine(dizionario3.Substring(i + 2, 5));
                                 break;
                             }
                         }
                     }

                 }
                    //inglese

                 if (lingua == "inglese")
                 {
                     
                     if (parola == "house")
                     {

                         if (lingua1 == "italiano")
                         {

                             for (int i = 0; i < dizionario1.Length; i++)
                             {

                                 if (dizionario1[i] == '#')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 3, 4));
                                     break;
                                 }
                             }
                         
                         }


                         if (lingua1 == "francese")
                         {

                             for (int i = 0; i < dizionario3.Length; i++)
                             {

                                 if (dizionario3[i] == '#')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 3, 6));
                                     break;
                                 }
                             }

                         }

                         for (int i = 0; i < dizionario2.Length; i++)
                         {

                             if (dizionario1[i] == '#')
                             {
                                 Console.WriteLine(dizionario2.Substring(i + 3, 5));
                                 break;
                             }
                         }
                     }
                     //auto

                     if (parola == "car")
                     {
                         if (lingua1 == "italiano")
                         {

                             for (int i = 0; i < dizionario1.Length; i++)
                             {

                                 if (dizionario1[i] == '@')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 1, 4));
                                     break;
                                 }
                             }
                         
                         }
                         if (lingua1 == "francese")
                         {

                             for (int i = 0; i < dizionario3.Length; i++)
                             {

                                 if (dizionario3[i] == '@')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 1, 7));
                                     break;
                                 }
                             }

                         }
                         for (int i = 0; i < dizionario2.Length; i++)
                         {

                             if (dizionario1[i] == '@')
                             {
                                 Console.WriteLine(dizionario2.Substring(i + 1, 3));
                                 break;
                             }
                         }
                     }
                     //ragazza inglese

                     if (parola == "girl")
                     {
                         if (lingua1 == "italiano")
                         {
                             for (int i = 0; i < dizionario1.Length; i++)
                             {
                                 if (dizionario1[i] == '3')
                                 {
                                     Console.WriteLine(dizionario1.Substring(i + 2, 7));
                                     break;
                                 }
                             }
                         }
                         if (lingua1 == "francese")
                         {
                             for (int i = 0; i < dizionario3.Length; i++)
                             {
                                 if (dizionario3[i] == '3')
                                 {
                                     Console.WriteLine(dizionario3.Substring(i + 2, 5));
                                     break;
                                 }
                             }
                         }

                         for (int i = 0; i < dizionario2.Length; i++)
                         {
                             if (dizionario2[i] == '3')
                             {
                                 Console.WriteLine(dizionario2.Substring(i + 2, 4));
                                 break;
                             }
                         }
                     }

                 }

                 break;
        
                case 2:
                 
                 do
                 {
                     Console.WriteLine("Quale lingua usare?");
                     scelta1 = Console.ReadLine();

                     if (scelta1 == "italiano")
                     {
                         Console.WriteLine("Inserire la parola da aggiungere: ");
                         parolaitanew = Console.ReadLine();

                         cont++;
                         dizionario1 += '#' + cont + '@' + parolaitanew;
                     }

                     if (scelta1 == "inglese")
                     {
                         Console.WriteLine("Inserire la parola da aggiungere: ");
                         parolainglnew = Console.ReadLine();

                         cont++;
                         dizionario2 += '#' + cont + '@' + parolainglnew;
                     }

                     if (scelta1 == "francese")
                     {
                         Console.WriteLine("Inserire la parola da aggiungere: ");
                         parolafranew = Console.ReadLine();

                         cont++;
                         dizionario3 += '#' + cont + '@' + parolafranew;
                     }

                     Console.WriteLine("inserimento completato? (SI)--(NO)");
                     sn = Console.ReadLine();
                     if (sn == "si")
                     {
                         continue;
                     }

                 } while (sn=="no");

                 break;

                case 3:
                  do
                 {
                 Console.WriteLine("Inserire la parola che si vuole eliminare: ");
                 elimina = Console.ReadLine();
                 
                 index = dizionario1.IndexOf(elimina);                
                 dizionario1 = dizionario1.Remove(index-3, elimina.Length+3);

                 Console.WriteLine("inserimento completato? (SI)--(NO)");
                 sn = Console.ReadLine();
                 if (sn == "si")
                 {
                     continue;
                 }

                 } while (sn == "no");

                 break;

                 case 4:
                 return;

            }
            
        }
    }
}
